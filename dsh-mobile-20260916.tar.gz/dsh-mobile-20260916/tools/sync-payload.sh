#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  sync-payload.sh —— 把本机"正在用的真实文件"同步进分发包 payload/
#
#  设计要点：
#    · 唯一真源原则：不在分发包里手改副本，一切从现场同步，避免两边漂移
#    · 同步即脱敏：APK 源码里的真实令牌会被替换成 __TOKEN__ 占位符
#    · 同步即审计：扫描密钥/令牌，发现泄漏立刻中止（不产出包）
#    · 生成 MANIFEST.sha256，安装端据此校验完整性
#
#  用法：
#    tools/sync-payload.sh            # 同步 + 脱敏 + 审计 + 生成清单
#    tools/sync-payload.sh --check    # 只检查分发包与现场是否一致（不写任何文件）
# ============================================================
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
HOME_DIR="${HOME_DIR:-$HOME}"
LIVE_APK="$HOME_DIR/dsh-backup/apk-build/DshShell"
LIVE_PLUGIN="$HOME_DIR/.dsh-lab/profiles/web/node_modules/dsh-mobile-adapt"
LIVE_TOOLS="$HOME_DIR/.dsh-tools"
LIVE_BIN="${PREFIX:-/data/data/com.termux/files/usr}/bin"
P="$ROOT/payload"

CHECK_ONLY=0
[ "${1:-}" = "--check" ] && CHECK_ONLY=1

# 收录的运维脚本（分发包只带运行时与维护所需，不带开发工具）
SCRIPTS="dshweb dshstop dshrestart dshstatus dshwatchdog
         dshopenapp dshopen dshopenchrome dsh-applog dsh-snapshot dshlast
         dsh-repatch-all dsh-apply-mime-patch dsh-scan-apk dsh-usage-refresh
         dsh-supervisor-start dsh-supervisor-stop dsh-supervisor-stop-if-idle
         dsh-board dsh-handoff dsh-pair dsh-sshd dsh-job-watch
         dsh-interconnect-check dsh-app-repair dsh-group dsh-release dsh-rollback dsh-rescue dsh-snapshot"

# 明确排除（写在这里，免得以后忘了为什么没有）
#   dsh-hotupdate       —— 开发用（依赖 ~/.dsh-lab 实验目录）
#   dsh-rollback-mobile —— 硬编码了本机备份路径，回滚改由安装脚本自己负责

ok()   { printf '\033[32m%s\033[0m\n' "$*"; }
info() { printf '  %s\n' "$*"; }
warn() { printf '\033[33m%s\033[0m\n' "$*"; }
die()  { printf '\033[31m❌ %s\033[0m\n' "$*" >&2; exit 1; }

[ -d "$LIVE_APK" ]    || die "找不到现场 APK 工程: $LIVE_APK"
[ -d "$LIVE_PLUGIN" ] || die "找不到现场插件: $LIVE_PLUGIN"
[ -d "$LIVE_BIN" ]    || die "找不到 Termux bin: $LIVE_BIN"

echo "════════ 同步 payload ════════"
echo "  源 : $HOME_DIR（本机现场真实文件）"
echo "  目标: $P"
[ "$CHECK_ONLY" = 1 ] && warn "  模式: --check（只比对，不写文件）"
echo

# ---------- 1) 插件 ----------
echo "[1/5] 插件 dsh-mobile-adapt"
if [ "$CHECK_ONLY" = 0 ]; then
  rm -rf "$P/plugin/dsh-mobile-adapt"
  mkdir -p "$P/plugin/dsh-mobile-adapt"
  # ★ 整目录复制，不要只拷 client.js —— 插件还有服务端入口 lib/index.js
  #   （package.json 的 main 指向它）。漏了它，装完重启服务会直接失败。
  ( cd "$LIVE_PLUGIN" && tar cf - --exclude=node_modules --exclude=.git . ) \
    | ( cd "$P/plugin/dsh-mobile-adapt" && tar xf - )
fi
info "文件：$(cd "$P/plugin/dsh-mobile-adapt" && find . -type f | sed 's|^\./||' | sort | tr '\n' ' ')"
info "client.js $(wc -c < "$LIVE_PLUGIN/lib/client.js") 字节"

# ---------- 2) Termux 脚本 ----------
echo "[2/5] Termux 运维脚本（$(echo $SCRIPTS | wc -w) 个）"
if [ "$CHECK_ONLY" = 0 ]; then
  rm -rf "$P/termux/bin"; mkdir -p "$P/termux/bin"
  for s in $SCRIPTS; do
    [ -f "$LIVE_BIN/$s" ] || { warn "  缺少 $s（跳过）"; continue; }
    cp -a "$LIVE_BIN/$s" "$P/termux/bin/$s"
    chmod 755 "$P/termux/bin/$s"
  done
fi
info "已收 $(ls "$P/termux/bin" 2>/dev/null | wc -l) 个脚本"

# ---------- 3) 辅助文件 ----------
echo "[3/5] 辅助文件（session-tail.mjs / link-fix.c）"
if [ "$CHECK_ONLY" = 0 ]; then
  if [ -f "$LIVE_TOOLS/session-tail.mjs" ]; then
    mkdir -p "$P/termux/dsh-tools"
    cp -a "$LIVE_TOOLS/session-tail.mjs" "$P/termux/dsh-tools/session-tail.mjs"
    info "dsh-tools/session-tail.mjs（dshlast 依赖）"
  else
    warn "  缺少 session-tail.mjs → dshlast 将不可用"
  fi
  if [ -f "$HOME_DIR/link-fix.c" ]; then
    cp -a "$HOME_DIR/link-fix.c" "$P/termux/link-fix.c"
    info "link-fix.c（服务启动前必须编译为 ~/link-fix.so）"
  else
    die "缺少 link-fix.c —— 没有它服务可能起不来"
  fi
fi

# ---------- 4) APK 工程（含令牌脱敏） ----------
echo "[4/5] APK 工程（源码脱敏）"
if [ "$CHECK_ONLY" = 0 ]; then
  rm -rf "$P/apk/DshShell"; mkdir -p "$P/apk/DshShell"
  cp -a "$LIVE_APK/AndroidManifest.xml" "$P/apk/DshShell/"
  cp -a "$LIVE_APK/res" "$P/apk/DshShell/res"
  cp -a "$LIVE_APK/src" "$P/apk/DshShell/src"
  # 脱敏：真实令牌 → 占位符（build.sh 会在本机构建时再填回本机令牌）
  find "$P/apk/DshShell/src" -name '*.java' -print0 | while IFS= read -r -d '' f; do
    sed -i -E 's|\?token=[A-Za-z0-9_-]{8,}|\?token=__TOKEN__|g' "$f"
  done
  info "令牌已替换为 __TOKEN__ 占位符"
fi
grep -q '__TOKEN__' "$P/apk/DshShell/src/com/dsh/shell/MainActivity.java" \
  && info "占位符检查: 通过" || warn "  未发现 __TOKEN__ 占位符，请人工确认 ENTRY 写法"

# ---------- 5) 审计：绝不允许密钥/令牌进入分发包 ----------
echo "[5/5] 安全审计（密钥/令牌泄漏扫描）"
LEAK=0
# 5.1 收集本机真实敏感值，逐个做字面比对（最严格）
SECRETS=()
TOK=$(grep -o 'token=[A-Za-z0-9_-]*' "$HOME_DIR/.dsh-web-url" 2>/dev/null | cut -d= -f2)
[ -n "$TOK" ] && SECRETS+=("$TOK")
KEY=$(grep -oE 'DEEPSEEK_API_KEY:[[:space:]]*[^[:space:]]+' "$HOME_DIR/.dsh/.credentials.yaml" 2>/dev/null | awk '{print $2}')
[ -n "$KEY" ] && SECRETS+=("$KEY")
[ -s "$HOME_DIR/.deepseek_key" ] && SECRETS+=("$(tr -d '\r\n' < "$HOME_DIR/.deepseek_key")")
for s in "${SECRETS[@]}"; do
  [ ${#s} -lt 8 ] && continue
  if grep -rqF -- "$s" "$P" 2>/dev/null; then
    warn "  ❌ 分发包里出现了本机真实凭据（长度 ${#s}）"
    LEAK=1
  fi
done
# 5.2 通用模式扫描（防以后新加文件时漏网）
if grep -rqE 'sk-[A-Za-z0-9]{16,}' "$P" 2>/dev/null; then
  warn "  ❌ 发现形如 sk-xxx 的 API Key"; LEAK=1
fi
if grep -rqE 'token=[A-Za-z0-9_-]{16,}' "$P" 2>/dev/null; then
  warn "  ❌ 发现形如真实令牌的字符串（非占位符）"; LEAK=1
fi
[ "$LEAK" = 1 ] && die "审计未通过：分发包含凭据，已中止（未生成清单）"
ok "审计通过：分发包内无任何凭据"

# ---------- 生成清单 ----------
if [ "$CHECK_ONLY" = 0 ]; then
  cd "$ROOT"
  find payload -type f ! -name MANIFEST.sha256 | LC_ALL=C sort | xargs sha256sum > payload/MANIFEST.sha256
  echo
  ok "清单已生成: payload/MANIFEST.sha256（$(wc -l < payload/MANIFEST.sha256) 个文件）"
  echo
  echo "  分发包体积: $(du -sh payload | cut -f1)"
  echo "  明细:"
  for d in plugin termux apk; do printf '    %-8s %s\n' "$d" "$(du -sh "$P/$d" 2>/dev/null | cut -f1)"; done
else
  # --check：比对现场与分发包是否漂移
  echo
  echo "── 漂移检查 ──"
  D=0
  rel=""
  while IFS= read -r rel; do
    if ! cmp -s "$LIVE_PLUGIN/$rel" "$P/plugin/dsh-mobile-adapt/$rel"; then
      warn "  插件 $rel 已漂移（现场 ≠ 分发包）"; D=1
    fi
  done < <( cd "$LIVE_PLUGIN" && find . -type f ! -path './node_modules/*' | sed 's|^\./||' | sort )
  # 反向：分发包里有、现场没有的
  while IFS= read -r rel; do
    [ -f "$LIVE_PLUGIN/$rel" ] || { warn "  插件 $rel 在分发包里多余"; D=1; }
  done < <( cd "$P/plugin/dsh-mobile-adapt" && find . -type f | sed 's|^\./||' | sort )
  for s in $SCRIPTS; do
    [ -f "$LIVE_BIN/$s" ] || continue
    cmp -s "$LIVE_BIN/$s" "$P/termux/bin/$s" || { warn "  $s 已漂移"; D=1; }
  done
  [ "$D" = 0 ] && ok "无漂移：分发包与现场一致" || warn "有漂移 → 跑一次 tools/sync-payload.sh 同步"
fi
