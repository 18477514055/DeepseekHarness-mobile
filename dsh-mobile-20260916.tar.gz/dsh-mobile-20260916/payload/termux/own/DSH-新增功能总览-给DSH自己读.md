# DSH 跨端协作 · 新增功能总览（**给本机 DSH 自己读**）

> 这份文件是**给装了你的人看的**：用户说"怎么互联 / 手机能干什么 / 有哪些新功能"时，
> 你先读这份，再照里面的命令与接口干活。**它同时是分发包装进用户工作区的那一份。**
> 最后更新：2026-09-16（对应手机端 DshShell v1.4.2 / versionCode 17）

---

## 0. 一分钟认识这套东西

- **手机 = 主机（hub）**：跑看板 `8787`（数据面）+ DSH 本体 `3080`（官方 UI）+ `sshd 8022`（自动化通道）。
- **电脑 = 从机（client）**：**纯出站、不监听端口**；它主动连手机，所以手机**不需要**把 DSH 暴露到局域网。
- **两端装的是同一份客户端插件** `dsh-workbench`（设置页「跨端协作」+ 会话视图「群聊 / 文件 / 余额」+ 输入框 `⇄`）。
- **绝不互相污染上下文**：跨端只传 **指令 / 工作摘要 / 产物文件**，会话与模型上下文各自独立。

---

## 1. 新增功能清单（逐条：是什么 · 怎么用 · 在哪）

### 1.1 配对与互联
- **6 位配对码**：主机开码（**5 分钟有效、用一次作废、错 5 次作废**）；对方输码即加为好友。
- **两种加入方式**：界面「设置 → 跨端协作 → 加入别人的小组（输入 6 位码）」；或命令行 `dsh-pair connect <码> [--host IP]` → 落 `~/.dsh-handoff/peer.json`（0600）。
- **双向列表**：主机侧 `devices.json` 记对方；加入方 `peer.json` 记主机 —— **两边的设备列表里都看得到对方**。
- **局域网自动发现**：主机在 **UDP 8788** 应答 `DSH-DISCOVER-V1`（定向广播优先）；免鉴权的 `GET /api/pair/info` 给"扫网段"兜底（**只有最小信息，无令牌**）。
- **命令行**：`dsh-pair discover`（扫主机）、`dsh-pair connect <码>`、`dsh-pair status`、`dsh-pair beat`、`dsh-pair forget`。

### 1.2 小组 / 组长
- 每个会话是一个**小组**：`participants`（成员） + **`host`（组长，默认手机）**；`GET /api/job` 回 `host / is_host / members`。
- 电脑默认是**组员**；组长是协调方。界面上：新建会话可选「组长（手机 / 电脑）」，会话头显示「组长手机」。

### 1.3 会话与轮次（两种走法 + 每端配额）
- **接力（relay，默认）**：一轮只轮到一台，做完交棒。
- **扇出（fanout）**：一轮里**各成员各自答一次**，**最后一个人交完才推进轮次**；此时 `turn=null`，"该谁动手"看 **`pending`**。
- **每端配额 `rounds_plan`**：可给每台设备单独设"最多回复几次"（新建会话表单里的步进器）。
  - `GET /api/job` 回 `rounds_plan / used_by / left_by / my_left`；配额用完再 `claim` → **409「本端口轮次已用完」**；**各端都用完 ⇒ 自动 PAUSED**；缺省＝每端都用 `max_rounds`（与旧行为等价）。
- **三闸**：轮数 / 金额 / 墙钟，谁先到谁停。判据看字段：**`can_run_current` → `gate_ok` → `gate_level`**（`gate` 只是给人看的文案，别解析）。
- **金额语义**：`cap_cny=null` 无上限、**`0`=不许花钱**；**成本算不出绝不填 0**（`cost_error` / `cost.unknown`）；`auto_run` 默认关。

### 1.4 群聊
- 一条 **append-only** 的群消息流（`board/group.jsonl`，递增 `seq`），**与任何一端的会话文件无关**。
- `kind ∈ say|work|file|system|instruction`；`to[]` 指定收件端口（空=全部）；`refs[]` 带产物（name/sha256/size）。
- **按会话分段**：`job` 只给 `system`/`work` 打标；`GET /api/group?job=<id>` 在**服务端**过滤。
- **界面**：会话视图「群聊」；顶部会话头显示 组长/轮次/已用金额/状态 + 「＋ 新建会话」；正文用官方 MarkdownText 渲染成**纯文本观感**（`**` 记号会被净化）。
- **全局指令转发**：**主输入框**里发一句话 = 群指令，发给所选端口（不用第二个输入框）。

### 1.5 文件交换（共享区）
- 视图「**文件**」（与 对话/轨迹/群聊/余额 并列）：看双方交换过的每个文件（名字/大小/时间/**sha256**），可**上传**、**下载**、复制哈希。
- 接口：`POST /api/upload`（**原始字节流**，流式落盘，上限 8GB，无 `Content-Length`→411）；
  `GET /api/download?name=|&id=&area=files|tx|ws|inbox|outbox|sent|archive`。
- **取件统一规则 `pick_name`**：先 `id=`（文件名的 base64url，**名字再怪也取得走**），再 `name=`；规则是"拒绝危险字符"（`+ # % & 空格 括号 中文` 都放行）。
- 界面走同源代理：`/dsh-workbench/upload` 与 `/dsh-workbench/download`（**令牌只在服务端，不回传浏览器**）。

### 1.6 余额
- 「余额」是**与对话/轨迹/群聊/文件并列的官方视图**（不再是悬浮胶囊）：显示账户余额 + 会话累计 tokens / 缓存读取 / 命中率 / 本轮输入输出。
- 数据直接读同源静态文件 **`/dsh-usage.json`**（看门狗写的），10 秒自动刷新；模式关掉时旧胶囊会回来。

### 1.7 移动端适配（手机侧原生壳 + 网页层）
- 左侧栏是**全屏覆盖层**；**从屏幕中间偏左/偏右（离左右各留 20px）向右划 = 打开；在侧栏上向左划 = 关闭**（灵敏度：位移 26px / 纵容差 80px / 900ms 内）。
- **系统返回手势分层**：先关**当前层**（余额页 → 设置页 → 左侧栏 → 官方弹层），都没有可关的才退出并回收服务（**不再"不管在哪都直接回桌面"**）。
- **键盘隔离**：点侧栏「新建对话」或切换会话回主界面时，**1.5~1.8 秒内不弹软键盘**；你主动点输入框照常弹。
- 会话头 ⋮ 菜单里注入「刷新页面 / 检查更新」等；余额胶囊已收进「余额」视图。

### 1.8 交接单通道（自动化用）
- `dsh-handoff`：`new/read/done/sent/manifest/status`；目录 `~/.dsh-handoff/{inbox,outbox,sent,archive}`。
- **文件名规则**："拒绝危险字符"；取件支持 `id=`；`/api/state` 的 `notes[]` 每条带 `id`。
- 看板 `8787`：状态台 + 时间线 + 交接单读写 + 文件上传下载 + sha256 核对；页面有「给电脑上的 DSH」一键复制区；`/api/brief` 是给对面 DSH 读的机器简报。

### 1.9 版本与回滚
- `dsh-release new <版本>`（改动前快照）/ `mark-good` / `current` / `rollback`；`dsh-rescue [--fix]` 是用户的一条体检+修复命令。
- **铁律**：重大更新一律"升级 + 可回滚"；`dsh-rescue` 是用户的安全网。

---

## 2. 常用命令（终端里直接跑）

```bash
dshstatus                 # 服务/看门狗/余额/内存
dsh-board status|url|token|post|timeline|brief|files   # 看板
dsh-handoff status|read latest|new <短名>|manifest <文件...>
dsh-pair discover|connect <6位码>|status|beat|forget
dsh-job-watch status|once|dry|loop        # 接力守卫（dry=空跑不花钱）
dsh-interconnect-check    # ★ 互联自检：一键看"能不能互联"
dsh-release current|list|rollback [版本]
dsh-rescue                # 用户体检命令（--fix = 回滚到 GOOD + 重打补丁）
```

## 3. 机器接口入口（给"另一端的 DSH"）

```
GET  /api/brief            机器可读简报（状态 + 清单 + 约定 + curl 示例）
GET  /api/pair/info        免鉴权最小发现信息（无令牌）
GET  /api/state            全量状态（notes/files/ws/job/timeline…）
GET  /api/job              任务/闸门/配额/小组（判 can_run_current 等字段）
GET  /api/group?since=&job=  群消息（append-only）
GET  /api/work             各设备工作摘要
```
> 除 `/api/pair/claim` 与 `/api/pair/info` 外，**所有接口都要令牌**（`?token=` 或 `X-Board-Token`）。

## 4. 怎么互联（三步）

**手机（主机）**
1. 打开 DSH → 设置 → **跨端协作** → 打开模式；
2. 点「**生成配对码**」→ 得到 6 位码（5 分钟有效，给别人念/发过去）；
3. 把 `dsh-board url` 打出来的地址（含令牌）给电脑用浏览器打开也行 —— 看板就是共享工作台。

**电脑（从机）**
1. 设置 → **跨端协作** → 打开模式 → 「**加入别人的小组**」输入 6 位码（或命令行 `dsh-pair connect <码> --host <手机IP>`）；
2. 配对成功后两端列表互相出现；
3. 之后所有跨端动作（建会话 / 群聊 / 传文件 / 接棒）都从**主界面**发起。

**免打字 IP（推荐）**：同一局域网内用 **UDP 8788 自动发现**（`dsh-pair discover` / 界面的"扫描附近主机"）→ 选中主机 → 输一次码即可。

**排障**：连不上先看 `dsh-board status`（地址是否读到 = 热点/USB 网络共享有没有开）、`dsh-sshd status`（8022）、`dsh-interconnect-check`。

## 5. 红线（DSH 自己也要守）

1. **花钱的动作必须用户点头**（`auto_run` 默认关、金额上限默认 ¥0.5）；
2. **关掉模式回原生**：把我们全关掉，主界面看不出少了什么；
3. **不互相污染上下文**；**契约只增不改**；**一个判据只许一处实现**；
4. **取不到的数据就说取不到**，绝不填一个看起来合理的数（成本尤其如此）。

## 6. 关键路径

```
看板/数据     ~/.dsh-handoff/{board,workspace,files,inbox,outbox,sent,archive}
插件(手机)    ~/.dsh/profiles/web/node_modules/{dsh-workbench,dsh-mobile-adapt}
日志          ~/.dsh/run/{dsh,watchdog,supervisor,app}.log
自测脚本      ~/.modetest.js ~/.menutest2.js ~/.sessiontest.js ~/.grouptest.js
              ~/.sessiontest-board.py ~/.nametest-board.py ~/.fanouttest-board.py
```
