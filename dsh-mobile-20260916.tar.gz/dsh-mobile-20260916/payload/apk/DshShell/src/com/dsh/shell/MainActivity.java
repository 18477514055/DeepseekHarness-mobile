package com.dsh.shell;

import android.app.Activity;
import android.app.DownloadManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageInfo;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.webkit.ValueCallback;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.JavascriptInterface;
import android.webkit.URLUtil;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceError;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import org.json.JSONObject;

import java.util.ArrayList;

/**
 * DSH 桌面壳：全屏 WebView + 连不上自动重试 + 页面内一键更新 + 后台自启监护。
 *
 * 与网页的接口是注入的 window.DshShell（见 Bridge 类）：⋮ 菜单里的「后台自启动」开关、
 * 「启动/停止 DSH 服务」都通过它落到原生。
 */
public class MainActivity extends Activity {

    /* ★ 2026-09-16：主 WebView 的文件选择器钩子（以前是裸的 WebChromeClient ⇒
     *   <input type="file"> 点击**静默无反应**，插件里的「选择文件上传」永远点不开）。
     *   回退点：~/dsh-backup/apk-build/backups/20260916-033345-v15-回退点/ */
    private ValueCallback<Uri[]> fileCb = null;
    private static final int REQ_FILE_CHOOSER = 4242;
    private static final String ENTRY = "http://127.0.0.1:3080/?token=__TOKEN__";
    private static final long RETRY_MS = 3000L;
    private static final int REQ_PERMS = 1001;

    private WebView web;
    private boolean retrying = false;
    private long lastDownloadId = -1L;
    private BroadcastReceiver installReceiver;

    /* 等待页（白底 + 进度条）的状态 */
    private Handler ui;
    private long loadT0 = 0L;
    private volatile boolean booting = false;
    private boolean loadingShown = false;
    private boolean loadingChrome = false;
    private boolean lastDownLogged = false;
    /**
     * 主框架刚刚加载失败过。
     * 关键事实：加载失败时 Chrome 依然会触发 onPageFinished，且 URL 就是入口地址，
     * 所以只靠 URL 判断会把"失败页的 finish"误当成"界面已就绪"，从而把进度轮询关掉，
     * 应用就永远卡在等待页（v1.3.4~v1.3.9 的 bug，诊断日志已证实）。
     */
    private volatile boolean mainFrameFailed = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        /* 刻意不再隐藏状态栏：隐藏后 MIUI 会在挖孔区留一条黑带，页面看起来就是
           "没铺满的矩形"。改成显示状态栏 + 让状态栏/导航栏颜色与页面一致，
           观感连续，且完全不影响主界面布局（DSH 前端自身不处理 safe-area）。 */
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);

        ui = new Handler();
        web = new WebView(this);
        /* 启动与等待期间一律白底：既不闪深色，也不会让人看到"没铺满"的深色矩形 */
        web.setBackgroundColor(Color.WHITE);
        getWindow().getDecorView().setBackgroundColor(Color.WHITE);
        /* 启动瞬间系统栏也刷白（页面底色与系统栏一致，才不会有"矩形边"） */
        try {
            applyBarColors(Color.WHITE);
            loadingChrome = true;
        } catch (Exception e) {}
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        /* 安全：本机 DSH 是 127.0.0.1（被视作安全上下文），不需要放行混合内容 */
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        if (Build.VERSION.SDK_INT >= 16) {
            s.setAllowFileAccessFromFileURLs(false);
            s.setAllowUniversalAccessFromFileURLs(false);
        }
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setSupportZoom(false);

        web.addJavascriptInterface(new Bridge(), "DshShell");

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb, FileChooserParams params) {
                if (fileCb != null) { try { fileCb.onReceiveValue(null); } catch (Exception e) {} }
                fileCb = cb;
                try {
                    Intent i = new Intent(Intent.ACTION_GET_CONTENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType("*/*");
                    i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, false);
                    startActivityForResult(Intent.createChooser(i, "\u9009\u62e9\u6587\u4ef6"), REQ_FILE_CHOOSER);
                    return true;
                } catch (Exception e) {
                    fileCb = null;
                    return false;
                }
            }
        });
        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                /* ★ 安全红线：JS 桥对本 WebView 的所有页面生效，非本机页面绝不能在此加载 */
                Uri u = req == null ? null : req.getUrl();
                if (u == null) return true;
                String h = u.getHost();
                if (h != null && (h.equals("127.0.0.1") || h.equals("localhost"))) return false;
                try {
                    Intent i = new Intent(Intent.ACTION_VIEW, u);
                    i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                    startActivity(i);
                } catch (Exception e) {}
                return true;
            }

            @Override
            public void onReceivedSslError(WebView v, android.webkit.SslErrorHandler h,
                                           android.net.http.SslError err) {
                h.cancel();
            }

            @Override
            public void onPageFinished(WebView v, String url) {
                /* ★ 等待页也会触发 onPageFinished。若在这里当成"界面就绪"，
                   就会把驱动它的进度轮询停掉 —— 于是服务起来了也没人打开界面，
                   应用永远卡在等待页（v1.3.4~v1.3.7 的 bug）。
                   等待页是 loadData 载入的，URL 不是 3080，据此排除。 */
                String ck;
                try {
                    ck = CookieManager.getInstance().getCookie("http://127.0.0.1:3080/") == null ? "none" : "yes";
                } catch (Exception e) { ck = "?"; }
                dlog("PAGE_FINISH " + shortUrl(url) + " cookie=" + ck + " failed=" + mainFrameFailed);
                if (mainFrameFailed) {
                    /* 这次 finish 属于加载失败的那一次 —— 绝不能当成"界面就绪" */
                    mainFrameFailed = false;
                    return;
                }
                if (url == null || !url.startsWith("http://127.0.0.1:3080")) return;
                injectVersion(v);
                boolean wasLoading = loadingShown;
                loadingShown = false;
                booting = false;
                if (ui != null) ui.removeCallbacks(ticker);
                restoreChrome(wasLoading);
            }
            @Override
            public void onReceivedError(WebView v, WebResourceRequest req, WebResourceError err) {
                if (req != null && req.isForMainFrame()) {
                    mainFrameFailed = true;
                    dlog("MAIN_ERROR code=" + err.getErrorCode() + " " + err.getDescription());
                    scheduleRetry();
                }
            }
            @Override
            public void onReceivedHttpError(WebView v, WebResourceRequest req, WebResourceResponse res) {
                if (req != null && req.isForMainFrame()) {
                    mainFrameFailed = true;
                    dlog("MAIN_HTTP status=" + (res == null ? "?" : res.getStatusCode()));
                    scheduleRetry();
                }
            }
        });

        /* 页面里点 .apk 链接 -> 交给系统下载 -> 完成后自动拉起安装器 */
        web.setDownloadListener(new DownloadListener() {
            public void onDownloadStart(String url, String ua, String cd, String mime, long len) {
                startApkDownload(url, cd, mime);
            }
        });

        setContentView(web);
        dlog("APP_START v" + versionName() + " entry=" + shortUrl(ENTRY));
        web.loadUrl(ENTRY);

        /* 首次启动补齐权限（在 Termux 中运行命令） */
        web.postDelayed(new Runnable() {
            public void run() { requestMissingPermissions(); }
        }, 1200L);
        ensureServerAsync();
    }

    @Override
    protected void onStart() {
        super.onStart();
        /* 应用可见：撤销后台空闲定时器，并开始 10 秒探活保活 */
        LifecycleService.visible = true;
        Alarm.cancel(this);
        startService(new Intent(this, LifecycleService.class).setAction(LifecycleService.ACTION_OPEN));
    }

    @Override
    protected void onResume() {
        super.onResume();
        ensureServerAsync();
        /* 从 Termux 切回来时，进度轮询可能已随进程被回收而停掉 —— 这里补一次 */
        if (loadingShown && ui != null) {
            booting = true;
            ui.removeCallbacks(ticker);
            ui.postDelayed(ticker, 300L);
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        /* 切后台绝不停服务（否则跑任务会被打断），改为排一个「后台空闲定时器」：
           20 分钟后若用户仍未切回、且 Termux 侧确认没有任务在跑，才回收服务。
           计时器由 AlarmManager 保管，能活过本应用进程被回收。 */
        LifecycleService.visible = false;
        Alarm.schedule(this, Alarm.FIRST_MS);
    }

    /**
     * 打开应用 = 用户明确要用了：服务没跑就直接拉起来，并解除监护挂起。
     * 这一条同时是「后台不启动」模式下的正常入口：没有后台常驻，但打开应用即可用。
     */
    private void ensureServerAsync() {
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    if (Termux.ping()) return;
                    Cfg.unpause(MainActivity.this);
                    Termux.runOnce(MainActivity.this, "dsh-supervisor-start", "DSH: app launch", 12000L);
                } catch (Exception e) {}
            }
        }).start();
    }

    /* ================= 与网页的接口 ================= */

    /* ================= ★ 2026-09-16：App 内「诊断与修复」 =================
       目标（用户原话）：崩溃后**不用打开 Termux**，在软件本体里就能体检/修复/看日志。
       做法：等待页按钮 → window.DshShell.repair(action) → RUN_COMMAND(带 PendingIntent)
            → Termux 把 stdout/stderr/exitCode 广播回来 → evaluateJavascript 推到页面。 */
    private static final String REPAIR_PERM = "com.dsh.shell.REPAIR_RESULT";
    private BroadcastReceiver repairRx = null;

    private void ensureRepairReceiver() {
        if (repairRx != null) return;
        repairRx = new BroadcastReceiver() {
            @Override public void onReceive(Context ctx, Intent it) {
                try {
                    Bundle b = it.getBundleExtra(Termux.EXTRA_RESULT_BUNDLE);
                    String out = "", err = ""; int code = -1;
                    if (b != null) {
                        out = b.getString("stdout", "");
                        err = b.getString("stderr", "");
                        code = b.getInt("exitCode", -1);
                        String msg = b.getString("errmsg");
                        if (msg != null) err = err + msg;
                    }
                    String text = (out == null ? "" : out);
                    if (err != null && err.length() > 0) text = text + "\n[stderr] " + err;
                    pushRepair(text, code);
                } catch (Exception e) {}
            }
        };
        IntentFilter f = new IntentFilter(REPAIR_PERM);
        try {
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(repairRx, f, Context.RECEIVER_NOT_EXPORTED);
            else registerReceiver(repairRx, f);
        } catch (Exception e) { repairRx = null; }
    }

    private void pushRepair(final String text, final int code) {
        runOnUiThread(new Runnable() { public void run() {
            try {
                if (web == null) return;
                String js = "window.__dshRepair&&window.__dshRepair("
                        + org.json.JSONObject.quote(text) + "," + code + ")";
                web.evaluateJavascript(js, null);
            } catch (Exception e) {}
        }});
    }

    private class Bridge {
        /** ★ 诊断与修复：action 例 "status" / "fix" / "patch" / "restart" / "mirror" /
         *  "log" / "agent --yes" / "open-termux"。输出会经 __dshRepair 回推到等待页。 */
        @JavascriptInterface
        public void repair(final String action) {
            runOnUiThread(new Runnable() { public void run() {
                try {
                    ensureRepairReceiver();
                    Intent it = new Intent(REPAIR_PERM);
                    it.setPackage(getPackageName());
                    PendingIntent pi = PendingIntent.getBroadcast(MainActivity.this, 1001, it,
                            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_MUTABLE);
                    String a = (action == null || action.trim().isEmpty()) ? "status" : action.trim();
                    String[] args = a.split("\\s+");
                    boolean ok = Termux.runWithResult(MainActivity.this, "dsh-app-repair", args,
                            "dsh-app-repair " + a, pi);
                    if (!ok) pushRepair("[err] 无法调用 Termux（RUN_COMMAND 权限未授予，或 Termux 未在运行）", -1);
                } catch (Exception e) {
                    pushRepair("[err] 修复调用失败：" + e, -1);
                }
            }});
        }

        @JavascriptInterface
        public String state() {
            JSONObject o = new JSONObject();
            try {
                o.put("version", versionCode());
                o.put("versionName", versionName());
                o.put("mode", "\u968f\u5e94\u7528\u542f\u505c");
                o.put("tracking", LifecycleService.alive);
                o.put("stateText", LifecycleService.lastState);
                o.put("termuxPerm", Termux.granted(MainActivity.this));
            } catch (Exception e) { /* 返回已填好的部分 */ }
            return o.toString();
        }

        @JavascriptInterface
        public void startServer() {
            Cfg.unpause(MainActivity.this);
            final boolean ok = Termux.run(MainActivity.this, "dsh-supervisor-start", null, "DSH：手动启动服务");
            toastOnUi(ok ? "正在启动 DSH 服务…" : "无法调用 Termux：请先授予“在 Termux 中运行命令”权限");
        }

        @JavascriptInterface
        public void stopServer() {
            Cfg.pause(MainActivity.this, 10 * 60 * 1000L);   /* 挂起监护 10 分钟，否则会被立刻拉回来 */
            final boolean ok = Termux.run(MainActivity.this, "dsh-supervisor-stop", null, "DSH：手动停止服务");
            toastOnUi(ok ? "已停止 DSH 服务（监护挂起 10 分钟）" : "无法调用 Termux：请先授予权限");
        }

        @JavascriptInterface
        public void requestSetup() {
            runOnUiThread(new Runnable() {
                public void run() {
                    requestMissingPermissions();
                    askBatteryExemption();
                }
            });
        }

        /**
         * 打开 Termux 应用。用于恢复「Termux 被系统清理强制停止」的死局 ——
         * 被强停的应用会拦截跨应用 intent，只有用户手动启动一次才能解锁；
         * 而 Termux 的 .bashrc 会在 shell 启动时自动拉起 DSH。
         */
        @JavascriptInterface
        public void openTermux() {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        Intent i = getPackageManager().getLaunchIntentForPackage("com.termux");
                        if (i == null) { toastOnUi("找不到 Termux 应用"); return; }
                        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                        startActivity(i);
                        /* 3.5 秒后让 Termux 侧「拉起服务并把本应用切回前台」：
                           用户只需点一次，剩下的自动完成，不必手动切回来。 */
                        ui.postDelayed(new Runnable() {
                            public void run() {
                                Termux.run(MainActivity.this, "dshopenapp", null, "DSH: open and return");
                            }
                        }, 3500L);
                    } catch (Exception e) {
                        toastOnUi("无法打开 Termux，请在 Termux 里执行 dshopenapp");
                    }
                }
            });
        }

        /** 让 Termux 扫描存储里最新的安装包并发布到页面（App 自身读不了 /sdcard 的 apk）。 */
        @JavascriptInterface
        public void checkUpdate() {
            Termux.run(MainActivity.this, "dsh-scan-apk", null, "DSH: check for update");
        }

        /** 在应用内打开 DeepSeek 网页版 / 开放平台（独立 WebView，无 JS 桥）。 */
        @JavascriptInterface
        public void openPane(final String which) {
            runOnUiThread(new Runnable() {
                public void run() {
                    try {
                        boolean platform = "platform".equals(which);
                        Intent i = new Intent(MainActivity.this, WebPaneActivity.class);
                        i.putExtra(WebPaneActivity.EXTRA_URL,
                                platform ? "https://platform.deepseek.com/" : "https://chat.deepseek.com/");
                        i.putExtra(WebPaneActivity.EXTRA_TITLE,
                                platform ? "DeepSeek \u5f00\u653e\u5e73\u53f0" : "DeepSeek");
                        startActivity(i);
                    } catch (Exception e) {
                        toastOnUi("\u65e0\u6cd5\u6253\u5f00\u9875\u9762");
                    }
                }
            });
        }

        @JavascriptInterface
        public int version() { return versionCode(); }
    }

    /* ================= 权限 ================= */

    private void requestMissingPermissions() {
        try {
            ArrayList<String> want = new ArrayList<String>();
            if (!Termux.granted(this)) want.add(Termux.PERM);
            if (!want.isEmpty()) requestPermissions(want.toArray(new String[0]), REQ_PERMS);
            else askBatteryExemption();
        } catch (Exception e) {}
    }

    @Override
    public void onRequestPermissionsResult(int code, String[] perms, int[] results) {
        super.onRequestPermissionsResult(code, perms, results);
        if (code != REQ_PERMS) return;
        if (Termux.granted(this)) ensureServerAsync();
        askBatteryExemption();
    }

    private void askBatteryExemption() {
        try {
            if (batteryExempt() || Cfg.batteryAsked(this)) return;
            Cfg.setBatteryAsked(this);
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {}
    }

    private boolean batteryExempt() {
        try {
            PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
            return Build.VERSION.SDK_INT < 23 || pm.isIgnoringBatteryOptimizations(getPackageName());
        } catch (Exception e) {
            return true;
        }
    }

    /* ================= 监护人服务 ================= */

    private void toastOnUi(final String msg) {
        runOnUiThread(new Runnable() {
            public void run() {
                try { Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show(); } catch (Exception e) {}
            }
        });
    }

    /* ================= 版本 / 下载 / 重试 ================= */

    private int versionCode() {
        try {
            PackageInfo pi = getPackageManager().getPackageInfo(getPackageName(), 0);
            return (Build.VERSION.SDK_INT >= 28) ? (int) pi.getLongVersionCode() : pi.versionCode;
        } catch (Exception e) {
            return 0;
        }
    }

    private String versionName() {
        try {
            return getPackageManager().getPackageInfo(getPackageName(), 0).versionName;
        } catch (Exception e) {
            return "";
        }
    }

    /** 把当前已安装的 versionCode 告诉网页，供其比对更新。 */
    private void injectVersion(WebView v) {
        try {
            v.evaluateJavascript("window.__DSH_APP_VERSION=" + versionCode()
                    + ";window.__DSH_APP_VERSION_NAME='" + versionName() + "';", null);
        } catch (Exception e) { /* ignore */ }
    }

    private void startApkDownload(String url, String contentDisposition, String mime) {
        try {
            String name = URLUtil.guessFileName(url, contentDisposition, mime);
            if (!name.endsWith(".apk")) name = name + ".apk";
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setTitle("DSH 更新");
            req.setDescription(name);
            req.setMimeType("application/vnd.android.package-archive");
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name);
            String cookie = CookieManager.getInstance().getCookie(url);
            if (cookie != null) req.addRequestHeader("Cookie", cookie);

            final DownloadManager dm = (DownloadManager) getSystemService(Context.DOWNLOAD_SERVICE);
            lastDownloadId = dm.enqueue(req);
            Toast.makeText(this, "正在下载更新…", Toast.LENGTH_SHORT).show();

            installReceiver = new BroadcastReceiver() {
                public void onReceive(Context c, Intent i) {
                    long id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L);
                    if (id != lastDownloadId) return;
                    Uri uri = dm.getUriForDownloadedFile(id);
                    if (uri == null) { Toast.makeText(MainActivity.this, "下载失败", Toast.LENGTH_LONG).show(); return; }
                    Intent it = new Intent(Intent.ACTION_VIEW);
                    it.setDataAndType(uri, "application/vnd.android.package-archive");
                    it.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_ACTIVITY_NEW_TASK);
                    try { startActivity(it); }
                    catch (Exception e) { Toast.makeText(MainActivity.this, "无法拉起安装器，请到下载目录手动安装", Toast.LENGTH_LONG).show(); }
                }
            };
            IntentFilter f = new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE);
            if (Build.VERSION.SDK_INT >= 33) registerReceiver(installReceiver, f, Context.RECEIVER_EXPORTED);
            else registerReceiver(installReceiver, f);
        } catch (Exception e) {
            Toast.makeText(this, "下载启动失败: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private long lastRetryAt = 0L;

    private void scheduleRetry() {
        if (web == null) return;
        long now = System.currentTimeMillis();
        if (now - lastRetryAt < 2000L) return;     /* 2 秒节流，避免失败时紧密循环 */
        lastRetryAt = now;
        /* 主页面加载失败：允许重新进入等待页并重启进度轮询。
           否则一旦那次 loadUrl 失败，就再也没有人去打开界面了。 */
        loadingShown = false;
        booting = false;
        showLoading();
    }

    /* ================= 等待页：白底 + 官方标志 + 真实进度 ================= */

    private void showLoading() {
        if (web == null) return;
        if (loadingShown) {
            /* 已在等待页：不重载页面（免得进度条抖），但必须保证轮询还在跑 */
            if (ui != null && booting) {
                ui.removeCallbacks(ticker);
                ui.postDelayed(ticker, 900L);
            }
            return;
        }
        loadingShown = true;
        booting = true;
        loadT0 = System.currentTimeMillis();
        dlog("SHOW_LOADING");
        applyLoadingChrome();
        String html = readRaw(R.raw.loading);
        /* base URL 必须为空：否则等待页的 URL 会和真界面一样是 3080，无法区分 */
        web.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null);
        if (ui != null) {
            ui.removeCallbacks(ticker);
            ui.postDelayed(ticker, 900L);
        }
    }

    /**
     * 进度不是瞎走：应用自己探端口，所以这条时间线是真的 ——
     *   发出启动指令 → 等 Termux 起来 → 等 DSH 引导完（端口响应）→ 就绪
     * 时间轴按实测约 18 秒走到 85%，端口一通就直接 100% 并打开界面。
     */
    private final Runnable ticker = new Runnable() {
        @Override public void run() {
            if (!booting || web == null || ui == null) return;
            final long el = System.currentTimeMillis() - loadT0;
            new Thread(new Runnable() {
                @Override public void run() {
                    if (ui == null) return;
                    if (Termux.ping()) {
                        ui.post(new Runnable() { @Override public void run() {
                            injectProgress(100, "正在打开界面…");
                            booting = false;
                            if (ui != null) ui.removeCallbacks(ticker);
                            dlog("PING_UP -> loadUrl");
                            ui.postDelayed(new Runnable() { @Override public void run() {
                                if (web != null) web.loadUrl(ENTRY);
                            }}, 280L);
                        }});
                    } else {
                        int pct = (int) Math.min(85, 8 + el / 18000.0 * 77);
                        String txt = (el < 3000) ? "正在唤醒 Termux…"
                                   : (el < 10000) ? "正在引导 DSH 服务…"
                                   : (el < 25000) ? "稍等，正在等端口响应…"
                                   : "仍在尝试，请稍候…";
                        if (!lastDownLogged) { lastDownLogged = true; dlog("PING_DOWN el=" + (el / 1000) + "s"); }
                        injectProgress(pct, txt);
                        ui.postDelayed(ticker, 1200L);
                    }
                }
            }).start();
        }
    };

    /** 应用侧诊断日志：通过 Termux 写进 ~/.dsh/run/app.log，从外部可读。 */
    private void dlog(String msg) {
        try {
            Termux.run(this, "dsh-applog", new String[]{msg}, "applog");
        } catch (Exception e) {}
    }

    private static String shortUrl(String u) {
        if (u == null) return "null";
        String s = u.replaceAll("token=[A-Za-z0-9_-]+", "token=***");
        return s.length() > 70 ? s.substring(0, 70) + "\u2026" : s;
    }

    private void injectProgress(int pct, String text) {
        try {
            if (web == null) return;
            web.evaluateJavascript("window.__dshProgress&&window.__dshProgress("
                    + pct + "," + JSONObject.quote(text) + ")", null);
        } catch (Exception e) {}
    }

    /** 等待页期间把 WebView 与系统栏都刷白，避免出现"深色矩形没铺满"的观感 */
    private void applyLoadingChrome() {
        try {
            loadingChrome = true;
            web.setBackgroundColor(Color.WHITE);
            getWindow().getDecorView().setBackgroundColor(Color.WHITE);
            applyBarColors(Color.WHITE);
        } catch (Exception e) {}
    }

    /** 状态栏与导航栏统一配色，并按亮度切换图标深浅 —— 页面与系统栏无色差，就没有"矩形边" */
    private void applyBarColors(int color) {
        try {
            getWindow().setStatusBarColor(color);
            getWindow().setNavigationBarColor(color);
            if (Build.VERSION.SDK_INT >= 26) {
                int f = getWindow().getDecorView().getSystemUiVisibility();
                if (isLightColor(color)) f = f | 0x10 | 0x2000;      /* LIGHT_NAVIGATION_BAR | LIGHT_STATUS_BAR */
                else f = f & ~0x10 & ~0x2000;
                getWindow().getDecorView().setSystemUiVisibility(f);
            }
        } catch (Exception e) {}
    }

    private static boolean isLightColor(int c) {
        double l = (0.299 * Color.red(c) + 0.587 * Color.green(c) + 0.114 * Color.blue(c)) / 255.0;
        return l > 0.6;
    }

    /** 界面加载完成：恢复系统栏，并把 WebView 底色对齐页面真实底色（亮/暗主题都对） */
    private void restoreChrome(boolean wasLoading) {
        try {
            if (loadingChrome) {
                loadingChrome = false;
                getWindow().getDecorView().setBackgroundColor(Color.WHITE);
                applyBarColors(Color.WHITE);
            }
            if (web == null) return;
            web.evaluateJavascript(
                "(function(){try{return getComputedStyle(document.body).backgroundColor||''}catch(e){return ''}})()",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String v) {
                        try {
                            if (v == null) return;
                            String t = v.replace("\"", "").trim();
                            int[] rgb = parseRgb(t);
                            if (rgb != null) {
                                int c = Color.rgb(rgb[0], rgb[1], rgb[2]);
                                web.setBackgroundColor(c);
                                applyBarColors(c);      /* 状态栏/导航栏跟随页面底色 */
                            }
                        } catch (Exception e) {}
                    }
                });
        } catch (Exception e) {}
    }

    private static int[] parseRgb(String css) {
        try {
            if (css == null || css.indexOf("rgb") < 0) return null;
            int a = css.indexOf('('), b = css.indexOf(')');
            if (a < 0 || b < 0) return null;
            String[] parts = css.substring(a + 1, b).split(",");
            if (parts.length < 3) return null;
            return new int[]{
                Integer.parseInt(parts[0].trim()),
                Integer.parseInt(parts[1].trim()),
                Integer.parseInt(parts[2].trim())
            };
        } catch (Exception e) { return null; }
    }

    private String readRaw(int id) {
        try {
            java.io.InputStream in = getResources().openRawResource(id);
            java.io.ByteArrayOutputStream bos = new java.io.ByteArrayOutputStream();
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) > 0) bos.write(buf, 0, n);
            in.close();
            return new String(bos.toByteArray(), "UTF-8");
        } catch (Exception e) { return ""; }
    }

    /** ★ 2026-09-16 用户反馈：**系统的返回手势**（边缘右划）不管在哪个界面都直接回桌面。
     *  原因：这里只判了 web.canGoBack()，而 DSH 是单页应用、历史栈基本为空 ⇒ 永远走到 super（退出）。
     *  改法：**先问网页**（`window.__dshBack()`，由 dsh-mobile-adapt 提供：余额页/设置页/左侧栏/弹层
     *  依次关掉），网页说"我消化了"就什么都不做；否则再退回历史；最后才退出（并停服务，维持原设计）。 */
    @Override
    public void onBackPressed() {
        if (web == null) { super.onBackPressed(); return; }
        try {
            web.evaluateJavascript(
                "(function(){try{return (window.__dshBack && window.__dshBack()) ? '1' : '0';}catch(e){return '0';}})()",
                new ValueCallback<String>() {
                    @Override
                    public void onReceiveValue(String v) {
                        try {
                            if (v != null && v.indexOf('1') >= 0) return;          /* 网页关掉了一层，不退出 */
                        } catch (Exception e) {}
                        if (web.canGoBack()) web.goBack();
                        else MainActivity.super.onBackPressed();
                    }
                });
        } catch (Exception e) {
            try { if (web.canGoBack()) { web.goBack(); return; } } catch (Exception e2) {}
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        try { if (repairRx != null) unregisterReceiver(repairRx); } catch (Exception e) {}
        /* 按返回键真正退出应用：不留宽限，立刻停止 Termux 侧服务 */
        if (isFinishing()) {
            Alarm.cancel(this);
            try {
                startService(new Intent(this, LifecycleService.class).setAction(LifecycleService.ACTION_STOP));
            } catch (Exception e) {}
        }
        if (installReceiver != null) { try { unregisterReceiver(installReceiver); } catch (Exception e) {} }
        if (web != null) web.destroy();
        super.onDestroy();
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        if (req == REQ_FILE_CHOOSER) {
            Uri[] out = null;
            if (res == RESULT_OK && data != null) {
                if (data.getData() != null) {
                    out = new Uri[]{ data.getData() };
                } else if (data.getClipData() != null) {
                    int n = data.getClipData().getItemCount();
                    out = new Uri[n];
                    for (int i = 0; i < n; i++) out[i] = data.getClipData().getItemAt(i).getUri();
                }
            }
            if (fileCb != null) { try { fileCb.onReceiveValue(out); } catch (Exception e) {} fileCb = null; }
            return;
        }
        super.onActivityResult(req, res, data);
    }
}
