#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
publish.py —— 把发布物上传到 GitHub（电脑端用，标准库，零依赖）

设计要点（对应 2026-09-19 的教训）：
  · 只读 manifest.json，**不在脚本里重写一遍文件名/校验值** ——
    本项目踩过"同一判据在多处各写一遍"的坑（手册第 6 节第 23 条）。
  · 先校验本地文件 sha256，不符就拒绝上传（防止把坏文件传上去）。
  · Release 附件用 uploads.github.com，主干文件用 contents API，
    两种通道都是官方接口，不需要 git、不需要装任何东西。
  · 幂等：Release 已存在就复用；文件已存在就更新（覆盖），不会重复堆积。

用法：
    # 1) 准备令牌（细粒度、只勾本仓库的 Contents: Read and write 即可）
    #    Windows PowerShell:  $env:GITHUB_TOKEN="github_pat_xxx"
    #    macOS/Linux:         export GITHUB_TOKEN=github_pat_xxx
    #    或把令牌写进同目录的 .github-token 文件
    # 2) 干跑（只看要做什么，不联网）：
    python publish.py --dry-run
    # 3) 真传：
    python publish.py

可选参数：
    --repo user/name    覆盖仓库（默认读 manifest.json）
    --tag  v20260919    覆盖 Release tag
    --ref  main         覆盖分支
"""
import json
import os
import sys
import hashlib
import base64
import urllib.request
import urllib.error
import urllib.parse

HERE = os.path.dirname(os.path.abspath(__file__))
LOCAL_VER = "?"   # 由 main() 从 manifest 填入，供对比显示用
API = "https://api.github.com"
UPLOADS = "https://uploads.github.com"


def die(msg, hint=""):
    sys.stderr.write("\n❌ %s\n" % msg)
    if hint:
        sys.stderr.write("   %s\n" % hint)
    sys.exit(1)


def sha256_of(path):
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


def human(n):
    for unit in ("B", "KB", "MB", "GB"):
        if n < 1024 or unit == "GB":
            return "%.1f %s" % (n, unit)
        n /= 1024.0


def load_manifest():
    p = os.path.join(HERE, "manifest.json")
    if not os.path.isfile(p):
        die("找不到 manifest.json", "这个脚本必须和 manifest.json 放在同一个目录里")
    with open(p, encoding="utf-8") as f:
        return json.load(f)


def get_token():
    t = os.environ.get("GITHUB_TOKEN") or os.environ.get("GH_TOKEN")
    if t:
        return t.strip()
    p = os.path.join(HERE, ".github-token")
    if os.path.isfile(p):
        with open(p, encoding="utf-8") as f:
            return f.read().strip()
    die("没有 GitHub 令牌",
        "设置环境变量 GITHUB_TOKEN，或把令牌写进同目录的 .github-token 文件")


def req(method, url, token, data=None, ctype="application/json", extra=None):
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
        "User-Agent": "dsh-mobile-publish",
    }
    if ctype:
        headers["Content-Type"] = ctype
    if extra:
        headers.update(extra)
    # ★ 无令牌也允许（只读公开仓库用；上传路径一定会先经过 get_token()）
    if token:
        headers["Authorization"] = "Bearer %s" % token
    r = urllib.request.Request(url, data=data, headers=headers, method=method)
    try:
        with urllib.request.urlopen(r, timeout=180) as resp:
            body = resp.read()
            return resp.status, (json.loads(body) if body else None)
    except urllib.error.HTTPError as e:
        body = e.read().decode("utf-8", "replace")
        return e.code, body
    except urllib.error.URLError as e:
        return 0, str(e)


def compare_with_repo(repo, ref):
    """对比「本包」与「仓库里已有的版本」——用户要求电脑做的第一件事。

    判据**只用版本号**，不靠文件名猜：
      · dsh-version.json  —— APK 的 versionCode / versionName（页面内更新读的就是它）
      · dsh-manifest.json —— 载荷版本、各文件、直链（随包发布，供以后核对）
    没有令牌也能读（仓库是公开的）；读不到就说明还没发布过 ⇒ 视为"首次上传"。
    只读、不写；干跑模式也会跑这一步。
    """
    print("⓪ 对比：本包 vs 仓库里已有的版本")
    base = "%s/repos/%s/contents" % (API, repo)
    out = {"apk": None, "manifest": None, "reachable": False}

    def get(name):
        st, body = req("GET", "%s/%s?ref=%s" % (base, name, ref), None)
        if st == 200 and isinstance(body, dict) and body.get("content"):
            try:
                import base64 as _b64
                return json.loads(_b64.b64decode(body["content"]).decode("utf-8"))
            except Exception:
                return None
        return None

    ver = get("dsh-version.json")
    man = get("dsh-manifest.json")
    if ver is None and man is None:
        print("   仓库里还没有版本信息文件 ⇒ 视为**首次上传**（没有可覆盖的旧版）")
        print()
        return out
    out["reachable"] = True
    out["apk"] = ver
    out["manifest"] = man
    if ver:
        print("   仓库里已有 APK：v%s（versionCode %s）"
              % (ver.get("versionName", "?"), ver.get("versionCode", "?")))
    if man:
        v = (man.get("versions") or {})
        print("   仓库里已有载荷：%s（本包：%s）" % (v.get("payload", "?"), LOCAL_VER))
    print("   （完整差异由校验步骤后的判定给出）")
    print()
    return out


def main():
    dry = "--dry-run" in sys.argv
    m = load_manifest()
    global LOCAL_VER
    LOCAL_VER = (m.get("versions") or {}).get("payload", "?")
    repo = m["repo"]
    ref = m.get("ref", "main")
    tag = m.get("tag", "")

    for i, a in enumerate(sys.argv):
        if a == "--repo" and i + 1 < len(sys.argv):
            repo = sys.argv[i + 1]
        if a == "--ref" and i + 1 < len(sys.argv):
            ref = sys.argv[i + 1]
        if a == "--tag" and i + 1 < len(sys.argv):
            tag = sys.argv[i + 1]

    print("=" * 62)
    print(" DshShell 发布上传")
    print("=" * 62)
    print("  仓库   : %s" % repo)
    print("  分支   : %s" % ref)
    print("  Release: %s" % tag)
    print("  本包   : 载荷 %s / APK v%s(code %s) / DSH %s"
          % (m.get("versions", {}).get("payload", "?"),
             m.get("versions", {}).get("apk_versionName", "?"),
             m.get("versions", {}).get("apk_versionCode", "?"),
             m.get("versions", {}).get("dsh_version", "?")))
    print("  模式   : %s" % ("干跑（不联网、不写入）" if dry else "真传"))
    print()

    # ---- 0) 对比：本包 vs 仓库里已有的版本（用户要求的第一件事）----
    #   判据用 dsh-version.json / dsh-manifest.json 里的版本号，**不靠文件名猜**。
    #   干跑模式也做这一步（要联网读取，但不写任何东西），这样上传前就能确认"确实是新版"。
    remote = compare_with_repo(repo, ref)

    # ---- 1) 先校验本地文件 ----
    print("① 校验本地文件完整性")
    plan = []
    allok = True
    for item in m["files"]:
        path = os.path.join(HERE, item["local"])
        if not os.path.isfile(path):
            print("   ❌ 缺文件: %s" % item["local"])
            allok = False
            continue
        got = sha256_of(path)
        size = os.path.getsize(path)
        if got != item["sha256"]:
            print("   ❌ 校验不符: %s" % item["local"])
            print("      期望 %s" % item["sha256"])
            print("      实测 %s" % got)
            allok = False
            continue
        print("   ✅ %-46s %s" % (item["local"], human(size)))
        plan.append((item, path))
    if not allok:
        die("本地文件校验未通过，已终止（一个字节都不上传）")
    print()

    # ---- 1b) 版本判定：确认"这确实是新版本"（用户要求）----
    #   判据：APK versionCode 比仓库里的大 ⇒ 是新版；载荷日期比仓库里的新 ⇒ 是新版。
    #   **只提示、不拦截**：紧急修复时可能故意重发同一版本（例如重传坏了的口）。
    lv = m.get("versions") or {}
    verdicts = []
    rv = (remote.get("apk") or {})
    if rv.get("versionCode") is not None and lv.get("apk_versionCode"):
        try:
            a, b = int(lv["apk_versionCode"]), int(rv["versionCode"])
            if a > b:
                verdicts.append(("ok", "APK 更新：仓库 v%s(%s) → 本包 v%s(%s)"
                                 % (rv.get("versionName"), rv.get("versionCode"),
                                    lv.get("apk_versionName"), lv.get("apk_versionCode"))))
            elif a == b:
                verdicts.append(("same", "APK 与仓库**相同版本**（v%s/code %s）—— 只在重传修复时才该这样"
                                 % (lv.get("apk_versionName"), a)))
            else:
                verdicts.append(("warn", "APK **比仓库旧**（仓库 code %s，本包 code %s）—— 确认是不是传错了包"
                                 % (rv.get("versionCode"), a)))
        except Exception:
            pass
    rm = ((remote.get("manifest") or {}).get("versions") or {})
    if rm.get("payload") and lv.get("payload"):
        if str(lv["payload"]) > str(rm["payload"]):
            verdicts.append(("ok", "载荷更新：仓库 %s → 本包 %s" % (rm["payload"], lv["payload"])))
        elif str(lv["payload"]) == str(rm["payload"]):
            verdicts.append(("same", "载荷与仓库**相同版本**（%s）" % lv["payload"]))
        else:
            verdicts.append(("warn", "载荷**比仓库旧**（仓库 %s，本包 %s）" % (rm["payload"], lv["payload"])))
    if not remote.get("reachable"):
        verdicts.append(("ok", "首次上传：仓库里没有版本信息，本包即最新"))
    if verdicts:
        print("①b 版本判定")
        for kind, msg in verdicts:
            mark = {"ok": "✅", "same": "⚠️ ", "warn": "❌"}.get(kind, "  ")
            print("   %s %s" % (mark, msg))
        if any(k == "warn" for k, _ in verdicts):
            print("       ⇒ 与本意不符就中止。确实要发就在下一步确认。")
        print()

    # ---- 2) 分类 ----
    # ★ 一个文件可以有多个去向（例如 Termux APK：既进仓库主干供直链下载，又做 Release 附件）。
    #   用 targets 数组表示；仍然兼容旧的单 target 写法。
    def _targets(i):
        if "targets" in i:
            return set(i["targets"])
        return {i.get("target", "repo")}
    release_files = [(i, p) for i, p in plan if "release" in _targets(i)]
    repo_files = [(i, p) for i, p in plan if "repo" in _targets(i)]

    if dry:
        print("② 将要执行的动作（干跑，未联网）")
        for item, path in repo_files:
            print("   · 上传到仓库 %s 分支：%s → %s"
                  % (ref, item["local"], item.get("remote", item["local"])))
        if release_files:
            print("   · 创建/复用 Release「%s」并附加 %d 个附件：" % (tag, len(release_files)))
            for item, path in release_files:
                print("       - %s（%s）" % (item["local"], human(os.path.getsize(path))))
        print()
        print("干跑结束。去掉 --dry-run 即真传。")
        return

    token = get_token()

    # ---- 3) Release（存在则复用）----
    rel = None
    if release_files:
        print("② 准备 Release「%s」" % tag)
        st, body = req("GET", "%s/repos/%s/releases/tags/%s" % (API, repo, tag), token)
        if st == 200 and isinstance(body, dict):
            rel = body
            print("   已存在，复用（id=%s，现有附件 %d 个）" % (rel["id"], len(rel.get("assets", []))))
        else:
            payload = json.dumps({
                "tag_name": tag,
                "name": tag,
                "body": m.get("release_notes", "DshShell 移动端发布包"),
                "draft": False,
                "prerelease": False,
            }).encode("utf-8")
            st, body = req("POST", "%s/repos/%s/releases" % (API, repo), token, payload)
            if st not in (200, 201):
                die("创建 Release 失败（HTTP %s）" % st, str(body)[:400])
            rel = body
            print("   已创建（id=%s）" % rel["id"])
        print()

    # ---- 4) 传 Release 附件 ----
    if release_files:
        print("③ 上传 Release 附件")
        existing = {a["name"]: a for a in rel.get("assets", [])}
        for item, path in release_files:
            name = os.path.basename(item["local"])
            size = os.path.getsize(path)
            if name in existing:
                # 幂等：先删旧的再传新的（同名附件不能直接覆盖）
                st, _ = req("DELETE", "%s/repos/%s/releases/assets/%s"
                            % (API, repo, existing[name]["id"]), token)
                print("   · 同名附件已存在，先删除旧的（HTTP %s）" % st)
            with open(path, "rb") as f:
                data = f.read()
            url = "%s/repos/%s/releases/%s/assets?name=%s" % (UPLOADS, repo, rel["id"], name)
            print("   ↑ %s（%s）…" % (name, human(size)))
            st, body = req("POST", url, token, data,
                           ctype="application/octet-stream")
            if st in (200, 201):
                print("     ✅ 完成")
            else:
                die("上传 %s 失败（HTTP %s）" % (name, st), str(body)[:400])
        print()

    # ---- 5) 传仓库主干文件 ----
    if repo_files:
        print("④ 上传仓库主干文件（分支 %s）" % ref)
        for item, path in repo_files:
            remote = item.get("remote", item["local"])
            size = os.path.getsize(path)
            api_url = "%s/repos/%s/contents/%s" % (API, repo, urllib.parse.quote(remote))
            # 取现有 sha（用于更新而不是冲突）
            st, body = req("GET", "%s?ref=%s" % (api_url, ref), token)
            sha_existing = body.get("sha") if (st == 200 and isinstance(body, dict)) else None
            with open(path, "rb") as f:
                content = base64.b64encode(f.read()).decode("ascii")
            payload = {
                "message": item.get("message", "update %s" % remote),
                "content": content,
                "branch": ref,
            }
            if sha_existing:
                payload["sha"] = sha_existing
            st, body = req("PUT", api_url, token, json.dumps(payload).encode("utf-8"))
            if st in (200, 201):
                print("   ✅ %s → %s（%s）" % (item["local"], remote, human(size)))
            else:
                die("上传 %s 失败（HTTP %s）" % (remote, st), str(body)[:400])
        print()

    print("=" * 62)
    print(" 全部完成")
    print("=" * 62)
    print()
    print("接下来请把「验收步骤.txt」里的链接在浏览器里点一遍，确认能下（应返回 200），")
    print("然后把结果告诉手机端 —— 手机端会实跑一次接收方安装验收。")


if __name__ == "__main__":
    main()
