#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  make-bundle.sh —— 把「电脑端要上传的一切」打成一个压缩包
#
#  用户要求（2026-09-19）：手机生成一个包，自己传给电脑，电脑解压后即可解析并上传。
#  ⇒ 所以这个包必须**自解释**：解压就有 manifest.json（机器读）+ 说明（人读）+ 上传脚本。
#
#  前置：先跑 tools/make-release.sh（它负责出 dsh-mobile-<日期>.tar.gz 与 发布直链.txt）
#
#  产物：<出包目录>/DshShell-发布包-<日期>.tar.gz  （唯一需要传给电脑的文件）
#
#  用法：
#    bash tools/make-bundle.sh
#    bash tools/make-bundle.sh --no-release   # 不重跑出包，直接用现有产物
# ============================================================
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${DSHM_DIST:-/storage/emulated/0/Download/DSH分发包}"; mkdir -p "$OUT"
VER="$(date +%Y%m%d)"
NAME="dsh-mobile-$VER"
BUNDLE="DshShell-发布包-$VER"
REPO="${REPO:-18477514055/DeepseekHarness-mobile}"
REF="${REF:-main}"
TAG="${TAG:-v$VER}"
STAGING="$HOME/dsh-backup/apk-staging"

ok()   { printf '\033[32m%s\033[0m\n' "$*"; }
info() { printf '  %s\n' "$*"; }
warn() { printf '\033[33m%s\033[0m\n' "$*"; }
die()  { printf '\033[31m❌ %s\033[0m\n' "$*" >&2; exit 1; }

# 受管 APK（与 lib/fetch-apk.sh、发布直链.txt 三处必须一致；出包时会交叉核对）
T_TERMUX="termux-app_v0.118.3+github-debug_arm64-v8a.apk"
S_TERMUX="72fdb596045116bf5ba1b5bdf5b26fddb9acc0bd074ad9f2da9eb0ae85e83a4e"
T_API="termux-api-app_v0.53.0+github.debug.apk"
S_API="ecf916ff80ae751e65c092f51c055cce4de417ebeea8e449cd0f294afdbde39a"

NO_RELEASE=0
[ "${1:-}" = "--no-release" ] && NO_RELEASE=1

echo "════════ 打「给电脑端」的单包 ════════"

# ---------- 1) 确保发布产物存在 ----------
if [ "$NO_RELEASE" = 0 ]; then
  info "先跑一次出包（tools/make-release.sh）…"
  bash "$ROOT/tools/make-release.sh" >/dev/null 2>&1 || die "出包失败，先单独跑 tools/make-release.sh 看错误"
fi

TARBALL="$OUT/$NAME.tar.gz"
LOADER="$OUT/一键安装.sh"
[ -f "$TARBALL" ] || die "找不到 $TARBALL（先跑 tools/make-release.sh）"
[ -f "$LOADER" ]    || die "找不到 $LOADER（先跑 tools/make-release.sh）"

# ---------- 2) 暂存目录 ----------
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
D="$STAGE/$BUNDLE"
mkdir -p "$D"

# ---------- 3) 收文件 ----------
info "收集文件…"
cp -a "$TARBALL" "$D/"
S_TARBALL=$(sha256sum "$D/$NAME.tar.gz" | cut -d' ' -f1)

# 一键脚本改名为 bootstrap.sh 再传：中文名在 URL 里要转义，容易出错
cp -a "$LOADER" "$D/bootstrap.sh"

for pair in "$T_TERMUX:$S_TERMUX" "$T_API:$S_API"; do
  f="${pair%%:*}"; want="${pair##*:}"
  src=""
  for c in "$STAGING/$f" "$OUT/$f" "/storage/emulated/0/Download/$f" "/storage/emulated/0/Download/DSH分发包/$f"; do
    [ -f "$c" ] && { src="$c"; break; }
  done
  [ -n "$src" ] || die "找不到 $f（权威暂存处：$STAGING）"
  got=$(sha256sum "$src" | cut -d' ' -f1)
  [ "$got" = "$want" ] || die "$f 校验不符！期望 $want 实测 $got"
  cp -a "$src" "$D/"
  info "$f ✓"
done

# ★ 2026-09-20 用户要求的"第 3 个资源"：客户端更新包（dsh-update.apk）。
#   它就是「检查更新」下载的那个文件；进主干后 Release 页也能看到它，且有直链。
DSH_DIST="$PREFIX/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-web-frontend/dist"
if [ -f "$DSH_DIST/dsh-update.apk" ]; then
  cp -a "$DSH_DIST/dsh-update.apk" "$D/dsh-update.apk"
  info "dsh-update.apk 已收进包（$(stat -c %s "$D/dsh-update.apk") 字节）"
fi
[ -f "$DSH_DIST/dsh-version.json" ] && cp -a "$DSH_DIST/dsh-version.json" "$D/dsh-version.json"

# ★ 2026-09-20 用户澄清的"三个资源"补全：
#   ② 源码包（给开发者）—— 与"载荷包"不同：那是部署产物，这是源码
#   ③ 一键更新脚本（给老用户）—— 先比对版本，避免白下
SRC_PKG="$OUT/dsh-mobile-src-$VER.tar.gz"
# 没现成的就顺手生成一个（避免忘记跑 make-source.sh 导致包里缺源码）
if [ ! -f "$SRC_PKG" ]; then
  info "源码包不存在，先跑 tools/make-source.sh…"
  bash "$ROOT/tools/make-source.sh" >/dev/null 2>&1 || warn "源码包生成失败（跳过）"
fi
if [ -f "$SRC_PKG" ]; then
  cp -a "$SRC_PKG" "$D/"
  info "源码包已收进包"
else
  warn "没有源码包（先跑 tools/make-source.sh）"
fi
# 更新脚本：替换仓库占位符后放进包（用户粘的那条命令就是它）
if [ -f "$ROOT/update.sh" ]; then
  sed "s|__REPO__|$REPO|; s|__REF__|$REF|" "$ROOT/update.sh" > "$D/update.sh"
  chmod +x "$D/update.sh"
  info "一键更新脚本已收进包（占位符已替换）"
fi

# 上传脚本 + 直链清单（给电脑端参考）
cp -a "$ROOT/tools/publish.py" "$D/publish.py"

# ★ 接收方说明：随包一起给出去，接收方解压就能看（2026-09-19 两路线版）
[ -f "$ROOT/docs/接收方安装说明-两路线.txt" ] && \
  cp -a "$ROOT/docs/接收方安装说明-两路线.txt" "$D/接收方安装说明.txt"

# 引导页：给接收方的那个「一条链接」页面，传到仓库根目录后即可分享
[ -f "$ROOT/web/index.html" ] && cp -a "$ROOT/web/index.html" "$D/install.html"
[ -f "$OUT/发布直链.txt" ] && cp -a "$OUT/发布直链.txt" "$D/"

# ---------- 4) manifest.json（机器读，唯一事实来源）----------
info "生成 manifest.json…"
# 取 APK 版本与 DSH 版本（供电脑端"对比新包与仓库里的包"）
APK_MANIFEST="$HOME/dsh-backup/apk-build/DshShell/AndroidManifest.xml"
APK_VC=$(grep -o 'android:versionCode="[0-9]*"' "$APK_MANIFEST" 2>/dev/null | grep -o '[0-9]*' | head -1)
APK_VN=$(grep -o 'android:versionName="[^"]*"' "$APK_MANIFEST" 2>/dev/null | sed 's/.*="//;s/"//' | head -1)
DSH_VER=$(node "$PREFIX/lib/node_modules/@deepseek-ai/dsh/lib/bin.js" --version 2>/dev/null | tr -d '\r\n' | head -c 40)
[ -z "$DSH_VER" ] && DSH_VER="unknown"
info "APK v${APK_VN:-?} / code ${APK_VC:-?}  ·  DSH ${DSH_VER}"
# ★ Release 说明：发布到 GitHub Release 页面正文，指导用户"该下哪个、它是干什么的"。
#   用户要求：在说明底部把这几个资源列出来并分别注明用途。
cat > "$D/Release说明.md" <<'NOTES'
# DshShell 发布包 %V%

> 手机端 DSH 的一键部署包。**不需要翻墙、不需要电脑**，约 5～15 分钟。

---

## 第一次安装（新用户）

1. 先装 **Termux 本体** —— 它是**绝对依赖**，没有它什么都跑不起来（见下方附件 ①）。
2. 再在 Termux 里粘一条命令，其余全自动：

```bash
bash <(curl -fsSL 'https://gh-proxy.com/https://raw.githubusercontent.com/%R%/%F%/bootstrap.sh')
```

命令跑起来后会问你一次：**浏览器模式**（最省事，回车即可）还是**本机 APK 版**（多一个桌面图标，多花 1~3 分钟）。

完整图文说明：<https://gh-proxy.com/https://raw.githubusercontent.com/%R%/%F%/install.html>

---

## 已经装过的老用户（更新）

**不要重新装一遍。** 老用户有两种更新，各管一块，建议都做：

**① 客户端（DshShell 本身）** —— 在页面里点「**检查更新**」，或下载附件 ⑤ 直接安装覆盖。

**② 服务端 / 适配 / 运维脚本** —— 在 Termux 里粘这一条（附件 ③ 就是它）：

```bash
bash <(curl -fsSL 'https://gh-proxy.com/https://raw.githubusercontent.com/%R%/%F%/update.sh')
```

它会**先比对版本**：已是最新就直接告诉你，不会白下。

---

## 本页附件说明

| 附件 | 是什么 | 你该不该下 |
|---|---|---|
| ① **Termux 本体 APK** | **绝对依赖**。安卓上必须先有它才能运行 DSH；与 Termux:API 必须同签名 | **所有新用户都要下**；老用户已装过则不用 |
| ② **完整工程文件（源码）** `dsh-mobile-src-*.tar.gz` | **给开发者**：本工程的源码（安装器模块、插件、APK 壳源码、运维命令、文档）。可读、可改、可自己构建 | 只想**用**的人不用下；想**改代码/自己构建**的人下 |
| ③ **一键更新脚本** `update.sh` | **给老用户**：在 Termux 里跑它即可更新服务端与适配层；会**先比对版本**，已是最新就不重复下载 | 老用户**推荐**；新用户用不到（首次部署用下面的命令） |
| ④ **用户说明** `给用户-部署说明.txt` | 从零装好、以后怎么更新的完整说明 | 建议都看一眼 |
| ⑤ **客户端更新包** `dsh-update.apk` | DshShell 客户端本身的新版本（约 45KB） | **给老用户**：下载后直接点开安装即可覆盖旧版 |

> 注：Release 页这个列表里的东西，一部分同时也在仓库主干里（可直接下，不必翻 Release 页）。

## 校验值（下载后可选核对）

```
SHA256 见本包内 APK-CHECKSUMS.txt / 发布直链.txt
```

## 遇到问题

- 卡住/报错：**再跑一次那条命令**。安装器是幂等的，不会重复安装，还会自检指出问题。
- 界面坏了想退回官方原生界面（保底）：
  ```bash
  dsh-mobile-safe-mode on     # 然后刷新页面
  ```
- 提示签名冲突：你装过 Play 版或 F-Droid 版 Termux，需先卸载（它们签名不同）。
NOTES
# 用 sed 直接替换（@ 做分隔符：避开路径里的 / 与花括号语法歧义）
sed -i "s|%R%|$REPO|g; s|%F%|$REF|g; s|%V%|$VER|g" "$D/Release说明.md"
# 替换后自检：不该再有 @X@ 残留
if grep -q "%R%\|%F%\|%V%" "$D/Release说明.md"; then
  die "Release说明.md 里有未替换的占位符"
fi

python3 - "$D" "$VER" "$REPO" "$REF" "$TAG" "$APK_VC" "$APK_VN" "$DSH_VER" <<'PYEOF'
import json, os, sys, hashlib
d, ver, repo, ref, tag = sys.argv[1:6]
apk_vc, apk_vn, dsh_ver = (sys.argv[6:9] + ["", "", ""])[:3]

def sha(p):
    h = hashlib.sha256()
    with open(p, "rb") as f:
        for c in iter(lambda: f.read(1 << 20), b""):
            h.update(c)
    return h.hexdigest()

name = "dsh-mobile-%s.tar.gz" % ver
files = [
    {"local": name, "sha256": sha(os.path.join(d, name)), "targets": ["repo", "release"],
     "remote": name, "message": "release %s payload" % ver,
     "note": "接收方一键脚本要下载的载荷包；也做 Release 附件（Release 说明里把它列为「完整更新包」）"},
    {"local": "bootstrap.sh", "sha256": sha(os.path.join(d, "bootstrap.sh")), "target": "repo",
     "remote": "bootstrap.sh", "message": "release %s bootstrap" % ver,
     "note": "接收方粘贴的那条命令所下载的引导脚本"},
]
# ★ 引导页也要传（它是给接收方的「一条链接」页面）。
#   加进 manifest 而不是只写进说明里 —— publish.py 只认 manifest，
#   漏了它就会出现"说明里让传、脚本却没传"的不一致（本项目踩过这类两处判据的坑）。
if os.path.isfile(os.path.join(d, "install.html")):
    files.append({"local": "install.html", "sha256": sha(os.path.join(d, "install.html")),
                  "target": "repo", "remote": "install.html",
                  "message": "release %s landing page" % ver,
                  "note": "给接收方的引导页（一条链接打开就是四个步骤）"})
# ★ 2026-09-20 用户要求：两个 APK **同时**进仓库主干 + Release 附件。
#   原因（用户原话）："把仓库中的 termux 单独拉出来，这样子的话，用户可以直接从仓库中下载这个软件，
#   而不用再解压。"
#   现状核对：以前只在 Release 附件里 ⇒ 用户必须点进 Releases 页再挑附件，手机上很麻烦。
#   放进主干后就是一条 raw 直链，点一下就下。
#   ★ 代价：33.5MB 的文件进 git 仓库（GitHub 允许，<100MB）。两个都放，用户更省事。
#   ★ 用 targets 数组（一个文件两个去向），避免 manifest 里出现重复条目。
# ★ 用户 2026-09-20 定的最终分工：
#   · Termux 本体（33.5MB，超网页 25MB 上限）→ **只放 Release**，用脚本/git 传；
#   · Termux:API（8.4MB）→ **进主干**（网页也能传）+ Release 附件（两个 APK 必须同签名）；
#   · 其余（载荷/引导脚本/引导页）→ 主干。
APKS = (
    # (文件名, targets, 说明)
    ("termux-app_v0.118.3+github-debug_arm64-v8a.apk", ["release"],
     "① Termux 本体（绝对依赖）—— 只放 Release：33.5MB 超过网页 25MB 上限，须用脚本或 git"),
    ("termux-api-app_v0.53.0+github.debug.apk", ["repo", "release"],
     "② Termux:API —— 进主干供直链下载，同时做 Release 附件（与 Termux 必须同签名）"),
)
# 客户端更新包：进主干（用户/Release 页都能直接下）
#   ★ dsh-update.apk 同时做 Release 附件 —— 用户要求 Release 说明里列的「第 3 个资源」
#     能在本页直接下到（否则说明里列了、页面上却没有）。
for f, tg, n in (("dsh-update.apk", ["repo", "release"],
                  "③ 客户端更新包：老用户下载后直接安装，或在页面点「检查更新」"),
                 ("dsh-version.json", ["repo"],
                  "客户端版本信息（「检查更新」读的就是它）")):
    p2 = os.path.join(d, f)
    if os.path.isfile(p2):
        files.append({"local": f, "sha256": sha(p2), "targets": tg, "remote": f,
                      "message": "update %s" % f, "note": n})

# 源码包 / 更新脚本 / 用户说明
_extra = [
    ("dsh-mobile-src-%s.tar.gz" % ver, ["repo", "release"],
     "② **完整工程文件（源码）** —— 给开发者：可读、可改、可自己构建。"
     "注意这不是部署包；部署包是 dsh-mobile-*.tar.gz"),
    ("update.sh", ["repo"],
     "③ 一键更新脚本（老用户）：在 Termux 里跑它即可更新，会先比对版本再决定下不下载"),
    ("给用户-部署说明.txt", ["release"],
     "④ 用户说明：怎么从零装好、以后怎么更新（可直接转发）"),
]
for f, tg, note in _extra:
    p3 = os.path.join(d, f)
    if os.path.isfile(p3):
        files.append({"local": f, "sha256": sha(p3), "targets": tg, "remote": f,
                      "message": "add %s" % f, "note": note})

for f, tg, note in APKS:
    p = os.path.join(d, f)
    if os.path.isfile(p):
        files.append({"local": f, "sha256": sha(p), "targets": tg,
                      "remote": f, "message": "add %s" % f, "note": note})

m = {
    "schema": "dsh-mobile-release/v1",
    "built_at": __import__("datetime").datetime.now().strftime("%F %T"),
    "repo": repo, "ref": ref, "tag": tag,
    # ★ 版本信息：让电脑端能"对比新包与仓库里的包"（用户要求的第一件事）
    "versions": {
        "payload": ver,
        "payload_file": name,
        "apk_versionCode": apk_vc,
        "apk_versionName": apk_vn,
        "dsh_version": dsh_ver,
    },
    "release_notes": (open(os.path.join(d, "Release说明.md"), encoding="utf-8").read()
                      if os.path.isfile(os.path.join(d, "Release说明.md")) else
                      "DshShell 移动端发布包 %s" % ver),
    "files": files,
    "install_entry": {
        "raw_url_template": "https://gh-proxy.com/https://raw.githubusercontent.com/%s/%s/bootstrap.sh" % (repo, ref),
        "raw_direct": "https://raw.githubusercontent.com/%s/%s/bootstrap.sh" % (repo, ref),
        "note": "接收方在 Termux 里跑的那条命令就是这个 URL（带国内加速前缀）"
    },
    "direct_download": {
        "termux_apk": "https://gh-proxy.com/https://raw.githubusercontent.com/%s/%s/termux-app_v0.118.3+github-debug_arm64-v8a.apk" % (repo, ref),
        "termux_api_apk": "https://gh-proxy.com/https://raw.githubusercontent.com/%s/%s/termux-api-app_v0.53.0+github.debug.apk" % (repo, ref),
        "note": "★ 给用户的直链：点一下就下，不用解压任何压缩包"
    },
    "verify": {
        "payload_sha256": sha(os.path.join(d, name)),
        "expected_channel": "github"
    }
}
with open(os.path.join(d, "manifest.json"), "w", encoding="utf-8") as f:
    json.dump(m, f, ensure_ascii=False, indent=2)
def _tg(x):
    return set(x["targets"]) if "targets" in x else {x.get("target", "repo")}
print("   条目 %d 个（repo %d / release %d）"
      % (len(files), sum(1 for x in files if "repo" in _tg(x)),
         sum(1 for x in files if "release" in _tg(x))))
PYEOF
[ -f "$D/manifest.json" ] || die "manifest.json 生成失败"
python3 -c "import json;json.load(open('$D/manifest.json',encoding='utf-8'));print('   manifest.json 可被解析 ✓')"

# ---------- 5) 两份人读报告（用户要求：一份给电脑、一份给用户，分开写）----------
# ① 给电脑端：做什么、怎么核对、怎么上传
cat > "$D/开始这里.txt" <<EOF
DshShell 发布上传包 —— 给【电脑端】
==========================================================
生成时间：$(date '+%F %T')
仓库     ：$REPO      分支：$REF      Release tag：$TAG
本包版本 ：载荷 $VER / APK v${APK_VN:-?}(code ${APK_VC:-?}) / DSH ${DSH_VER:-?}
==========================================================

你要做三件事。第 1、3 件脚本会自动帮你做。

━━━ 第 1 件：对比新包与仓库里的包，确认确实是新版本 ━━━
----------------------------------------------------------
   cd 解压出来的这个目录
   python publish.py --dry-run

它会：
   · 校验本目录每个文件的 sha256（不符就拒绝，一个字节都不传）
   · 联网读仓库里已有的 dsh-version.json / dsh-manifest.json，**对比版本号**
   · 打印判定：APK 是"更新 / 相同 / 比仓库旧"、载荷是"更新 / 相同 / 比仓库旧"
   · 只读、不写、不联网上传（可以看到全部动作）

★ 判据只用**版本号**，不靠文件名猜。若显示"比仓库旧"，先别传 —— 多半是拿错了包。
★ 仓库里没有版本信息文件时，会显示"首次上传"，这是正常的。

━━━ 第 2 件：把 Termux 安装包单独放进仓库主干 ━━━
----------------------------------------------------------
**为什么要做**：以前 Termux APK 只当 Release 附件，用户得点进 Releases 页再挑附件，
手机上很麻烦。放进主干后就是一条 raw 直链，用户**点一下就下，不用解压任何压缩包**。

**脚本会自动做**（manifest.json 里这两个文件的去向是 ["repo","release"]）：
     · $T_TERMUX   （33.5MB）
     · $T_API      （8.5MB）
   即：既传进仓库根目录（供直链），又做 Release 附件。

ℹ️ **关于 25MB 上限（说准确，别误解）**：
   GitHub **网页拖拽上传**的单文件上限是 **25MB**。本包各文件对照：

     ✅ 网页能传（< 25MB）：载荷 0.17MB · bootstrap.sh · install.html ·
                            dsh-update.apk · dsh-version.json · termux-api 8.44MB
     ❌ 网页传不了：termux-app APK **33.48MB**（超限）

   **但这不代表"主干放不了 Termux"** —— 它只是不能用网页那条路：
     · \`python publish.py\`（走 Contents API，上限约 100MB）→ ✅ 没问题
     · \`git push\`（硬上限 100MB）→ ✅ 没问题
   本项目的方案是：**Termux 只放 Release 附件**（不走主干，也用不着网页传主干）。

   最终分工（manifest.json 已按此写好，脚本自动照办）：
     仓库主干：dsh-mobile-*.tar.gz · bootstrap.sh · install.html ·
               dsh-update.apk · dsh-version.json · termux-api*.apk
     Release ：termux-app*.apk（绝对依赖）· dsh-mobile-*.tar.gz（完整更新包）·
               dsh-update.apk（客户端更新包）· termux-api*.apk

★ sha256 必须一致（比对上面那个 dry-run 的输出）：
     $T_TERMUX
       $S_TERMUX
     $T_API
       $S_API
   两个 APK 还必须**同签名**（证书 SHA-256 =
   b6da0148eefd5fbf2cd3771b8d1021ec791304bdd6c4bf41d3faabad48ee5e1），
   否则 termux-api 命令会静默失效。本包里这两份已经验真，别换成别处下的。

━━━ 第 3 件：上传 + 核对 ━━━
----------------------------------------------------------
**方式 B（推荐，脚本自动做完上面全部）**
   1) 申请细粒度令牌：GitHub → Settings → Developer settings →
      Personal access tokens → Fine-grained token
        · Repository access：只勾 $REPO
        · Permissions：Contents = Read and write
      （只影响这一个仓库，随时可撤）
   2) 在电脑上：
        cd 解压出来的这个目录
        python publish.py --dry-run     # 先看（含第 1 件的对比结论）
        python publish.py               # 确认无误后真传
      令牌怎么给（任选）：
        Windows PowerShell :  \$env:GITHUB_TOKEN="github_pat_xxx"
        macOS / Linux      :  export GITHUB_TOKEN=github_pat_xxx
        或写进本目录的 .github-token 文件
   脚本幂等：Release 已存在就复用，同名附件先删后传，不会重复堆积。

**方式 A（纯网页，注意 25MB 限制）**
   1) 把这三个文件拖进仓库根目录（main 分支）：
        · $NAME.tar.gz
        · bootstrap.sh
        · install.html
   2) Releases → Draft a new release，Tag 填 $TAG，附件传下面 4 个
      （对应 Release 说明里列的几项资源）：载荷 · dsh-update.apk · termux-app · termux-api。
   3) 主干里的 termux-api APK（8.44MB）网页可以传；
      **只有 33.48MB 的 termux-app 网页传不了** —— 而它按本方案**只放 Release**，
      所以网页路线也能走通（用上面那个附件传它）。

**传完核对**（电脑浏览器点一遍，应返回 200 而不是 404）：
   https://raw.githubusercontent.com/$REPO/$REF/bootstrap.sh
   https://gh-proxy.com/https://raw.githubusercontent.com/$REPO/$REF/install.html
   https://gh-proxy.com/https://raw.githubusercontent.com/$REPO/$REF/$T_TERMUX
   https://gh-proxy.com/https://raw.githubusercontent.com/$REPO/$REF/$NAME.tar.gz

★ 大文件刚传上去时 raw 可能短暂 404，等 1~2 分钟再点。

━━━ 做完之后：告诉手机端 ━━━
----------------------------------------------------------
手机会实跑一次「接收方」安装验收 —— 那是唯一能证明"一条链接就能装好"成立的测试。

━━━ 这一包里的文件 ━━━
----------------------------------------------------------
  manifest.json      机器读的清单（版本/文件名/sha256/去哪个位置），publish.py 只认它，
                     **不要手改**；改了会导致校验不符而拒绝上传
  publish.py         上传脚本（跨平台、干跑、校验、幂等）
  install.html       ★ 给用户的引导页（要传到仓库根目录）
  给用户-部署说明.txt  ★ 给用户的完整说明（可直接转发）
  bootstrap.sh       一键命令所下载的引导脚本
  $NAME.tar.gz   载荷包
  $T_TERMUX / $T_API  两个 APK
  发布直链.txt        候选下载源清单（核对用）
EOF

# ② 给用户：怎么从零装好、怎么以后更新
cat > "$D/给用户-部署说明.txt" <<EOF
DshShell 安装与更新说明
==========================================================
适用：安卓手机（arm64）· 不需要 VPN · 不需要电脑 · 约 5～15 分钟
==========================================================

【先说清一件事】
安装过程中有**一步必须你手动点**：装 Termux 本体（第一个 App）。
安卓不允许一个 App 偷偷装另一个 App，所以这一步谁也代劳不了。
除此之外，其余全部自动完成。


━━━ 第一步：装 Termux（点一下就好，不用解压任何东西）━━━
----------------------------------------------------------
用手机浏览器打开下面这个链接，**直接就是安装包**，点下载 → 点安装：

  Termux 本体：
  https://gh-proxy.com/https://raw.githubusercontent.com/$REPO/$REF/$T_TERMUX

  Termux:API（建议一起装，用于"检查更新"等；很小，8.5MB）：
  https://gh-proxy.com/https://raw.githubusercontent.com/$REPO/$REF/$T_API

系统会问「允许安装未知应用」→ 选**允许**。
★ 这两个包**签名同源**，必须都从上面这两个链接下，不要换成别处下载的
  （混用不同来源会导致命令静默失效）。
★ 如果上面链接打不开，去掉开头的 https://gh-proxy.com/ 再试（用官方原址）。

装好后**先别急着打开**，继续第二步。


━━━ 第二步：一条命令，剩下的全自动 ━━━
----------------------------------------------------------
打开 Termux，把下面这一整行粘进去（长按屏幕 → Paste），回车：

  bash <(curl -fsSL 'https://gh-proxy.com/https://raw.githubusercontent.com/$REPO/$REF/bootstrap.sh')

它一口气完成：
   · 下载安装包并校验完整性
   · 装依赖（nodejs / python / clang 等）
   · 给 DSH 打安卓修复补丁（这些是官方包在 Termux 上跑不起来的必要修复）
   · 编译原生模块、安装移动端适配插件
   · 启动服务

★ 中途会问你一次：

     「浏览器模式」还是「本机 APK 版」？

     · 直接回车 = 浏览器模式：最省事，装完用浏览器打开就能用。
     · 选「本机 APK 版」= 继续在本地把 DshShell 客户端也编译装好
       （多花 1~3 分钟；装好后有桌面图标，用起来更像一个正经 App）。

   拿不准就按回车。


━━━ 装完之后 ━━━
----------------------------------------------------------
终端会打印一个网址，形如：
   http://127.0.0.1:3080/?token=……

· 浏览器模式：用手机浏览器打开它，建议「添加到桌面」。
· 本机 APK 版：到「下载」里点开 DshShell.apk 安装，以后从桌面图标启动
  （首次打开会问「执行命令」权限 → 必须允许）。

**建议再做两件事**，否则小米/华为/OPPO 等系统会把后台任务掐断：
   1. 设置 → 应用 → Termux → 省电策略 → 选「无限制」
   2. 最近任务列表里给 Termux「加锁」（下拉那个小锁图标）


━━━ 以后怎么更新（★ 不用重装一遍）━━━
----------------------------------------------------------
**你不用再从头下载任何东西。**

两种更新来源，任选：

① 客户端更新（DshShell 本身）
   打开应用 → 右上角 ⋮ 菜单 → **检查更新** → 它会自动下载新版本并拉起安装器。
   点一下即可，不用碰 Termux。

② 服务端/适配更新（我们改了插件或脚本）
   收到新版本通知后，在 Termux 里重跑一次**第二步那条命令**即可。
   安装器是**幂等**的：不会重复安装、不会动你的会话记录，只更新变化的部分。

★ 任何时候想确认当前版本：在 Termux 里执行

     dshstatus

★ 界面出问题了想退回官方原生界面（保底，随时可用）：

     dsh-mobile-safe-mode on      # 进安全模式 → 刷新页面
     dsh-mobile-safe-mode off     # 想恢复适配再来这一条


━━━ 常见问题 ━━━
----------------------------------------------------------
· 卡在哪一步了？
  再跑一次第二步那条命令。安装器会自检查出问题在哪，且不会重复装。

· 提示签名冲突装不上？
  说明你手机上装过 Google Play 版或 F-Droid 版的 Termux —— 它们与官方 GitHub 版
  签名不同，必须先卸载旧版再装。

· 不装 Termux:API 行不行？
  主功能可用，但「检查更新」「部分弹窗」会退化。建议装。

· 这是什么东西？
  一个跑在你自己手机上的 DSH（DeepSeek Harness）客户端：
  Termux 提供运行环境，DshShell 提供原生壳与移动端适配界面。
EOF

echo
info "已生成两份报告：开始这里.txt（给电脑） / 给用户-部署说明.txt（给用户）"

# ---------- 6) 打包 ----------
echo
info "打包…"
BUNDLE_PATH="$OUT/$BUNDLE.tar.gz"
tar -czf "$BUNDLE_PATH" -C "$STAGE" "$BUNDLE"
( cd "$OUT" && sha256sum "$BUNDLE.tar.gz" > "$BUNDLE.tar.gz.sha256" )

# 同步一份到下载根目录（用户手机上传/分享时好找）
DL="/storage/emulated/0/Download"
[ -d "$DL" ] && [ -w "$DL" ] && { cp -f "$BUNDLE_PATH" "$DL/"; cp -f "$BUNDLE_PATH.sha256" "$DL/"; }

SIZE=$(stat -c %s "$BUNDLE_PATH")
echo
ok "单包已生成"
info "文件：$BUNDLE_PATH"
info "大小：$(numfmt --to=iec "$SIZE" 2>/dev/null || echo "$SIZE 字节")"
info "校验：$(cat "$BUNDLE_PATH.sha256" | cut -d' ' -f1)"
info "内容："
tar tzf "$BUNDLE_PATH" | sed 's/^/    /'
echo
info "把这个 tar.gz 传给电脑即可（电脑解压后看「开始这里.txt」）"
