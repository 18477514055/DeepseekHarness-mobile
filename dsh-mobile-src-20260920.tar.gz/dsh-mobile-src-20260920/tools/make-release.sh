#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  make-release.sh —— 打出可分发的发布包（tar.gz + 校验和）
#
#  为什么是压缩包而不是 npm 包：
#    分发者无法注册 npm 账号，而安装器**本来就不需要**任何 registry 账号
#    —— DSH 走 npmmirror 公开包，android.jar 走腾讯云镜像，都不需要账号。
#    所以渠道可以是一个 300KB 的压缩包，放哪都行（Gitee 附件/网盘/直接发文件）。
#
#  用法：
#    tools/make-release.sh            # 先同步 payload，再打包
#    tools/make-release.sh --no-sync  # 不重新同步，直接用现有 payload
# ============================================================
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${DSHM_DIST:-/storage/emulated/0/Download/DSH分发包}"; mkdir -p "$OUT"
VER="$(date +%Y%m%d)"
NAME="dsh-mobile-$VER"

ok()   { printf '\033[32m%s\033[0m\n' "$*"; }
info() { printf '  %s\n' "$*"; }
warn() { printf '\033[33m%s\033[0m\n' "$*"; }
die()  { printf '\033[31m❌ %s\033[0m\n' "$*" >&2; exit 1; }

SYNC=1
[ "${1:-}" = "--no-sync" ] && SYNC=0

# 0) 前置检查：必备文件齐全（缺了就别打包出去害人）
echo "════════ 发布前检查 ════════"
need=(install.sh LICENSE payload/MANIFEST.sha256 \
      payload/plugin/dsh-mobile-adapt/package.json \
      payload/plugin/dsh-mobile-adapt/lib/client.js \
      payload/plugin/dsh-mobile-adapt/lib/index.js \
      payload/apk/DshShell/AndroidManifest.xml \
      payload/termux/link-fix.c thirdparty/SHA256SUMS README.zh.md)
miss=0
for f in "${need[@]}"; do
  [ -e "$ROOT/$f" ] || { printf '\033[31m  缺文件: %s\033[0m\n' "$f"; miss=1; }
done
[ "$miss" = 0 ] || die "必备文件不全，拒绝打包"
info "必备文件齐全（${#need[@]} 项）"

# 1) 同步 payload（保证发布的内容就是现场验证过的那一份）
if [ "$SYNC" = 1 ]; then
  echo
  bash "$ROOT/tools/sync-payload.sh" || die "payload 同步/审计失败，拒绝打包"
fi

# 2) 语法自检：发布出去的脚本必须能过 bash -n
echo
echo "════════ 语法自检 ════════"
n=0
while IFS= read -r f; do
  bash -n "$f" || die "语法错误：$f"
  n=$((n + 1))
done < <(cd "$ROOT" && find . -name '*.sh' -not -path './dist/*' | sort)
while IFS= read -r f; do
  case "$(head -1 "$f")" in
    *bash*) bash -n "$f" || die "语法错误：$f"; n=$((n + 1)) ;;
  esac
done < <(cd "$ROOT" && find payload/termux/bin payload/termux/own -type f 2>/dev/null | sort)
ok "$n 个脚本语法通过"

# 3) 凭据泄漏最后一道闸
echo
echo "════════ 凭据泄漏终检 ════════"
LEAK=0
if grep -rqE 'sk-[A-Za-z0-9]{16,}' "$ROOT/payload" 2>/dev/null; then echo "  发现 sk- 形态密钥"; LEAK=1; fi
if grep -rqE 'token=[A-Za-z0-9_-]{16,}' "$ROOT/payload" 2>/dev/null; then echo "  发现真实令牌（非 __TOKEN__）"; LEAK=1; fi
for f in "$HOME/.dsh-web-url" "$HOME/.deepseek_key"; do
  [ -f "$f" ] || continue
  v=$(tr -d '\r\n' < "$f" | sed 's/.*token=//')
  [ ${#v} -ge 8 ] && grep -rqF -- "$v" "$ROOT/payload" 2>/dev/null && { echo "  发现本机令牌字面量"; LEAK=1; }
done
[ "$LEAK" = 0 ] || die "发布包里发现凭据，拒绝打包"
ok "无凭据"

# 4) 打包
echo
echo "════════ 打包 ════════"
mkdir -p "$OUT"
STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
DEST="$STAGE/$NAME"
mkdir -p "$DEST"

# 只带运行所需：install.sh + lib + payload + thirdparty + docs + LICENSE + README
cp -a "$ROOT/install.sh" "$DEST/"
cp -a "$ROOT/lib" "$DEST/"
cp -a "$ROOT/payload" "$DEST/"
cp -a "$ROOT/thirdparty" "$DEST/"
[ -d "$ROOT/docs" ] && cp -a "$ROOT/docs" "$DEST/"
[ -f "$ROOT/README.zh.md" ] && cp -a "$ROOT/README.zh.md" "$DEST/"
[ -f "$ROOT/LICENSE" ] && cp -a "$ROOT/LICENSE" "$DEST/"
[ -d "$ROOT/tools" ] && { mkdir -p "$DEST/tools"; cp -a "$ROOT/tools/sync-payload.sh" "$DEST/tools/"; }

# 记录本次发布对应的 DSH 版本（便于日后追溯）
printf 'dsh_pin=%s\nbuilt_at=%s\n' \
  "$(grep -oE 'DSHM_PIN_VERSION="[^"]+"' "$ROOT/lib/stage-dsh.sh" | cut -d'"' -f2)" \
  "$(date '+%F %T')" > "$DEST/RELEASE-INFO.txt"

tar -czf "$OUT/$NAME.tar.gz" -C "$STAGE" "$NAME"
( cd "$OUT" && sha256sum "$NAME.tar.gz" > "$NAME.tar.gz.sha256" )

SIZE=$(stat -c %s "$OUT/$NAME.tar.gz")
printf '\n'
ok "发布包已生成"
info "文件：$OUT/$NAME.tar.gz（$(numfmt --to=iec "$SIZE" 2>/dev/null || echo "$SIZE 字节")）"
info "校验：$OUT/$NAME.tar.gz.sha256"
info "内容："
tar tzf "$OUT/$NAME.tar.gz" | head -12 | sed 's/^/    /'
info "… 共 $(tar tzf "$OUT/$NAME.tar.gz" | wc -l) 项"

# 4.5) 生成"一键安装脚本"（接收方只需粘贴一条命令）
cat > "$OUT/一键安装.sh" <<'BOOT'
#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  DshShell 一键安装（接收方用）
#
#  用法（在 Termux 里粘贴这一条）：
#    bash <(curl -fsSL 这个文件的直链)
#  或者先把本文件和安装包都下到 Download，再：
#    bash ~/storage/downloads/一键安装.sh
#
#  它会：下载安装包 → 校验 SHA256 → 解压 → 运行安装器
# ============================================================
set -u
# ↓↓↓ 发布者需要把下面两行填上（填好后本脚本就能独立工作）↓↓↓
TARBALL_URL="${DSHM_TARBALL_URL:-__请填写安装包的下载直链__}"
SHA256="__请填写安装包的SHA256__"
# ★ 多源候选（打包时由 dist/发布直链.txt 自动生成）：GitHub 原址 + 国内加速前缀，逐个试
MIRRORS=()
# ↑↑↑ 发布者填写区结束 ↑↑↑

NAME="dsh-mobile-setup"
WORK="$HOME/$NAME"
TAR="$WORK/setup.tar.gz"

red()  { printf '\033[31m%s\033[0m\n' "$*" >&2; }
grn()  { printf '\033[32m%s\033[0m\n' "$*"; }
die()  { red "❌ $*"; exit 1; }

# ★ 拿安装包的三条路（2026-09-16 加强）：① 本机已有文件（最稳）② 直链下载 ③ 下载失败时给可操作提示
#   命令行里直链下不动是常态：网盘直链要 cookie / 加速站要 VPN / curl 不跟某些跳转 —— 所以本地文件优先。
LOCAL=""
if [ -n "${DSHM_LOCAL:-}" ]; then
  LOCAL="$DSHM_LOCAL"
else
  # ★ 逐个候选**先校验再采用**：Download 里常躺着旧版本的包，不能拿它硬装（否则报"校验不通过"让人一头雾水）
  for c in "$(dirname "$0")"/dsh-mobile-*.tar.gz \
           "$(dirname "$0")"/*.tar.gz \
           /storage/emulated/0/Download/dsh-mobile-*.tar.gz \
           /sdcard/Download/dsh-mobile-*.tar.gz \
           "$HOME/storage/downloads"/dsh-mobile-*.tar.gz \
           "$HOME/Download"/dsh-mobile-*.tar.gz \
           "$HOME"/dsh-mobile-*.tar.gz; do
    [ -f "$c" ] || continue
    g=$(sha256sum "$c" 2>/dev/null | cut -d' ' -f1)
    if [ "$g" = "$SHA256" ]; then LOCAL="$c"; break; fi
    echo "  · 跳过（不是这一版）：$(basename "$c")"
  done
fi
help_find_file() {
  red "❌ 还没拿到安装包。三条最容易成功的办法（任选一条，然后重跑本脚本）："
  echo "   ① 让发送方把 dsh-mobile-*.zip 发给你 → 用手机文件管理器解压到 下载 目录（最稳）"
  echo "   ② 用手机浏览器打开下载链接（浏览器能过网盘页/跳转/要 cookie 的直链），下到 下载 目录"
  echo "   ③ 和发送方在同一 Wi-Fi / 热点下：他在自己手机跑  cd ~/Download && python3 -m http.server 8899"
  echo "      你用浏览器打开 http://<他的IP>:8899/ 直接点文件下载（不用外网、不用 VPN）"
  echo "   本脚本已在这些位置找过：脚本同目录 / Download / /sdcard/Download / ~/storage/downloads / ~"
  die "把 tar.gz 放到上面任一位置即可，或者确认直链真的可用"
}

command -v curl >/dev/null 2>&1 || { pkg install -y curl || die "需要 curl"; }
mkdir -p "$WORK" || die "无法创建 $WORK"

try_download() {   # $1=url；下载成功**且校验通过**才算数
  rm -f "$TAR"
  curl -L --fail --connect-timeout 6 -m 30 --retry 1 -s -o "$TAR" "$1" || return 1
  [ "$(sha256sum "$TAR" 2>/dev/null | cut -d' ' -f1)" = "$SHA256" ] || return 1
  return 0
}
if [ -n "$LOCAL" ]; then
  echo "① 使用本机已有的安装包：$LOCAL"
  cp -f "$LOCAL" "$TAR" || die "复制安装包失败：$LOCAL"
else
  URLS=()
  case "$TARBALL_URL" in __*|"") ;; *) URLS+=("$TARBALL_URL") ;; esac
  if [ "${#MIRRORS[@]}" -gt 0 ]; then URLS+=("${MIRRORS[@]}"); fi
  [ "${#URLS[@]}" -gt 0 ] || help_find_file
  echo "① 下载安装包（会自动换源，共 ${#URLS[@]} 个候选）…"
  OKD=0
  for u in "${URLS[@]}"; do
    echo "   · 试：$u"
    if try_download "$u"; then echo "   ✓ 下载并校验通过"; OKD=1; break; fi
    echo "   ✗ 这个源不行，换下一个"
  done
  [ "$OKD" = 1 ] || { rm -f "$TAR"; help_find_file; }
fi

echo "② 校验完整性…"
GOT=$(sha256sum "$TAR" | cut -d' ' -f1)
if [ "$GOT" != "$SHA256" ]; then
  rm -f "$TAR"
  die "校验不通过（文件可能没下完或被篡改）：期望 $SHA256，实际 $GOT"
fi
grn "   校验通过"

echo "③ 解压…"
rm -rf "$WORK/src"; mkdir -p "$WORK/src"
tar xzf "$TAR" -C "$WORK/src" --strip-components=1 || die "解压失败"
[ -f "$WORK/src/install.sh" ] || die "压缩包内容异常（缺少 install.sh）"
grn "   解压到 $WORK/src"

# ★ 2026-09-19 新增：顺手把 Termux:API 也装上。
#   为什么放在这里（用户实测反馈驱动）：很多人手机上 termux-setup-storage 跑不通，
#   共享存储与 Termux 私有目录不互通。此时「先下到下载目录再点安装」这条路是断的。
#   而 Termux:API 是**必须安装的 APK**（它提供 termux-open 等命令）。
#   ⇒ 那就由脚本自己下到共享存储（不依赖 ~/storage 符号链接）并尝试拉起安装界面；
#     万一共享存储也不可用，就只提示、**绝不中断**，让主安装照常走完。
echo "④ 准备 Termux:API（可选但强烈建议）…"
TA_NAME="termux-api-app_v0.53.0+github.debug.apk"
TA_SHA="ecf916ff80ae751e65c092f51c055cce4de417ebeea8e449cd0f294afdbde39a"
TA_BASE="https://github.com/termux/termux-api/releases/download/v0.53.0/$TA_NAME"
TA_URLS=(
  "https://gh-proxy.com/$TA_BASE"
  "https://ghproxy.net/$TA_BASE"
  "$TA_BASE"
)
TA_SHARED=""
for d in /storage/emulated/0/Download /sdcard/Download /storage/self/primary/Download /mnt/sdcard/Download; do
  [ -d "$d" ] && [ -w "$d" ] && { TA_SHARED="$d"; break; }
done
TA_DEST="${TA_SHARED:-$WORK}/$TA_NAME"
if command -v termux-open >/dev/null 2>&1; then
  grn "   termux-api 客户端命令已在，跳过"
elif [ -f "$TA_DEST" ] && [ "$(sha256sum "$TA_DEST" 2>/dev/null | cut -d' ' -f1)" = "$TA_SHA" ]; then
  grn "   Termux:API 安装包已在：$TA_DEST"
else
  echo "   下载 Termux:API 安装包…"
  OKA=0
  for u in "${TA_URLS[@]}"; do
    rm -f "$TA_DEST.part"
    if curl -L --fail --connect-timeout 15 -m 180 -s -o "$TA_DEST.part" "$u"; then
      if [ "$(sha256sum "$TA_DEST.part" 2>/dev/null | cut -d' ' -f1)" = "$TA_SHA" ]; then
        mv -f "$TA_DEST.part" "$TA_DEST"; OKA=1; break
      fi
    fi
    rm -f "$TA_DEST.part"
  done
  if [ "$OKA" = 1 ]; then
    grn "   已下载并校验：$TA_DEST"
    if [ -t 0 ]; then
      if command -v termux-open >/dev/null 2>&1; then
        termux-open "$TA_DEST" >/dev/null 2>&1 || true
      else
        am start -a android.intent.action.VIEW -d "file://$TA_DEST" \
          -t application/vnd.android.package-archive >/dev/null 2>&1 || true
      fi
      echo "   → 若弹出安装界面，点「安装」即可（装完会回到这里）"
    fi
  else
    echo "   ⚠️ Termux:API 没下下来（不影响主安装）。可稍后手动装，或重跑本命令。"
  fi
fi

echo "⑤ 开始安装 DSH…"
echo
exec bash "$WORK/src/install.sh" "$@"
BOOT
# ★ 自动把安装包的 SHA256 预填进一键脚本（2026-09-16：手工填漏过两次，改成脚本自己填，不再依赖记忆）
SHA_REAL=$(cut -d' ' -f1 "$OUT/$NAME.tar.gz.sha256" 2>/dev/null || true)

# ★ 2026-09-19 重做「烧直链」这一段。
#   旧版的问题（自检发现）：它读的 $OUT/发布直链.txt **从来没人生成过**，
#   于是兜底去 head -1 那一行——而文件第一行是注释 `# ...`，被当成 URL 烧进脚本，
#   结果是 MIRRORS 里多一条垃圾、TARBALL_URL 被清空、**一键脚本根本无法独立工作**。
#   现在改成：① 先调 make-direct-links.sh 真正生成清单 ② 只取清单里属于**本载荷**那一行。
if [ "${DSHM_SKIP_LINKS:-0}" != 1 ]; then
  REPO="${REPO:-18477514055/DeepseekHarness-mobile}" REF="${REF:-main}" TAG="${TAG:-v$VER}" \
    bash "$ROOT/tools/make-direct-links.sh" || die "生成发布直链失败"
fi

if [ -f "$OUT/发布直链.txt" ]; then
  python3 - "$OUT/一键安装.sh" "$OUT/发布直链.txt" "$NAME.tar.gz" <<'PYEOF'
import sys, re, os
sh, listf, want = sys.argv[1], sys.argv[2], sys.argv[3]
urls = []
if os.path.isfile(listf):
    for l in open(listf, encoding="utf-8"):
        l = l.strip()
        if not l or l.startswith("#"):
            continue
        parts = l.split()
        # 格式：<sha256>  <文件名>  <候选url...>  —— 只挑本载荷那一行
        if len(parts) >= 3 and parts[1] == want:
            urls = parts[2:]
            break
if not urls:
    print("未在 发布直链.txt 里找到 %s，一键脚本将保持占位符" % want)
    sys.exit(0)
s = open(sh, encoding="utf-8").read()
s = re.sub(r"^TARBALL_URL=.*$", 'TARBALL_URL="${DSHM_TARBALL_URL:-}"', s, count=1, flags=re.M)
arr = "MIRRORS=(" + " ".join('"%s"' % c for c in urls) + ")"
s = re.sub(r"^MIRRORS=\(\)$", lambda m: arr, s, count=1, flags=re.M)
open(sh, "w", encoding="utf-8").write(s)
print("MIRRORS=%d 个候选（首条 %s）" % (len(urls), urls[0][:48]))
PYEOF
  ok "一键脚本已烧入多源候选"
fi
if [ -n "$SHA_REAL" ]; then
  sed -i "s|^SHA256=\".*\"|SHA256=\"$SHA_REAL\"|" "$OUT/一键安装.sh"
  ok "一键脚本已自动预填 SHA256：${SHA_REAL:0:16}…"
fi
chmod +x "$OUT/一键安装.sh"
# ★ 自检：一键脚本绝不允许留下占位符（自检发现它曾经带着 __请填写…__ 就发出去了）
if grep -q '__请填写' "$OUT/一键安装.sh" || grep -q '^MIRRORS=()$' "$OUT/一键安装.sh"; then
  warn "一键脚本仍有未填字段（占位符或空 MIRRORS）—— 发布前必须解决"
else
  ok "一键脚本自检通过：无占位符、候选源非空"
fi
info "一键脚本：$OUT/一键安装.sh"

# 5) 生成给用户看的安装说明（可直接贴到发布页）
cat > "$OUT/安装说明.txt" <<EOF
DshShell 一键安装（Termux · 免翻墙）
====================================
适用：安卓手机 + Termux（arm64）。不需要 VPN，不需要电脑。

━━ 第一步：装 Termux ━━
★ 2026-09-19 更正：这里原来写「下载 v0.119.0+github-debug_universal.apk」，
  而 **v0.119.0 并不存在正式发布**（它还在 beta），universal 包也有 112MB。
  实际最新正式版就是 v0.118.3，我们分发的也正是它 —— 以下为更正后的写法。

推荐从 GitHub Releases 装（F-Droid 在部分网络下很慢）：
  手机浏览器打开： https://github.com/termux/termux-app/releases/latest
  或加速打开  ： https://gh-proxy.com/https://github.com/termux/termux-app/releases/latest
  下载哪个（看你的机型，多数现役手机是 arm64-v8a）：
      termux-app_v0.118.3+github-debug_arm64-v8a.apk      ← 首选
      termux-app_v0.118.3+github-debug_armeabi-v7a.apk    ← 很老的机型
      termux-app_v0.118.3+github-debug_universal.apk      ← 拿不准就用它（112MB）
  安装时系统会问「允许安装未知应用」→ 允许
★ 同时建议装上 Termux:API（同源签名，缺了它「检查更新」等会退化）：
  https://github.com/termux/termux-api/releases/latest
      termux-api-app_v0.53.0+github.debug.apk
注意：不要用 Google Play 版的 Termux（已停更，且签名不同，会冲突）。

━━ 第二步：把安装包弄到手机上 ━━
本发布物共 3 个文件：安装包 .tar.gz、它的 .sha256、以及本说明。

情况 A：用浏览器下的（Gitee 附件 / 网盘直链 / 群里点开链接）
  文件会自动进「下载」目录，跳到第三步即可。

情况 B：别人用微信/QQ 发给你的
  微信：点开文件 → 右上角「…」→「用其他应用打开」→ 选「保存到手机」
  这样才会进「下载」目录。微信自己的目录 Termux 也能读，但路径很绕，不推荐。
  如果只能留在微信目录里，路径大致是：
    微信   ~/storage/shared/tencent/MicroMsg/Download/
    QQ     ~/storage/shared/tencent/QQfile_recv/

━━ 第三步：在 Termux 里安装 ━━
打开 Termux，粘贴下面这几行（一行一行来）：

  termux-setup-storage          # 弹窗里选「允许」

  cd ~
  mkdir -p dsh-setup && cd dsh-setup
  tar xzf ~/storage/downloads/dsh-mobile-<日期>.tar.gz --strip-components=1
  bash install.sh

如果是从微信/QQ 目录解压，把上面第三行的路径换成第二步里对应的路径。

装完依赖后，安装器会问你：
  1) 浏览器模式    —— 最省事，装完用浏览器打开
  2) 本机 APK 版   —— 多一个原生壳（要现场编译，约 1~3 分钟）
想跳过询问直接选：  bash install.sh --mode=apk

━━ 结束之后 ━━
  浏览器模式 → 打开终端里打印的那个地址（也存在 ~/.dsh-web-url）
  APK 版     → 到「下载」里点开 DshShell.apk 安装，以后从桌面图标启动
              首次打开会请求「执行命令」权限，必须允许（否则连不上 Termux）

━━ 出问题怎么办 ━━
先再跑一次：  bash install.sh       （可重复执行，会自检并指出问题）
详细排查：    docs/故障排查.md
权限与安全：  docs/权限与安全.md
EOF
info "安装说明：$OUT/安装说明.txt"

# 6) 同步到「下载」根目录（用户在手机下载管理器里要能直接看到）
#    注意：直接放根目录，不要放子文件夹 —— 下载管理器通常只索引根目录
DL="/storage/emulated/0/Download"
if [ -d "$DL" ] && [ -w "$DL" ]; then
  cp -f "$OUT/$NAME.tar.gz"        "$DL/"
  cp -f "$OUT/$NAME.tar.gz.sha256" "$DL/"
  cp -f "$OUT/安装说明.txt"          "$DL/dsh-mobile-安装说明.txt"
  cp -f "$OUT/一键安装.sh"           "$DL/dsh-mobile-一键安装.sh"
  printf '\n'
  ok "已同步到下载管理器可见位置"
  info "$DL/$NAME.tar.gz"
  info "$DL/$NAME.tar.gz.sha256"
  info "$DL/dsh-mobile-安装说明.txt"
  info "$DL/dsh-mobile-一键安装.sh"
else
  printf '\n'
  warn "没找到可写的 $DL（未同步）；手动复制："
  info "cp '$OUT/$NAME.tar.gz' '$OUT/$NAME.tar.gz.sha256' /storage/emulated/0/Download/"
fi

printf '\n'
ok "完成。把这个 tar.gz + .sha256 + 安装说明 一起发出去即可。"
