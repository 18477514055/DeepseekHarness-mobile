#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  make-source.sh —— 打「源码包」（给开发者）
#
#  用户 2026-09-20 澄清的三个资源里，第 2 个是：
#     "完整工程文件（注意是源码，适合那些开发者）"
#  这与"载荷包"不是一回事：
#     · 载荷包 dsh-mobile-*.tar.gz  = **部署产物**（给老用户/一键脚本用，体积小）
#     · 源码包 dsh-mobile-src-*.tar.gz = **本工程的源码**（给开发者看/改/自己构建）
#
#  源码包里**必须没有**：任何凭据、任何预编译 APK 二进制。
#  （APK 是"产物"，开发者要用源码自己编。）
#
#  用法：bash tools/make-source.sh
# ============================================================
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${DSHM_DIST:-/storage/emulated/0/Download/DSH分发包}"; mkdir -p "$OUT"
VER="$(date +%Y%m%d)"
NAME="dsh-mobile-src-$VER"

ok()   { printf '\033[32m%s\033[0m\n' "$*"; }
info() { printf '  %s\n' "$*"; }
warn() { printf '\033[33m%s\033[0m\n' "$*"; }
die()  { printf '\033[31m❌ %s\033[0m\n' "$*" >&2; exit 1; }

echo "════════ 打源码包（给开发者）════════"

STAGE="$(mktemp -d)"
trap 'rm -rf "$STAGE"' EXIT
D="$STAGE/$NAME"
mkdir -p "$D"

# ---------- 1) 收源码（只收源，不收产物）----------
info "收集源码…"
[ -f "$ROOT/install.sh" ] || die "找不到 install.sh（是不是在错的目录跑？）"
cp -a "$ROOT/install.sh" "$D/"
for d in lib tools docs thirdparty web; do
  [ -d "$ROOT/$d" ] && cp -a "$ROOT/$d" "$D/"
done
[ -f "$ROOT/README.zh.md" ] && cp -a "$ROOT/README.zh.md" "$D/"
[ -f "$ROOT/LICENSE" ]      && cp -a "$ROOT/LICENSE" "$D/"

# payload：只要源码，**排除任何 .apk 二进制**
mkdir -p "$D/payload"
if [ -d "$ROOT/payload" ]; then
  ( cd "$ROOT/payload" && tar cf - --exclude='*.apk' . ) | ( cd "$D/payload" && tar xf - )
  n=$(find "$D/payload" -name '*.apk' | wc -l)
  [ "$n" = 0 ] || die "payload 里仍残留 $n 个 APK 二进制"
fi

# 出包目录不进源码包（那是产物）
rm -rf "$D/dist" 2>/dev/null

# ---------- 2) 脱敏：源码包里绝不能出现真实令牌/密钥 ----------
info "安全审计…"
LEAK=0
TOK=$(grep -o 'token=[A-Za-z0-9_-]*' "$HOME/.dsh-web-url" 2>/dev/null | cut -d= -f2)
if [ -n "$TOK" ] && grep -rqF -- "$TOK" "$D" 2>/dev/null; then
  warn "  源码包里出现了本机真实令牌"; LEAK=1
fi
if grep -rqE 'sk-[A-Za-z0-9]{16,}' "$D" 2>/dev/null; then
  warn "  发现形如 sk- 的 API Key"; LEAK=1
fi
if grep -rqE 'token=[A-Za-z0-9_-]{16,}' "$D" 2>/dev/null; then
  warn "  发现形如真实令牌的字符串（应为 __TOKEN__）"; LEAK=1
fi
[ "$LEAK" = 1 ] && die "源码包审计未通过，已中止"
ok "审计通过：无凭据、无 APK 二进制"

# ---------- 3) 写一份给开发者的说明 ----------
cat > "$D/源码说明-给开发者.txt" <<EOF
DshShell 源码包（$VER）
==========================================================
这是**源码**，不是部署产物。适合想读代码、改代码、或自己构建的人。

【目录结构】
  install.sh          安装器入口（在 Termux 里跑 bash install.sh）
  lib/*.sh            安装器模块：体检/下载/依赖/DSH/原生模块/sharp/插件/APK/自检
  tools/              出包与发布工具
                        sync-payload.sh      从现场同步真实文件进 payload + 脱敏 + 审计
                        make-release.sh      出载荷包 + 一键脚本（含烧直链）
                        make-direct-links.sh 生成《发布直链.txt》《APK 校验值》
                        make-bundle.sh       打「给电脑端」的自解释上传包
                        make-source.sh       打本源码包
                        publish.py           上传到 GitHub（跨平台、干跑、校验、幂等）
  payload/
    plugin/dsh-mobile-adapt/   移动端适配插件（client.js 是网页层，index.js 是服务端半）
    termux/bin/                自建运维命令（dshweb/dshstatus/dsh-session/...）
    termux/link-fix.c          安卓上 link() 被拒的降级补丁源码
    apk/DshShell/              APK 壳的**源码**（Java + res + AndroidManifest）
  docs/               文档（含两条路线的接收方说明）
  web/                引导页与契约体检页（静态 HTML）
  thirdparty/         第三方组件校验和（android.jar 等，只记校验值不分发本体）

【为什么里面没有 APK】
  本项目的设计是**用接收方自己的令牌现场编译 APK**（keystore 也在本机生成），
  所以发布物里不含预编译 APK、不含任何凭据。这是刻意的安全选择。

【想自己构建】
  最直接的方式：把本目录放到 Termux 里，跑
      bash install.sh --mode=apk
  它会自己下依赖、下 android.jar、编译并签名 APK。

  只想出包（不安装）：
      bash tools/make-release.sh          # 出载荷包
      bash tools/make-source.sh           # 出源码包
      bash tools/make-bundle.sh           # 打给电脑端的自解释上传包
EOF

# ---------- 4) 打包 ----------
# 说明放最外层，解压就能看到
( cd "$STAGE" && tar -czf "$OUT/$NAME.tar.gz" "$NAME" )
( cd "$OUT" && sha256sum "$NAME.tar.gz" > "$NAME.tar.gz.sha256" )

SIZE=$(stat -c %s "$OUT/$NAME.tar.gz")
echo
ok "源码包已生成"
info "文件：$OUT/$NAME.tar.gz（$(numfmt --to=iec "$SIZE" 2>/dev/null || echo "$SIZE 字节")）"
info "校验：$(cut -d' ' -f1 "$OUT/$NAME.tar.gz.sha256")"
info "内容（顶层）："
tar tzf "$OUT/$NAME.tar.gz" | sed -n '2,12p' | sed 's/^/    /'
info "… 共 $(tar tzf "$OUT/$NAME.tar.gz" | wc -l) 项"
echo
info "给开发者：解压后看《源码说明-给开发者.txt》"
