#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  make-direct-links.sh —— 生成「发布直链.txt」与「APK-CHECKSUMS.txt」
#  被 tools/make-release.sh 调用（也可单独跑）
#
#  背景（2026-09-19 自检发现）：
#    make-release.sh 里本来就有"读 dist/发布直链.txt，自动生成多源候选并烧进一键脚本"
#    的逻辑，但**那个文件从来没被生成过** ⇒ 这段逻辑一次都没生效，一键脚本里
#    至今是占位符 + 空 MIRRORS。本脚本就是补上那个缺失的生产者。
#
#  产物（都在 $OUT）：
#    发布直链.txt        —— 每个受管文件一行：<sha256>  <文件名>  <候选url...>
#                           供 lib/fetch-apk.sh 与一键脚本读取
#    APK-CHECKSUMS.txt  —— 给「电脑端上传者」核对用（人工可读）
#    上传清单-给电脑端.txt —— 电脑端要传哪些文件、传到哪、sha256 是多少
#
#  用法：
#    bash tools/make-direct-links.sh                  # 默认 GitHub 仓库信息
#    REPO=user/name TAG=v20260919 REF=main bash tools/make-direct-links.sh
# ============================================================
set -u

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
OUT="${DSHM_DIST:-/storage/emulated/0/Download/DSH分发包}"; mkdir -p "$OUT"
VER="$(date +%Y%m%d)"
NAME="dsh-mobile-$VER"

# ---- 仓库与引用（换仓库只改这两个默认值，或在命令行覆盖）----
REPO="${REPO:-18477514055/DeepseekHarness-mobile}"
REF="${REF:-main}"
TAG="${TAG:-v$VER}"

ok()   { printf '\033[32m%s\033[0m\n' "$*" >&2; }
info() { printf '  %s\n' "$*" >&2; }
warn() { printf '\033[33m%s\033[0m\n' "$*" >&2; }
die()  { printf '\033[31m❌ %s\033[0m\n' "$*" >&2; exit 1; }

USER="${REPO%%/*}"; REPONAME="${REPO##*/}"

# ---- 受管文件表：与 lib/fetch-apk.sh 的内嵌 sha256 必须一致 ----
# 出包时会交叉核对，不一致直接拒绝（防止"改了 APK 忘了改校验值"这种致命漂移）
T_TERMUX="termux-app_v0.118.3+github-debug_arm64-v8a.apk"
S_TERMUX="72fdb596045116bf5ba1b5bdf5b26fddb9acc0bd074ad9f2da9eb0ae85e83a4e"
T_API="termux-api-app_v0.53.0+github.debug.apk"
S_API="ecf916ff80ae751e65c092f51c055cce4de417ebeea8e449cd0f294afdbde39a"

# ---- 候选源构造 ------------------------------------------------------------
# raw 主干文件（载荷、一键脚本）：jsDelivr 也能用（<20MB）
raw_candidates() {   # $1=路径
  local path="$1"
  printf '%s\n' \
    "https://gh-proxy.com/https://raw.githubusercontent.com/$REPO/$REF/$path" \
    "https://ghproxy.net/https://raw.githubusercontent.com/$REPO/$REF/$path" \
    "https://raw.githubusercontent.com/$REPO/$REF/$path" \
    "https://cdn.jsdelivr.net/gh/$USER/$REPONAME@$REF/$path" \
    "https://ghfast.top/https://raw.githubusercontent.com/$REPO/$REF/$path" \
    "https://github.com/$USER/$REPONAME/raw/$REF/$path"
}

# Release 附件：★ 只有加速前缀能走（jsDelivr 不支持 Release，且 >20MB 会被拒）
release_candidates() {   # $1=文件名
  local f="$1"
  local base="https://github.com/$REPO/releases/download/$TAG/$f"
  printf '%s\n' \
    "https://gh-proxy.com/$base" \
    "https://ghproxy.net/$base" \
    "$base"
}

# ---- 1) 清单文件（载荷 + 一键脚本）----------------------------------------
TARBALL="$OUT/$NAME.tar.gz"
[ -f "$TARBALL" ] || die "找不到 $TARBALL —— 先跑 tools/make-release.sh 生成发布包"
S_TARBALL=$(sha256sum "$TARBALL" | cut -d' ' -f1)
LOADER="$OUT/一键安装.sh"
[ -f "$LOADER" ] || die "找不到 $LOADER —— 先跑 tools/make-release.sh 生成一键脚本"

# ---- 2) 收集受管 APK：优先「下载」目录，其次分发包目录 ---------------------
DL="/storage/emulated/0/Download"
# ★ 受管 APK 的**唯一权威暂存处**（2026-09-19 新增）：
#   以前两个 APK 只散落在共享存储里，而共享存储会被清理/整理 ⇒ 曾出现"出包时找不到"。
#   现在固定从 ~/dsh-backup/apk-staging/ 取，并且这里存的必须是验真过的官方原件。
STAGING="$HOME/dsh-backup/apk-staging"
find_apk() {   # $1=文件名 → 打印路径
  local f="$1" c
  for c in "$STAGING/$f" "$OUT/$f" "$DL/$f" "$DL/DSH分发包/$f" \
           "/sdcard/Download/$f" "/sdcard/Download/DSH分发包/$f"; do
    [ -f "$c" ] && { printf '%s\n' "$c"; return 0; }
  done
  return 1
}

P_TERMUX=$(find_apk "$T_TERMUX" || true)
P_API=$(find_apk "$T_API" || true)
[ -n "$P_TERMUX" ] || warn "本机找不到 $T_TERMUX —— 它的直链会写进清单，但**电脑端上传后才能真正下载**"
[ -n "$P_API" ]    || warn "本机找不到 $T_API —— 同上"

# 本地能拿到的，就实测 sha256 并交叉核对（拿不到就沿用已知值，仍会被电脑端核对）
chk() {   # $1=路径(可空) $2=期望sha $3=文件名
  local p="$1" want="$2" f="$3" got
  if [ -n "$p" ]; then
    got=$(sha256sum "$p" | cut -d' ' -f1)
    if [ "$got" != "$want" ]; then
      die "受管文件「$f」的 sha256 与预期不符！" \
          "预期 $want
  实测 $got
  本机文件：$p
  ⇒ 要么文件被换过、要么内嵌校验值过期。改对之前拒绝出包。"
    fi
    info "$f ✓ $(numfmt --to=iec "$(stat -c %s "$p")" 2>/dev/null || echo '?')  来自 $p"
  else
    info "$f（本机无此文件，沿用已知校验值）"
  fi
  printf '%s\n' "$want"
}

echo "════════ 生成发布直链 ════════"
echo "  仓库：$REPO   分支：$REF   Release tag：$TAG"
echo "  输出：$OUT"
echo

# ---- 3) 写 发布直链.txt ----------------------------------------------------
LIST="$OUT/发布直链.txt"
{
  echo "# 发布直链清单（由 tools/make-direct-links.sh 自动生成，勿手改）"
  echo "# 生成时间：$(date '+%F %T')"
  echo "# 格式：<sha256>  <文件名>  <候选直链...>（脚本逐条试，每条都校验 sha256）"
  echo "# 仓库：$REPO  分支：$REF  Release：$TAG"
  echo "#"
  echo "# ① 一键脚本与安装包（走 raw 主干，jsDelivr 可用）"
  printf '#%s\n' "$S_TARBALL  $NAME.tar.gz"
  printf '%s  %s' "$S_TARBALL" "$NAME.tar.gz"
  while IFS= read -r u; do printf ' %s' "$u"; done < <(raw_candidates "$NAME.tar.gz")
  printf '\n'
  echo "#"
  echo "# ② Termux / Termux:API（走 Release 附件；★ 两者必须同签名 b6da0148…48ee5e1）"
  printf '%s  %s' "$(chk "$P_TERMUX" "$S_TERMUX" "$T_TERMUX")" "$T_TERMUX"
  while IFS= read -r u; do printf ' %s' "$u"; done < <(release_candidates "$T_TERMUX")
  printf '\n'
  printf '%s  %s' "$(chk "$P_API" "$S_API" "$T_API")" "$T_API"
  while IFS= read -r u; do printf ' %s' "$u"; done < <(release_candidates "$T_API")
  printf '\n'
} > "$LIST"
ok "发布直链.txt 已生成（$(grep -cv '^#' "$LIST") 条文件记录）"

# ---- 4) 给电脑端上传者的说明 ----------------------------------------------
UPLOAD="$OUT/上传清单-给电脑端.txt"
cat > "$UPLOAD" <<EOF
给电脑端：把下面这些文件传到 GitHub 仓库（手机端只用 curl 拉，不碰任何界面）
==========================================================================
仓库：https://github.com/$REPO
生成时间：$(date '+%F %T')

【第一步】主干文件（浏览器拖拽上传即可，都远小于 25MB 限制）
--------------------------------------------------------------------------
目标分支：$REF
要传的文件（源文件就在手机「下载/DSH分发包/」里，用微信/QQ/数据线取走）：

  1) $NAME.tar.gz
     sha256 = $S_TARBALL

  2) 一键安装.sh
     （请重命名为  bootstrap.sh 再传，中文名在 URL 里要转义、容易出错）
     内容就是 $OUT/一键安装.sh

【第二步】两个 APK（★ 必须走 Release 附件，网页拖拽传不了 34MB）
--------------------------------------------------------------------------
新建 Release，tag 填：$TAG
把这两个文件作为附件上传（附件上限 2GB，34MB 没问题）：

  a) $T_TERMUX
     sha256 = $S_TERMUX
     （本机文件：${P_TERMUX:-未找到}）

  b) $T_API
     sha256 = $S_API
     （本机文件：${P_API:-未找到}）

  ★ 这两个 APK 必须来自官方 termux / termux-api 的 GitHub Releases，
    且**签名必须同源**（证书 SHA-256 = b6da0148eefd5fbf2cd3771b8d1021ec791304bdd6c4bf41d3faabad48ee5e1）。
    传之前请用 sha256 核对，传错了整条链路都会装不上或命令静默失效。

【第三步】回执
--------------------------------------------------------------------------
传完把「发布直链.txt」里 ② 那两行的 URL 在电脑浏览器里点一下，确认能下（HTTP 200）。
然后告诉手机端，手机端会实跑一次验收（这是唯一能证明"一条链接"成立的测试）。
EOF
ok "上传清单-给电脑端.txt 已生成"

# ---- 5) 人工可读的校验值表 ------------------------------------------------
SUM="$OUT/APK-CHECKSUMS.txt"
{
  echo "# 受管 APK 校验值（自动生成，勿手改）"
  echo "# 生成时间：$(date '+%F %T')"
  echo "# ★ 与 lib/fetch-apk.sh 内嵌值、《发布直链.txt》三处必须一致"
  echo "$S_TERMUX  $T_TERMUX"
  echo "$S_API  $T_API"
} > "$SUM"
ok "APK-CHECKSUMS.txt 已生成"

echo
info "下一步（电脑端）：按「上传清单-给电脑端.txt」上传，然后手机端实跑验收"