#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  fetch-apk.sh —— 「第 0 步：把 DshShell 需要的那几个 APK 弄到手」
#  被 install.sh source
#
#  为什么要有这个模块（2026-09-19 自检发现的缺口）：
#    以前接收方要自己在 GitHub releases 页面里翻两个 APK（34MB + 8.5MB），
#    而命令行里 GitHub 直链在部分网络下要 VPN。结果是"一键安装"其实要人肉四步。
#    本模块把这几步自动化：**多源回退 + 逐个 SHA256 校验 + 落盘到「下载」+ 尽力拉起安装器**。
#
#  两条不可动摇的红线（沿用本项目既有事实，别改）：
#    ① **Termux 与 Termux:API 必须同一签名**，否则 termux-api 命令静默失效
#       （实测两者证书都是 b6da0148…48ee5e1）。
#    ② 从 Google Play 装的 Termux 已停更且签名不同 —— 必须引导用户用 GitHub 版。
#
#  URL 不写死在本文件：从仓库根的「发布直链.txt」读（由 tools/make-release.sh 生成），
#  这样仓库/加速前缀换了不用改代码。sha256 是本模块内嵌的权威值（文件内容不变就不会变）。
# ============================================================

# ---- 受管 APK 清单 ---------------------------------------------------------
# 条目格式：<包名>|<落盘文件名>|<sha256>|<显示名>|<必需?>
# ★ sha256 与分发包 dist/APK-CHECKSUMS.txt 及仓库 发布直链.txt 三处必须一致，
#   出包时由 tools/make-release.sh 交叉核对，不一致就拒绝出包。
APK_TERMUX_PKG="com.termux"
APK_TERMUX_FILE="termux-app_v0.118.3+github-debug_arm64-v8a.apk"
APK_TERMUX_SHA="72fdb596045116bf5ba1b5bdf5b26fddb9acc0bd074ad9f2da9eb0ae85e83a4e"

APK_API_PKG="com.termux.api"
APK_API_FILE="termux-api-app_v0.53.0+github.debug.apk"
APK_API_SHA="ecf916ff80ae751e65c092f51c055cce4de417ebeea8e449cd0f294afdbde39a"

# ---- 小工具 ---------------------------------------------------------------

# apk_pkg_installed <包名> —— 装了没有
# ★★ 2026-09-19 重要修正：不要用这个当**唯一**判据！
#   实测（本机）：`pm path com.termux.api` 在几分钟之内先返回空、后返回真实路径 ——
#   包可见性会随"是否与该包交互过"变化（手册第 6 节第 11 条：pm list packages 受包可见性过滤）。
#   ⇒ 结论：`pm path` 只能给出**肯定**答案（查得到=确实装了）；查不到**不能**推断没装。
#   真正的判据应该是**功能性**的：命令存在 + App 真的响应（见 apk_app_alive）。
apk_pkg_installed() {
  local p="$1" out
  out=$(pm path "$p" 2>/dev/null || true)
  [ -n "$out" ]
}

# apk_client_ready —— termux-api 的**客户端命令**在不在（与 App 是两件事）
apk_client_ready() { have termux-open; }

# apk_app_alive —— ★ 功能性判据：Termux:API 这个 **App** 到底在不在、响不响应。
#   用 termux-toast（最轻、不弹权限、不需要存储授权）打一发：
#     · 装了 App 且链路通 → 退出码 0
#     · 没装 App → termux-api 客户端会报 "Termux:API app is not installed" 之类，退出码非 0
#   这比 `pm path` 可靠得多，因为它测的是"能不能用"，而不是"能不能看见"。
apk_app_alive() {
  have termux-toast || return 1
  termux-toast -g bottom " " >/dev/null 2>&1
}

# apk_installed_version <apk路径> —— 读 APK 自身的 versionName
apk_installed_version() {
  local f="$1"
  [ -f "$f" ] || return 1
  aapt dump badging "$f" 2>/dev/null | sed -n "s/^package:.*versionName='\([^']*\)'.*/\1/p" | head -1
}

# apk_device_app_version <包名> —— 读**已安装**那个 App 的 versionName（可见性是问题，所以失败就返回空）
apk_device_app_version() {
  local p="$1" f
  f=$(pm path "$p" 2>/dev/null | head -1 | cut -d: -f2)
  [ -n "$f" ] || return 1
  apk_installed_version "$f"
}

# apk_urls_for <文件名> —— 从 发布直链.txt 取该文件的全部候选直链
# 清单格式（每行）：<sha256>  <文件名>  <url> [<url> ...]
apk_urls_for() {
  local want="$1" list="$DSHM_REPO/发布直链.txt"
  [ -f "$list" ] || return 1
  awk -v n="$want" '
    /^[[:space:]]*#/ { next }
    NF >= 3 && $2 == n { for (i = 3; i <= NF; i++) print $i }
  ' "$list"
}

# apk_sha_for <文件名> —— 从清单里取权威 sha256（清单没有就退回模块内嵌值）
apk_sha_for() {
  local want="$1" list="$DSHM_REPO/发布直链.txt" got=""
  if [ -f "$list" ]; then
    got=$(awk -v n="$want" '/^[[:space:]]*#/ {next} NF>=3 && $2==n {print $1; exit}' "$list")
  fi
  [ -n "$got" ] && { printf '%s\n' "$got"; return 0; }
  case "$want" in
    "$APK_TERMUX_FILE") printf '%s\n' "$APK_TERMUX_SHA" ;;
    "$APK_API_FILE")    printf '%s\n' "$APK_API_SHA" ;;
    *) return 1 ;;
  esac
}

# apk_shared_dir —— 用户能在「下载」里直接看到的目录
# ★ 同时供"离线投放点"复用：用户事先把 APK 丢在这里，脚本就跳过下载。
#
# ★★ 2026-09-19 重要修正（用户实测反馈）：
#   用户在**多台别人的手机上**发现 `termux-setup-storage` 这个命令**打不开/跑不通**，
#   于是"下载到共享目录再安装"这条路直接断掉。
#   根因是我的探测顺序错了：原来第一位是 `~/storage/downloads`，而那个路径是
#   **termux-setup-storage 才会创建的符号链接**。命令跑不通 ⇒ 符号链接不存在 ⇒
#   我判定"没有共享存储" ⇒ 只能落到 Termux 私有目录 ⇒ 用户从文件管理器看不见。
#
#   实测（本机，2026-09-19）：下面这些**直接路径**都能读写，且**不依赖那条命令**：
#     /storage/emulated/0/Download · /sdcard/Download
#     /storage/self/primary/Download · /mnt/sdcard/Download
#   （Termux 只要拿到过存储权限，就能直接走这些路径；符号链接只是顺手的快捷方式。）
#   ⇒ 所以**先试直接路径**，符号链接放到最后当兜底。
apk_shared_dir() {
  local d
  for d in /storage/emulated/0/Download \
           /sdcard/Download \
           /storage/self/primary/Download \
           /mnt/sdcard/Download \
           "$HOME/storage/downloads" \
           "$HOME/storage/shared/Download"; do
    [ -d "$d" ] && [ -w "$d" ] && { printf '%s\n' "$d"; return 0; }
  done
  return 1
}

# is_shared_path <路径> —— 判断这个目录是不是"用户在文件管理器里看得见"的共享存储
is_shared_path() {
  case "$1" in
    /storage/emulated/*|/sdcard/*|/storage/self/*|/mnt/sdcard/*|"$HOME"/storage/*) return 0 ;;
    *) return 1 ;;
  esac
}

# ensure_storage_access —— 尝试拿到共享存储；**拿不到也绝不让安装停下来**
#   ★ 2026-09-19 改：以前这里是"必须先授权"的硬步骤，而用户实测那条命令在很多手机上
#     跑不通 ⇒ 整个流程卡死。现在改成**尽力而为**：
#       ① 若已经有可写的共享路径（不依赖符号链接）→ 直接过，什么都不做；
#       ② 否则试 termux-setup-storage（能弹就弹，等用户点「允许」）；
#       ③ 还是不行 → **不报错、不中断**，明确告知文件会落在 Termux 私有目录并给出用法。
#     私有目录本身对"脚本自己要用"的文件（载荷、插件、脚本）完全够用；
#     只有"要交给系统安装器去装的 APK"才必须放共享存储（见 apk_try_install 的注释）。
ensure_storage_access() {
  SHARED_DIR=""          # ★ 每次重新判定，避免留下上一轮的陈旧路径（自测发现的 bug）
  if d=$(apk_shared_dir) 2>/dev/null; then
    dim "共享存储可用：$d ✓"
    SHARED_DIR="$d"
    return 0
  fi
  if [ "$DRY_RUN" = 1 ]; then dim "[dry-run] 共享存储不可用，跳过探测"; return 0; fi

  # 走一遍授权尝试，但**不把它当门槛**
  if have termux-setup-storage; then
    dim "共享存储还不可写 —— 尝试申请一次「文件和媒体」权限（能弹窗就点「允许」）"
    run termux-setup-storage >/dev/null 2>&1 || true
    local i
    for i in 1 2 3 4 5 6 7 8; do
      sleep 1
      if d=$(apk_shared_dir) 2>/dev/null; then
        ok "共享存储已可用：$d"
        SHARED_DIR="$d"
        return 0
      fi
    done
  fi

  # ★ 这里**故意不用 warn/不中断**：拿不到共享存储只是"需要多一步手动安装"，
  #   不是致命错误。用户反馈过被那类硬性提示搞懵，所以措辞要平和、可操作。
  dim "共享存储暂时不可用 —— 不影响安装，只是个别文件会落在 Termux 自己的目录里"
  return 0
}

# 探测结果缓存（由 ensure_storage_access 填）
SHARED_DIR=""

# apk_sideload_dir —— 共享目录不可用时的**私有兜底目录**
apk_sideload_dir() { printf '%s\n' "$DSHM_HOME/dsh-sideload"; }

# apk_notify_ready <文件路径> <显示名> —— 装完通知用户去点安装（有 termux-api 才有用）
apk_notify_ready() {
  local f="$1" label="$2"
  [ "$DRY_RUN" = 1 ] && return 0
  have termux-notification || return 0
  termux-notification --title "DshShell 组件就绪" \
    --content "$label 已下载并通过校验，点开即可安装" \
    --button1 "打开下载目录" --button1-action "am start -a android.intent.action.VIEW -d content://com.android.externalstorage.documents/root/primary" \
    >/dev/null 2>&1 || true
}

# ---- 取得单个 APK（多源 + 校验 + 复用）-------------------------------------

# ensure_apk_file <文件名> <sha256> <显示名>
# 成功时把**最终文件路径**写到全局 APK_GOT
APK_GOT=""
ensure_apk_file() {
  local file="$1" want="$2" label="$3"
  local shared dest_in_shared=0
  # ★ 优先用 ensure_storage_access 探测好的结果（它已按"直接路径优先"的顺序找过）
  if [ -n "$SHARED_DIR" ] && [ -w "$SHARED_DIR" ]; then
    shared="$SHARED_DIR"; dest_in_shared=1
  elif shared=$(apk_shared_dir); then
    dest_in_shared=1
  else
    shared=$(apk_sideload_dir)
    run mkdir -p "$shared"
  fi
  local dest="$shared/$file"
  if [ "$dest_in_shared" = 1 ]; then
    dim "$label 将落到：$shared（你在「文件管理 / 下载」里能看到）"
  else
    # ★ 重要：落在私有目录时，**明确说清为什么、以及需要做什么**。
    #   用户反馈过"文件下到哪去了找不到"，所以这里不能只报路径，要给出下一步。
    dim "$label 将落到 Termux 私有目录：$shared"
    dim "  原因：这台手机暂时拿不到共享存储（「下载」目录）的写权限。"
    dim "  影响：文件本身没问题，但**系统安装器读不到 Termux 私有目录** ⇒ 需要你手动搬到共享存储再点安装。"
    dim "  办法：安装结束时会告诉你怎么搬（一条命令），或直接在 Termux 里跑："
    dim "        cp '$shared/$file' /sdcard/Download/ && termux-open /sdcard/Download/$file"
  fi
  APK_GOT=""

  # ① 已有且校验通过 → 直接复用（放在共享目录里，用户点一下就能装）
  if verify_sha256 "$dest" "$want"; then
    ok "$label 已就绪（校验通过），不重复下载"
    APK_GOT="$dest"; return 0
  fi

  # ①-b 共享目录里没有，但私有兜底目录里有一份好文件 → 拷过去
  if [ "$dest_in_shared" = 1 ]; then
    local side; side="$(apk_sideload_dir)/$file"
    if verify_sha256 "$side" "$want"; then
      info "$label 在私有目录里已有好文件，复制到「下载」…"
      run cp -a "$side" "$dest"
      if verify_sha256 "$dest" "$want"; then ok "$label 就绪（来自私有兜底目录）"; APK_GOT="$dest"; return 0; fi
      warn "复制后校验失败，改为重新下载"
    fi
  fi

  # ② 缓存命中
  if verify_sha256 "$DSHM_CACHE/$file" "$want"; then
    info "$label 命中本地缓存，复制到「下载」…"
    run mkdir -p "$(dirname "$dest")"
    run cp -a "$DSHM_CACHE/$file" "$dest"
    if verify_sha256 "$dest" "$want"; then APK_GOT="$dest"; return 0; fi
    warn "缓存复制后校验失败，改为重新下载"
  fi

  # ③ 多源下载（每个源试 2 次，下完立刻校验）
  local urls=() u
  while IFS= read -r u; do [ -n "$u" ] && urls+=("$u"); done < <(apk_urls_for "$file" || true)

  run mkdir -p "$(dirname "$dest")" "$DSHM_CACHE"
  local tmp="$dest.part" attempt
  for u in "${urls[@]}"; do
    for attempt in 1 2; do
      info "下载 $label ← $u（第 $attempt 次）"
      rm -f "$tmp"
      if [ "$DRY_RUN" = 1 ]; then
        printf '   %s[dry-run] curl -L -o %s %s%s\n' "$C_BLU" "$tmp" "$u" "$C_OFF"
        APK_GOT="$tmp"; return 0
      fi
      # APK 是 34MB 级，超时给宽一点；--fail 保证 404 不会落成"看起来下好了"的坏文件
      if curl -L --fail --connect-timeout 20 --retry 2 --retry-delay 3 \
              --progress-bar -o "$tmp" "$u"; then
        if verify_sha256 "$tmp" "$want"; then
          mv -f "$tmp" "$dest"
          cp -a "$dest" "$DSHM_CACHE/$file" 2>/dev/null || true
          ok "$label 下载完成并通过校验（$(human_size "$(stat -c %s "$dest")")）"
          APK_GOT="$dest"; return 0
        fi
        warn "校验不通过（可能没下完或被篡改），换下一个源"
        rm -f "$tmp"
        break                # 字节本身不对，同一源再试一次没意义
      fi
      warn "本源失败，重试…"
      sleep 2
    done
  done

  [ ${#urls[@]} -eq 0 ] && apk_hint_no_urls "$file" "$label"
  apk_hint_manual "$file" "$label" "$want"
  return 1
}

# ---- 失败时的人工兜底说明 --------------------------------------------------

apk_hint_no_urls() {
  local file="$1" label="$2"
  printf '\n'
  warn "发布清单里没有 $label 的下载地址（$DSHM_REPO/发布直链.txt）"
  dim "原因通常是：发布者还没把它上传到仓库 / Release。"
  dim "可以这样绕过去（任选）："
  dim "  ① 让发送方把 $file 用微信/QQ 发给你，存到「下载」目录，再重跑本安装脚本"
  dim "  ② 手机浏览器打开 https://github.com/termux/termux-app/releases 手动下载"
  dim "     （Termux:API 在 https://github.com/termux/termux-api/releases）"
  dim "  ③ 和发送方同一 Wi-Fi：他在自己手机跑  cd ~/Download && python3 -m http.server 8899"
  dim "     你用浏览器打开 http://<他的IP>:8899/ 直接点文件下载"
}

apk_hint_manual() {
  local file="$1" label="$2" want="$3"
  printf '\n'
  dim "人工兜底：把 $file 放到「下载」目录，然后重跑本脚本。"
  dim "文件必须满足 sha256 = $want"
}

# ---- 尝试拉起系统安装器（尽力而为，失败不算错）-----------------------------

# 安装界面最终指向的文件（可能已被搬到共享存储）—— 成功时供调用方显示给用户
APK_INSTALL_PATH=""

# apk_try_install <apk路径> <显示名>
#   Termux 本体声明了 REQUEST_INSTALL_PACKAGES，所以大概率能直接弹出安装界面。
#   但它**不是**成功保证：部分 ROM 会拦非文件管理器的安装请求 ⇒ 失败只提示，不报错。
apk_try_install() {
  local f="$1" label="$2"
  [ "$DRY_RUN" = 1 ] && { dim "[dry-run] 跳过拉起安装器"; return 0; }
  [ -f "$f" ] || return 1
  [ -t 0 ] || return 1          # 非交互（脚本管道）时不弹窗，免得吓人

  # ★★ 2026-09-19 关键修复：系统安装器 / termux-open **读不到 Termux 私有目录**。
  #   如果文件在私有目录里（拿不到共享存储的那种手机），必须先搬到共享存储，
  #   否则下面两条通道必然失败 —— 这正是用户反馈"打不开"的另一半原因。
  if ! is_shared_path "$(dirname "$f")"; then
    local sd=""
    sd=$(apk_shared_dir 2>/dev/null || true)
    if [ -n "$sd" ]; then
      dim "把 $label 从 Termux 私有目录搬到共享存储（系统安装器只认这里）"
      if run cp -f "$f" "$sd/" 2>/dev/null; then
        f="$sd/$(basename "$f")"
        dim "已搬至：$f"
      fi
    else
      dim "共享存储不可用，无法拉起安装界面（系统安装器读不到 Termux 私有目录）"
      return 1
    fi
  fi

  local out=""
  # 通道 ①：termux-open（Termux:API 提供；MIME 由扩展名推断，.apk → 安装界面）
  if have termux-open; then
    out=$(termux-open "$f" 2>&1) && { ok "已拉起 $label 的安装界面"; APK_INSTALL_PATH="$f"; return 0; }
    dim "termux-open 未能拉起（$(printf '%s' "$out" | head -1)），试下一条通道"
  fi
  # 通道 ②：am start（不依赖 Termux:API，直接 ACTION_VIEW）
  if have am; then
    out=$(am start -a android.intent.action.VIEW -d "file://$f" \
                -t application/vnd.android.package-archive 2>&1) \
      && { ok "已拉起 $label 的安装界面"; APK_INSTALL_PATH="$f"; return 0; }
    dim "am start 未能拉起（$(printf '%s' "$out" | head -1)）"
  fi
  return 1
}

# ---- 主入口 ---------------------------------------------------------------

# prepare_sideload_apks <模式>
#   browser 模式：Termux 本体必然已装（脚本正跑在里面），只需 Termux:API
#   apk 模式    ：Termux:API + （稍后由 stage-apk 现场编译的）DshShell
prepare_sideload_apks() {
  local mode="${1:-browser}"
  ensure_storage_access          # ★ 必须先做：没有它，后面下到哪儿用户都点不到
  step "⓪-b 准备 Termux 侧组件（Termux:API，可选但强烈建议）"

  dim "Termux 本体：你正在用它跑本脚本 ⇒ 已就绪，无需下载"
  if apk_pkg_installed "$APK_TERMUX_PKG"; then
    local v; v=$(apk_installed_version "$(pm path "$APK_TERMUX_PKG" 2>/dev/null | cut -d: -f2)" 2>/dev/null || true)
    dim "检测到 Termux 版本：${v:-未知}"
  fi

  # Termux:API —— 它提供 termux-open / termux-notification / termux-dialog 等命令，
  # 「检查更新」「安装器拉起」「存储授权」都靠它。
  # ★ 判定顺序（2026-09-19 改）：先功能性探测，再看包可见性；`pm path` 只用来"加证据"。
  local client_ok=0 app_ok=0 alive=0
  apk_client_ready && client_ok=1
  apk_app_alive && alive=1
  apk_pkg_installed "$APK_API_PKG" && app_ok=1

  if [ "$alive" = 1 ]; then
    ok "Termux:API 工作正常（已实测能响应），跳过"
    local dv; dv=$(apk_device_app_version "$APK_API_PKG" 2>/dev/null || true)
    [ -n "$dv" ] && dim "已装版本：$dv"
    [ "$client_ok" = 1 ] || dim "（提示：termux-api 客户端包尚未安装，稍后由依赖步骤补齐）"
    return 0
  fi
  if [ "$app_ok" = 1 ] && [ "$client_ok" = 0 ]; then
    dim "检测到 Termux:API 的 App（但客户端命令还没装，稍后由依赖步骤补齐）"
    return 0
  fi
  if [ "$client_ok" = 0 ] && [ "$app_ok" = 0 ]; then
    dim "未检测到 Termux:API（命令与 App 都没有）"
  elif [ "$client_ok" = 1 ]; then
    warn "termux-api 命令在，但 **App 不响应** —— 多半是 App 没装、或与 Termux 签名不同源"
    dim "（签名不同源时命令会静默失败，这是本项目踩过的坑）"
  fi

  local sha; sha=$(apk_sha_for "$APK_API_FILE" || true)
  if [ -z "$sha" ]; then
    warn "读不到 Termux:API 的校验值，跳过自动准备（不影响主安装）"
    return 0
  fi

  if ensure_apk_file "$APK_API_FILE" "$sha" "Termux:API"; then
    if [ "$alive" = 0 ] && [ -n "$APK_GOT" ]; then
      apk_notify_ready "$APK_GOT" "Termux:API"
      apk_try_install "$APK_GOT" "Termux:API" || {
        printf '\n'
        warn "请手动完成这一步（只差一次点击）："
        dim "  装好的文件就在这里：$APK_GOT"
        dim "  用「文件管理」打开它（或直接在「下载」里找 ${APK_API_FILE}）→ 点安装"
        dim "  装的时候系统会问一次「允许安装未知应用」→ 允许"
        dim "  若提示签名冲突，说明你装过 Play 版 / F-Droid 版 Termux —— 那些版本与官方 GitHub 版签名不同，"
        dim "  必须先卸载旧版再装 GitHub 版（否则 termux-api 命令会静默失败）"
        dim "  装好后回到 Termux 重跑本安装脚本即可（会跳过已完成的步骤）"
      }
      printf '\n'
      warn "★ 关键：Termux 与 Termux:API 必须来自同一来源（同一签名），否则命令会静默失败"
      dim "  本脚本分发的两个 APK 证书已是同源（b6da0148…48ee5e1），照装即可"
    fi
  else
    warn "Termux:API 没拿到 —— 不影响 DSH 本体安装，但「检查更新 / 部分弹窗」会不可用"
    dim "  拿到后重跑本脚本即可补齐（本步骤是幂等的）"
  fi
  return 0
}
