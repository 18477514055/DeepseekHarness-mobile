## android.jar 获取说明（本文件不分发任何 Google 组件）

### 为什么不分发
`android.jar` 属于 Google 的 Android SDK 平台包（`platform-35_r02.zip`），
是**受限再分发组件**。因此本仓库**只记录校验和与获取方式**，不存放文件本体。

### 为什么这不成问题
安装脚本会**自动下载**，实测（无 VPN 环境）：

| 源 | 实测 |
|---|---|
| `mirrors.cloud.tencent.com/AndroidSDK/` | **4.7 秒**下完 62,273,788 字节（14 MB/s） |
| `dl.google.com/android/repository/` | 可下（无 VPN 也通），约 2~3 秒建连 |

腾讯镜像的字节**已用 Google 官方公布的 sha1 校验通过**（见下），可放心作为主源。

### 已固定的校验和

平台包（下载物）：

| 文件 | 大小 | sha1（Google 官方公布） | sha256（实测） |
|---|---|---|---|
| `platform-35_r02.zip` | 64,273,788 | `0bb560a90a7a2cbd0dd8348224d518b638fe7949` ✅ | `0988cacad01b38a18a47bac14a0695f246bc76c1b06c0eeb8eb0dc825ab0c8e0` |
| `platform-35_r01.zip` | 64,281,654 | （官方 XML 已不再列出，不用于主路径） | `ec20a0a65704e1b2554f8e3eebf588ef260569673c848c01aff2e29c28734cf4` |

解包后的 `android.jar`（编译直接用）：

| 文件 | 大小 | sha256 |
|---|---|---|
| `android-35/android.jar` | 26 MB | `4566663c3876e022b4fa4ced8c8697c4ab1688267f090114fd92d027b32e619b` |

> 校验来源：`https://dl.google.com/android/repository/repository2-3.xml`
> 中 `platforms;android-35` 条目的 `<checksum>` 字段（2026-09-15 抓取）。

### 手动获取（离线兜底）
```bash
# 1) 任选一个源下载
curl -L -o platform-35_r02.zip \
  https://mirrors.cloud.tencent.com/AndroidSDK/platform-35_r02.zip
# 2) 校验（必须与上表 sha256 一致）
sha256sum platform-35_r02.zip
# 3) 解出 android.jar，放进缓存目录
mkdir -p ~/.cache/dsh-mobile/android-35
unzip -j -o platform-35_r02.zip android-35/android.jar -d ~/.cache/dsh-mobile/android-35/
sha256sum ~/.cache/dsh-mobile/android-35/android.jar
```
脚本检测到缓存里已有且校验通过的文件时，会**跳过下载**。
