# DshShell 一键安装（Termux · 免翻墙）

在安卓手机上把 [DeepSeek Harness](https://github.com/deepseek-ai/deepseek-harness)（DSH）装成**能用的桌面级应用**：
一个安装脚本走完「环境 → DSH 本体 → 本机专项修复 → 界面适配 → 原生 APK」，**不需要 VPN，不需要电脑**。

- 分发包：**315 KB / 35 个文件**（不含任何凭据）
- 已验证平台：Redmi K70 至尊版（MT6989 / arm64-v8a）/ Android 15 / Termux 0.119.0
- 许可：MIT（第三方非官方安装包，详见 `LICENSE`）

---

## 一、三分钟装完

**1. 装 Termux**（从 F-Droid 或 GitHub Releases，**不要用 Google Play 版**，它已停更）

**2. 把发布包传到手机并解压**
```bash
termux-setup-storage            # 弹窗里选「允许」
cd ~ && mkdir -p dsh-setup && cd dsh-setup
tar xzf ~/storage/downloads/dsh-mobile-<日期>.tar.gz --strip-components=1
```

**3. 运行安装器**
```bash
bash install.sh
```

装完基础依赖后会问你一个选择：

```
────────────────────────────────────────────────────────────
 请选择安装模式
────────────────────────────────────────────────────────────
  1) 浏览器模式
     最省事，装完用手机浏览器打开 DSH 即可。
     不需要额外下载、不需要编译，约 1~2 分钟完成。
     代价：没有原生壳（没有等待页进度条、页面内一键更新、
           后台空闲回收）。界面适配插件照常生效。

  2) 本机 APK 版
     在浏览器模式基础上，再在这台手机上现场编译并签名一个 APK，
     获得原生壳：等待页进度条 / 页面内一键更新 / 后台空闲 20 分钟回收。
     额外需要：
       · 再装构建工具包：约 400MB（含 android.jar 62MB）
       · 下载 android.jar 平台包 62MB（实测约 5 秒，无需翻墙）
       · 编译 + 签名，约 1~3 分钟
       · 授予 Termux 存储权限（用于把 APK 放到 Download 目录）
       · 允许 Termux 安装未知应用（系统会弹一次确认）
       · 生成的 APK 用本机自己的令牌现场签名，不含任何可外泄的凭据。
────────────────────────────────────────────────────────────
 请输入 1 或 2 [默认 2]:
```

不想被问就直接指定：
```bash
bash install.sh --mode=apk        # 本机 APK 版
bash install.sh --mode=browser    # 浏览器模式
bash install.sh --dry-run         # 只演示流程，不做任何改动
```

**重跑安装脚本永远是安全的**（幂等，不会重复安装），出问题先重跑一次。

---

## 二、它替你修了哪些"手机上才会遇到"的坑

这部分是本项目存在的主要理由 —— 直接 `npm i -g @deepseek-ai/dsh` 在 Termux 上是**装得完但用不了**的：

| # | 问题 | 症状 | 本项目怎么修 |
|---|---|---|---|
| 1 | 静态服务缺 PNG/WEBP/字体 MIME 映射 | 界面缺图标、字体 404 | 打补丁补上映射表 |
| 2 | 启动令牌每次重启都变 | APK 里烧的入口失效 → 卡等待页 | 改成由本机密钥派生的**稳定令牌** |
| 3 | `@deepseek-ai/node-addon-system` **没有 android 平台包**，且 `flock.js` 在非 linux/darwin 直接抛错 | **会话打不开** | 用包内自带的 `src/flock.c` **现场编译**原生模块 + 放行 android |
| 4 | `sharp` 在 android-arm64 无预编译二进制 | **服务启动即崩溃**（`plugin tree failed to load`） | 装官方推荐的 WebAssembly 运行时 `@img/sharp-wasm32` |
| 5 | Termux 上 `link()` 常被 `EPERM` 拒绝 | DSH 首次引导写文件失败 | 编译 26 行的 `link-fix.so`，把失败的 `link()` 降级为复制 |

> 第 3、4 条是**必崩级**问题：不修的话，全新安装的 DSH 要么起不来，要么会话打不开。
> 修复 3 之后还会做一次**功能自检**（真加锁 / 真争用 EAGAIN / 非法 fd EBADF），不是"文件在就算好"。

---

## 三、免翻墙是怎么保证的（实测数据）

在**确认没有 VPN** 的机器上实测（`google.com` / `youtube.com` 均 HTTP 000 失败）：

| 资源 | 主源 | 实测 | 备源 |
|---|---|---|---|
| DSH 本体 | `registry.npmmirror.com` | 515 个包 **1 分钟**装完，包实体 0.24s | `registry.npmjs.org` |
| Android 平台包 62MB | `mirrors.cloud.tencent.com/AndroidSDK` | **4.7 秒**（14 MB/s） | `dl.google.com`（无 VPN 实测可达） |
| 两个包源都挂了 | — | — | 提供离线手动放置指引 + SHA256 |

腾讯镜像的字节已用 **Google 官方 `repository2-3.xml` 公布的 sha1 校验通过**（完全一致），
不是"看着像"就用。校验和固定在 `thirdparty/SHA256SUMS`。

**分发渠道**：因为安装器不需要任何 registry 账号，所以发布物就是一个压缩包 ——
放 Gitee 附件、网盘、或直接发文件都可以。

---

## 四、装完怎么用

**浏览器模式**：打开终端里打印的地址（也存在 `~/.dsh-web-url`），建议加书签。

**APK 版**：
1. 到「下载」点开 `DshShell.apk` 完成安装（系统会问一次"允许安装未知应用"）
2. 打开 DshShell，首次会请求「执行命令」权限 → **必须允许**（这是壳与 Termux 通信的唯一通道）
3. 建议在最近任务里给 **Termux** 和 **DshShell** 都加锁，避免被一键清理强停

**Termux 设置**（安装器会检测并提示，但不会偷偷改你的系统）：

| 项 | 是否必须 |
|---|---|
| `allow-external-apps = true`（`~/.termux/termux.properties`） | **必须** |
| 存储权限 | 推荐（APK 版需要） |
| 自启动 | 推荐 |
| 省电策略「无限制」 | 推荐 |

---

## 五、日常维护

```bash
dshstatus              # 看状态（服务/看门狗/余额）
dshrestart             # 重启服务
dshstop                # 停止服务
dshweb                 # 启动服务（并打印地址）
dsh-mobile-repair      # ★ 一键恢复全部本地修复（DSH 升级后必跑）
```

**DSH 升级/重装后怎么办**：`npm install -g` 会覆盖掉上面那 5 项本地修复，跑一次：
```bash
dsh-mobile-repair
```
它会用**同一套安装器代码**重新应用全部修复并自检（不会动你的会话记录与配置）。

> 已有的 `dsh-repatch-all` 只覆盖第 1、2 项，所以升级后还是用 `dsh-mobile-repair` 更省心。

**想确认自己装得对不对**：重跑 `bash install.sh`，最后会有 15 项自检，例如
```
✓ 令牌有效（入口 303 → 带 cookie 访问 200，认证通过）
✓ flock 原生模块可用（加锁/争用均正常）
✓ sharp 可加载（v0.35.4）
✓ 插件已安装且与分发包逐文件一致（3 个文件）
✓ APK 内令牌与当前服务令牌一致
```

---

## 六、安全

- **分发包零凭据**：不含令牌、不含 API Key、不含 keystore。APK 在**你自己手机上**用
  **你自己**的令牌现场构建，签名私钥也在本机生成。
- **所有下载都校验 SHA256**（含 62MB 平台包）；分发包自身也有 `payload/MANIFEST.sha256`，
  安装前会逐文件校验，被改动会拒绝安装。
- **只监听 `127.0.0.1`**，局域网不可达。
- **APK 只申请 4 项权限**，没有通知/存储/相机/位置/开机自启。
- 详细说明（含"安装过程会改什么"和信任边界）：`docs/权限与安全.md`

---

## 七、不承诺的事（诚实说明）

- **首次安装耗时**：浏览器模式约 1~2 分钟；APK 版还要 62MB 下载 + 1~3 分钟编译。
  磁盘占用：DSH 本体约 279MB，加缓存建议预留 2GB。
- **必须自己填 DeepSeek API Key**（官方计费）。分发的是工具，不是服务。
- **厂商后台策略差异**：MIUI 的「一键清理」会强停应用，被强停的应用会拦截跨应用 intent，
  只能用户手动打开一次 Termux 解锁。各家系统不同，**不把行为写成保证**。
- **界面适配插件依赖 DSH 的原生 CSS 哈希**：DSH 升级可能改哈希，插件会**静默退回原生样式**
  （不会坏，但也没效果）。所以默认钉在已验证版本 `0.1.5-rc.1`。
- **Android 上没有可用的沙箱后端**（Landlock/bwrap/用户命名空间都不可用），
  因此服务以 `DSH_PERMISSION_MODE=danger-full-access` 启动；否则命令执行会被直接拒绝。
  这是平台现实，不是本项目的偏好，详见 `docs/权限与安全.md`。

---

## 八、目录结构

```
dsh-mobile/
├── install.sh              唯一入口（幂等、可重入、失败即停）
├── lib/                    分阶段实现，便于单独排障
│   ├── common.sh           日志/错误/幂等助手（变量统一用 DSHM_* 前缀）
│   ├── preflight.sh        体检：架构/空间/网络/已装检测
│   ├── fetch.sh            唯一下载出口：多源回退 + SHA256 + 离线兜底
│   ├── ui.sh               模式选择菜单
│   ├── stage-deps.sh       依赖（基础 / APK 构建 两批）
│   ├── stage-dsh.sh        装 DSH + 核心补丁 1、2
│   ├── stage-native.sh     补丁 3：现场编译 flock 原生模块 + 功能自检
│   ├── stage-sharp.sh      补丁 4：sharp WASM 运行时
│   ├── stage-termux.sh     运维脚本 + 补丁 5：link-fix.so
│   ├── stage-service.sh    服务启停 + 令牌获取（含快速失败）
│   ├── stage-plugin.sh     插件安装 + 挂载记录（含 YAML 校验）
│   ├── stage-apk.sh        android.jar + 现场编译签名 + 交付
│   └── verify.sh           15 项自检
├── payload/                实际分发内容（由 tools/sync-payload.sh 从现场生成）
│   ├── plugin/             界面适配插件（client.js 浏览器端 + index.js 服务端）
│   ├── termux/bin/         运维脚本
│   ├── termux/own/         本项目自己的脚本（如 dsh-mobile-repair）
│   ├── termux/link-fix.c
│   └── apk/DshShell/       APK 工程源码（令牌为 __TOKEN__ 占位符）
├── tools/
│   ├── sync-payload.sh     同步 + 脱敏 + 泄漏审计 + 漂移检查
│   └── make-release.sh     出发布包（tar.gz + sha256 + 安装说明）
├── thirdparty/             只放校验和，不放 Google 受限组件
└── docs/                   手动安装 / 权限与安全 / 故障排查
```

---

## 九、给维护者

```bash
tools/sync-payload.sh            # 从现场同步 payload（自动脱敏、审计、生成清单）
tools/sync-payload.sh --check    # 只检查"分发包 vs 现场"是否漂移
tools/make-release.sh            # 出发布包到 dist/
```

**改动前建议**：`dsh-snapshot`（快照插件 + Termux 脚本 + APK 工程）。

**三个已经踩过的坑**（都在 `docs/故障排查.md` 的 F 节）：
1. `DSH_HOME` 是 DSH 自己的环境变量，会被注入到子 shell —— 本项目内部一律用 `DSHM_*`。
2. `cordis.patch.yml` 的默认模板含一行 `[]`，**追加**列表项会得到非法 YAML，
   服务下次启动直接失败 —— 要**替换**那一行，写完用 YAML 解析器校验。
3. 插件必须整目录同步（`lib/index.js` 是服务端入口，`package.json` 的 `main` 指向它），
   只拷 `client.js` 会让服务启动即退出。

---

## 十、致谢与许可

- DeepSeek Harness：MIT，https://github.com/deepseek-ai/deepseek-harness
- 本项目：MIT（见 `LICENSE`）。不分发 Android SDK（Google 受限组件），只提供校验和与获取方式。
