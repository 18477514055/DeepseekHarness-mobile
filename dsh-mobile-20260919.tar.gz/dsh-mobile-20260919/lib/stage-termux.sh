#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  stage-termux.sh —— 安装 Termux 侧脚本与 link-fix.so
#  被 install.sh source
# ============================================================

install_termux_scripts() {
  step "⑤ 安装 Termux 运维脚本"
  local src="$DSHM_PAYLOAD/termux/bin"
  [ -d "$src" ] || die "分发包缺少 payload/termux/bin"
  run mkdir -p "$DSHM_PREFIX/bin"
  local n=0 f
  for f in "$src"/*; do
    [ -f "$f" ] || continue
    run cp -f "$f" "$DSHM_PREFIX/bin/$(basename "$f")"
    run chmod 755 "$DSHM_PREFIX/bin/$(basename "$f")"
    n=$((n + 1))
  done
  ok "已安装 $n 个脚本到 $DSHM_PREFIX/bin"

  # 安装器自带脚本（非从现场同步，属于本项目自己写的）
  local own="$DSHM_PAYLOAD/termux/own"
  if [ -d "$own" ]; then
    local m=0 g
    for g in "$own"/*; do
      [ -f "$g" ] || continue
      run cp -f "$g" "$DSHM_PREFIX/bin/$(basename "$g")"
      run chmod 755 "$DSHM_PREFIX/bin/$(basename "$g")"
      m=$((m + 1))
    done
    [ "$m" -gt 0 ] && dim "另有 $m 个本项目脚本（如 dsh-mobile-repair）"
  fi

  # dshlast 依赖的辅助脚本
  if [ -f "$DSHM_PAYLOAD/termux/dsh-tools/session-tail.mjs" ]; then
    run mkdir -p "$DSHM_HOME/.dsh-tools"
    run cp -f "$DSHM_PAYLOAD/termux/dsh-tools/session-tail.mjs" "$DSHM_HOME/.dsh-tools/session-tail.mjs"
    dim "已安装 dsh-tools/session-tail.mjs（dshlast 依赖）"
  fi

  # 让 shell 能找到它们（幂等追加，不重复写）
  local rc="$DSHM_HOME/.bashrc"
  if [ -f "$rc" ] && ! grep -q 'dsh-mobile-setup PATH' "$rc" 2>/dev/null; then
    backup_file "$rc" >/dev/null 2>&1
    run bash -c "printf '\n# dsh-mobile-setup PATH\nexport PATH=\"\$PREFIX/bin:\$PATH\"\n' >> '$rc'"
  fi
}

# ------------------------------------------------------------
#  link-fix.so：把 Termux 上被 EPERM 拒绝的 link() 降级为复制。
#  没有它，DSH 首次引导写文件时可能直接失败。
# ------------------------------------------------------------
install_link_fix() {
  step "⑥ 编译 link-fix.so"
  local csrc="$DSHM_PAYLOAD/termux/link-fix.c"
  local c="$DSHM_HOME/link-fix.c"
  local so="$DSHM_HOME/link-fix.so"
  [ -f "$csrc" ] || die "分发包缺少 link-fix.c"

  if [ -f "$so" ] && [ -f "$c" ] && cmp -s "$csrc" "$c" && [ "$so" -nt "$c" ]; then
    ok "link-fix.so 已是最新，跳过编译"
    return 0
  fi

  [ -f "$c" ] && backup_file "$c"
  run cp -f "$csrc" "$c"
  have clang || die "缺少 clang，无法编译 link-fix.so" "pkg install -y clang"
  if ! run clang -shared -fPIC -O2 -o "$so" "$c" -ldl; then
    die "link-fix.so 编译失败" "pkg install -y clang && clang -shared -fPIC -O2 -o ~/link-fix.so ~/link-fix.c -ldl"
  fi
  [ "$DRY_RUN" = 1 ] || chmod 755 "$so" 2>/dev/null
  ok "link-fix.so 编译完成（$(human_size "$(stat -c %s "$so" 2>/dev/null || echo 0)")）"
  dim "注意：服务启动时会带上 LD_PRELOAD=$so"
}
