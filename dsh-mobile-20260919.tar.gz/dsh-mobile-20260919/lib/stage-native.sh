#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  stage-native.sh —— 为 Android 编译 flock 原生模块（Termux 专项修复）
#  被 install.sh source
#
#  背景（这是踩出来的坑，务必理解）：
#    @deepseek-ai/node-addon-system 在 optionalDependencies 里只声明了
#    darwin-arm64/x64、linux-x64/arm64 —— ①没有 android 平台包，
#    ②lib/flock.js 也会在非 linux/darwin 平台直接抛 ERR_FLOCK_UNSUPPORTED_PLATFORM。
#    而 dsh-session-persistence-jsonl 拿不到 flock 时会**直接抛错**（不是降级），
#    表现为会话打不开。
#
#  好消息：该 npm 包**自带 C 源码**（src/flock.c），且 Termux 有 clang 与 node 头文件，
#  所以可以本机编译，不需要任何预编译产物、也不需要额外下载。
# ============================================================

native_base() { echo "$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai"; }

# Node 头文件目录：优先目标 prefix，其次跟随实际使用的 node 二进制所在 prefix
# （隔离安装时 DSHM_PREFIX 可能不是 node 的 prefix，所以必须有回退）
node_include_dir() {
  local cand
  for cand in \
      "$DSHM_PREFIX/include/node" \
      "$(dirname "$(dirname "$(command -v node 2>/dev/null)")")/include/node" \
      "${PREFIX:-}/include/node"
  do
    [ -n "$cand" ] && [ -f "$cand/node_api.h" ] && { printf '%s\n' "$cand"; return 0; }
  done
  return 1
}

# 原生模块功能自检：真加锁、真争用、真报错（不是只看文件存在）
native_selftest() {
  local dsh_root="$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh"
  local out
  out=$( cd "$dsh_root" && node --input-type=module -e "
import { openSync, closeSync } from 'node:fs'
import { tryLockExclusive } from '@deepseek-ai/node-addon-system/flock'
const p = process.env.HOME + '/.flock-selftest.lock'
const fd = openSync(p, 'w')
try { await tryLockExclusive(fd); console.log('SELFTEST_LOCK_OK') } catch(e) { console.log('SELFTEST_LOCK_FAIL', e.code || e.message) }
const fd2 = openSync(p, 'w')
try { await tryLockExclusive(fd2); console.log('SELFTEST_CONTENTION_BAD') } catch(e) { console.log('SELFTEST_CONTENTION_' + e.code) }
closeSync(fd); closeSync(fd2)
" 2>&1 )
  rm -f "$DSHM_HOME/.flock-selftest.lock" 2>/dev/null
  case "$out" in
    *SELFTEST_LOCK_OK*SELFTEST_CONTENTION_EAGAIN*)
      return 0 ;;
    *)
      printf '%s\n' "$out" | sed 's/^/     /' >&2
      return 1 ;;
  esac
}

ensure_android_native() {
  step "④b 为 Android 编译 flock 原生模块"
  local plat; plat=$(node -p 'process.platform' 2>/dev/null)
  if [ "$plat" != "android" ]; then
    dim "当前平台是 ${plat:-未知}，此步不需要（官方已覆盖）"
    return 0
  fi

  local base; base=$(native_base)
  local ns="$base/node-addon-system"
  local pkg="$base/node-addon-system-android-arm64"
  local arch; arch=$(node -p 'process.arch' 2>/dev/null)

  [ -f "$ns/lib/flock.js" ] || die "找不到 $ns/lib/flock.js（DSH 版本结构可能变了）" \
      "检查 DSH 是否安装完整：npm install -g @deepseek-ai/dsh@$DSHM_PIN_VERSION"
  [ -f "$ns/src/flock.c" ] || die "该 DSH 版本没有附带 $ns/src/flock.c，无法在 Android 上编译 flock" \
      "这属于上游结构变化，请在项目仓库提 issue；临时可用 --mode=browser 但会话可能打不开"

  # ---- 1) 放行 android 平台（幂等；保留官方原文件 .orig）----
  if grep -q "platform !== 'android'" "$ns/lib/flock.js" 2>/dev/null; then
    ok "flock.js 已放行 android 平台"
  else
    backup_file "$ns/lib/flock.js"
    if [ "$DRY_RUN" = 1 ]; then
      printf '   %s[dry-run] 修改 flock.js 允许 android%s\n' "$C_BLU" "$C_OFF"
    else
      cp -a "$ns/lib/flock.js" "$ns/lib/flock.js.orig"
      python3 - "$ns/lib/flock.js" <<'PY' || die "修改 flock.js 失败（源码结构与预期不符）"
import sys
f = sys.argv[1]
s = open(f, encoding="utf-8").read()
old = "platform !== 'linux' && platform !== 'darwin'"
new = "platform !== 'linux' && platform !== 'darwin' && platform !== 'android'"
if old not in s:
    sys.exit(3)
open(f, "w", encoding="utf-8").write(s.replace(old, new, 1))
PY
    fi
    ok "已放行 android（原文件备份为 flock.js.orig）"
  fi

  # ---- 2) 编译原生模块 ----
  local csrc="$ns/src/flock.c"
  local so="$pkg/bin/system.node"
  if [ -f "$so" ] && [ "$so" -nt "$csrc" ]; then
    ok "原生模块已存在且新于源码，跳过编译"
  else
    have clang || die "缺少 clang，无法编译 flock 原生模块" "pkg install -y clang"
    local inc; inc=$(node_include_dir) \
      || die "找不到 Node 头文件（node_api.h）" "pkg install -y nodejs-lts"
    dim "Node 头文件目录：$inc"
    run mkdir -p "$pkg/bin"
    if [ ! -f "$pkg/package.json" ] && [ "$DRY_RUN" = 0 ]; then
      cat > "$pkg/package.json" <<EOF
{
  "name": "@deepseek-ai/node-addon-system-android-arm64",
  "version": "0.1.2",
  "description": "Prebuilt system primitives for android-arm64 (locally compiled for Termux)",
  "os": ["android"],
  "cpu": ["arm64"],
  "main": "bin/system.node",
  "license": "BSD-3-Clause"
}
EOF
    fi
    dim "clang -shared -fPIC -O2 -I$inc -o bin/system.node src/flock.c"
    run clang -shared -fPIC -O2 -I"$inc" -o "$so" "$csrc" \
      || die "编译 flock 原生模块失败" \
             "clang -shared -fPIC -O2 -I'$inc' -o '$so' '$csrc'"
    [ "$DRY_RUN" = 1 ] || chmod 755 "$so" 2>/dev/null
    ok "原生模块编译完成（$(human_size "$(stat -c %s "$so" 2>/dev/null || echo 0)")）"
  fi

  # ---- 3) 功能自检：真的能加锁、真的能拒绝争用 ----
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] 原生模块功能自检（加锁/争用）%s\n' "$C_BLU" "$C_OFF"
    return 0
  fi
  if native_selftest; then
    ok "原生模块功能自检通过（加锁 OK / 争用 EAGAIN）"
  else
    die "flock 原生模块功能自检未通过（上面是实际输出）" \
        "重跑安装脚本；仍失败请把上面的输出发给维护者"
  fi
}
