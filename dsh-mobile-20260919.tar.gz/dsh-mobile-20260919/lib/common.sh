#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  common.sh —— 公共约定：日志、错误、配置、幂等助手
#  被 install.sh 与 lib/*.sh 共同 source，不单独运行
#
#  可覆盖的变量（用于隔离测试，绝不动到真环境）：
#    DSHM_HOME    目标家目录（默认 $HOME）
#    DSHM_PREFIX  目标 Termux prefix（默认 $PREFIX）
#    DSHM_CACHE   下载缓存目录
#    DRY_RUN=1   只打印将做什么，不落任何改动
# ============================================================

DSHM_HOME="${DSHM_HOME:-$HOME}"
DSHM_PREFIX="${DSHM_PREFIX:-${PREFIX:-/data/data/com.termux/files/usr}}"
DSHM_CACHE="${DSHM_CACHE:-${XDG_CACHE_HOME:-$DSHM_HOME/.cache}/dsh-mobile}"
DRY_RUN="${DRY_RUN:-0}"
ASSUME_YES="${ASSUME_YES:-0}"

# 分发包根目录（由 install.sh 注入；此处兜底）
DSHM_REPO="${DSHM_REPO:-$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)}"
DSHM_PAYLOAD="$DSHM_REPO/payload"

LOG_DIR="$DSHM_HOME/.dsh/run"
SETUP_LOG="$LOG_DIR/setup.log"

# ---------- 颜色与日志 ----------
if [ -t 1 ]; then
  C_RED=$'\033[31m'; C_GRN=$'\033[32m'; C_YEL=$'\033[33m'; C_BLU=$'\033[36m'; C_BLD=$'\033[1m'; C_OFF=$'\033[0m'
else
  C_RED=''; C_GRN=''; C_YEL=''; C_BLU=''; C_BLD=''; C_OFF=''
fi

_log() {  # _log <级别> <文本...>
  local lv="$1"; shift
  mkdir -p "$LOG_DIR" 2>/dev/null
  printf '[%s] %-5s %s\n' "$(date '+%F %T')" "$lv" "$*" >> "$SETUP_LOG" 2>/dev/null
}
info() { printf '%s\n' "$*"; _log INFO "$*"; }
ok()   { printf '%s✅ %s%s\n' "$C_GRN" "$*" "$C_OFF"; _log OK "$*"; }
warn() { printf '%s⚠️  %s%s\n' "$C_YEL" "$*" "$C_OFF" >&2; _log WARN "$*"; }
step() { printf '\n%s▸ %s%s\n' "$C_BLD" "$*" "$C_OFF"; _log STEP "$*"; }
dim()  { printf '   %s\n' "$*"; }

# die <人话原因> [可复制的修复命令]
die() {
  local reason="$1" fix="${2:-}"
  printf '\n%s❌ %s%s\n' "$C_RED" "$reason" "$C_OFF" >&2
  _log FAIL "$reason"
  if [ -n "$fix" ]; then
    printf '   修复：%s%s%s\n\n' "$C_BLU" "$fix" "$C_OFF" >&2
  fi
  exit 1
}

# ---------- 幂等助手 ----------
# have <命令>：命令是否存在
have() { command -v "$1" >/dev/null 2>&1; }

# run <命令...>：受 DRY_RUN 控制的执行
run() {
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] %s%s\n' "$C_BLU" "$*" "$C_OFF"
    _log DRY "$*"
    return 0
  fi
  _log RUN "$*"
  "$@"
}

# pkg_installed <包名>
pkg_installed() { dpkg-query -W -f='${Status}' "$1" 2>/dev/null | grep -q "install ok installed"; }

# ensure_pkgs <包...>：只装缺的，已装的跳过（幂等核心）
ensure_pkgs() {
  local missing=()
  local p
  for p in "$@"; do pkg_installed "$p" || missing+=("$p"); done
  [ ${#missing[@]} -eq 0 ] && { ok "依赖已齐（$*）"; return 0; }
  info "需要安装：${missing[*]}"
  export DEBIAN_FRONTEND=noninteractive
  if ! run pkg install -y "${missing[@]}"; then
    die "依赖安装失败：${missing[*]}" "pkg update && pkg install -y ${missing[*]}"
  fi
  # 复核：pkg 返回 0 也可能没装上（网络半途断过）
  local still=()
  for p in "${missing[@]}"; do pkg_installed "$p" || still+=("$p"); done
  if [ ${#still[@]} -gt 0 ]; then
    die "这些包仍然没装上：${still[*]}" "pkg update && pkg install -y ${still[*]}"
  fi
  ok "依赖安装完成（${missing[*]}）"
}

# backup_file <路径> [备份根目录]：改动前先备份（幂等：同一次运行只备份一次）
backup_file() {
  local f="$1" root="${2:-$DSHM_HOME/.dsh-backup-setup}"
  [ -f "$f" ] || return 0
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] 备份 %s%s\n' "$C_BLU" "$f" "$C_OFF"
    return 0
  fi
  local tag="$root/$(date +%Y%m%d_%H%M%S)"
  local dest="$tag/$(printf '%s' "$f" | sed 's|^/||; s|/|__|g')"
  mkdir -p "$tag"
  if [ ! -f "$dest" ]; then
    cp -a "$f" "$dest"
    dim "已备份 $f → $dest"
  fi
}

# confirm <问题>：交互确认；--yes 或非交互时自动通过
confirm() {
  [ "$ASSUME_YES" = 1 ] && return 0
  [ -t 0 ] || return 0
  local a
  printf '%s [Y/n] ' "$1"
  read -r a || a=""
  case "$a" in ""|y|Y|yes|YES) return 0 ;; *) return 1 ;; esac
}

# human_size <字节>（纯 shell 整除，不依赖 bc —— 新装的 Termux 没有 bc）
human_size() {
  local b="${1:-0}"
  case "$b" in ''|*[!0-9]*) b=0 ;; esac
  if [ "$b" -ge 1073741824 ]; then
    printf '%d.%d GB' $((b / 1073741824)) $(((b % 1073741824) * 10 / 1073741824))
  elif [ "$b" -ge 1048576 ]; then
    printf '%d MB' $((b / 1048576))
  elif [ "$b" -ge 1024 ]; then
    printf '%d KB' $((b / 1024))
  else
    printf '%s B' "$b"
  fi
}
