#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  stage-sharp.sh —— 修复 sharp 在 android-arm64 上无法加载的问题
#  被 install.sh source
#
#  背景：
#    @deepseek-ai/dsh-attachment-local 会 import sharp。sharp 在 android-arm64
#    上没有预编译二进制，于是整个插件树加载失败、服务直接退出：
#      Error: dsh: plugin tree failed to load: … Could not load the "sharp" module
#             using the android-arm64 runtime
#    sharp 官方给的解法就是装 WebAssembly 运行时 @img/sharp-wasm32。
#
#  做法（确定性、只增不改）：
#    1) 先用"能不能 require 成功"作为唯一判据
#    2) 在临时目录里让 npm 解析出完整依赖树（含 @emnapi/runtime）
#    3) 只把缺的包拷进 DSH 自己的 node_modules —— 不动它的 package.json
# ============================================================

sharp_ok() {
  local nm="$1"
  node -e "const s=require('$nm/sharp'); if(!s.versions) process.exit(1)" >/dev/null 2>&1
}

sharp_version() {
  node -e "try{console.log(require('$1/sharp/package.json').version)}catch(e){console.log('')}" 2>/dev/null
}

ensure_sharp_wasm() {
  step "④c 修复 sharp（Android 无预编译产物 → 装 WASM 运行时）"
  local D="$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh"
  local NM="$D/node_modules"

  if [ ! -f "$NM/sharp/package.json" ]; then
    dim "这份 DSH 没装 sharp，跳过"
    return 0
  fi

  if [ "$DRY_RUN" = 0 ] && sharp_ok "$NM"; then
    ok "sharp 本来就能用（v$(sharp_version "$NM")），无需修复"
    return 0
  fi

  local ver; ver=$(sharp_version "$NM")
  [ -n "$ver" ] || die "读不到 sharp 版本（$NM/sharp 可能损坏）"
  dim "sharp v$ver 在 android-arm64 无预编译二进制 → 改装 WebAssembly 运行时"

  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] 安装 @img/sharp-wasm32@%s 及其依赖 @emnapi/runtime%s\n' "$C_BLU" "$ver" "$C_OFF"
    return 0
  fi

  # ---- 在临时目录里解析完整依赖树 ----
  local tmp="$DSHM_CACHE/sharp-wasm-$ver"
  rm -rf "$tmp"; mkdir -p "$tmp"
  local reg="$NPM_MIRROR"
  curl -sI --max-time 10 "$reg/" >/dev/null 2>&1 || reg="$NPM_OFFICIAL"

  ( cd "$tmp" && npm init -y >/dev/null 2>&1 \
    && npm install --no-save --no-fund --no-audit --registry="$reg" "@img/sharp-wasm32@$ver" ) \
    || die "安装 sharp WASM 运行时失败（npm 出错）" \
           "npm install --no-save @img/sharp-wasm32@$ver --registry=$reg"

  # ---- 只增不改地拷进 DSH 的 node_modules ----
  local scope pkg n
  for scope in "@img" "@emnapi"; do
    [ -d "$tmp/node_modules/$scope" ] || continue
    mkdir -p "$NM/$scope"
    for pkg in "$tmp/node_modules/$scope"/*; do
      [ -d "$pkg" ] || continue
      n=$(basename "$pkg")
      if [ -e "$NM/$scope/$n" ]; then
        dim "已存在，跳过：$scope/$n"
      else
        cp -a "$pkg" "$NM/$scope/$n"
        dim "已安装：$scope/$n"
      fi
    done
  done

  # ---- 复核：必须真的能 require ----
  if sharp_ok "$NM"; then
    ok "sharp 修复完成（v$(sharp_version "$NM")，走 WebAssembly）"
  else
    node -e "require('$NM/sharp')" 2>&1 | tail -5 | sed 's/^/     /' >&2
    die "修复后 sharp 仍然无法加载" \
        "手动执行：npm i -g @deepseek-ai/dsh@$DSHM_PIN_VERSION 后重跑安装脚本"
  fi

  # 提示：WASM 版比原生版慢，但在这个平台上这是唯一可行方案
  dim "说明：WASM 版图像处理比原生版慢一些，但 Android 上没有原生预编译产物"
}
