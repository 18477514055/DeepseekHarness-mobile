#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  preflight.sh —— 动手之前先体检：不合格就直接说原因，不碰任何东西
#  被 install.sh source
# ============================================================

# 检查结果汇总（不直接退出，收集完一起报，用户一次就能看完所有问题）
PF_FATAL=()
PF_WARN=()
pf_fatal() { PF_FATAL+=("$1"); }
pf_warn()  { PF_WARN+=("$1"); }

# ---------- 1) 必须在 Termux 里 ----------
preflight_env() {
  case "$DSHM_PREFIX" in
    *com.termux*) : ;;
    *) pf_fatal "看起来不是在 Termux 里运行（prefix=$DSHM_PREFIX）。本安装包只能在 Termux 里用。" ;;
  esac
  have pkg || pf_fatal "找不到 pkg 命令，请确认用的是 Termux 官方版（不是 F-Droid 之外的第三方终端）。"
  [ -w "$DSHM_PREFIX/bin" ] || [ -w "$DSHM_HOME" ] || pf_fatal "没有写权限：$DSHM_PREFIX/bin 与 $DSHM_HOME"
}

# ---------- 2) CPU 架构 ----------
preflight_arch() {
  local a; a=$(uname -m)
  case "$a" in
    aarch64|arm64) : ;;
    *) pf_fatal "本包的预编译依赖只覆盖 arm64-v8a，当前架构是 $a。" ;;
  esac
}

# ---------- 3) 剩余空间 ----------
# need_mb <MB> <用途说明>
preflight_space() {
  local need_mb="$1" what="$2"
  local avail_mb
  avail_mb=$(df -Pk "$DSHM_HOME" 2>/dev/null | awk 'NR==2{print int($4/1024)}')
  [ -z "$avail_mb" ] && { pf_warn "读不到剩余空间，跳过检查"; return 0; }
  if [ "$avail_mb" -lt "$need_mb" ]; then
    pf_fatal "剩余空间不足：需要约 ${need_mb}MB（$what），当前只有 ${avail_mb}MB。"
  else
    dim "剩余空间 ${avail_mb}MB ≥ 需要 ${need_mb}MB ✓"
  fi
}

# ---------- 4) 网络（这一条最关键：没网就什么也做不了） ----------
preflight_net() {
  local ok_npmmirror=0 ok_npmjs=0 ok_tencent=0
  curl -sI --max-time 12 https://registry.npmmirror.com/ >/dev/null 2>&1 && ok_npmmirror=1
  curl -sI --max-time 12 https://registry.npmjs.org/    >/dev/null 2>&1 && ok_npmjs=1
  curl -sI --max-time 12 https://mirrors.cloud.tencent.com/ >/dev/null 2>&1 && ok_tencent=1

  [ "$ok_npmmirror" = 1 ] && dim "registry.npmmirror.com 可达 ✓" || pf_warn "registry.npmmirror.com 不可达，将改用官方源（较慢）"
  [ "$ok_npmjs" = 1 ]     && dim "registry.npmjs.org 可达 ✓"     || pf_warn "registry.npmjs.org 不可达"
  if [ "$ok_npmmirror" = 0 ] && [ "$ok_npmjs" = 0 ]; then
    pf_fatal "两个 npm 源都连不上，无法安装 DSH。请先确认手机能上网。"
  fi
  if [ "$ok_tencent" = 1 ]; then
    dim "腾讯云镜像（android.jar）可达 ✓"
  else
    pf_warn "腾讯云镜像不可达，打包 APK 时会自动改用 Google 源"
  fi
}

# ---------- 5) 已有安装？ ----------
preflight_existing() {
  DSHM_ALREADY=0
  if [ -f "$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/package.json" ]; then
    DSHM_ALREADY=1
    local v; v=$(node -e "console.log(require('$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/package.json').version)" 2>/dev/null || echo "?")
    dim "已检测到已安装的 DSH：v$v（将走升级/修复流程，保留你的会话记录与配置）"
  else
    dim "未检测到 DSH，将全新安装"
  fi
  if [ -f "$DSHM_HOME/.dsh-web-url" ]; then
    dim "已存在服务地址记录 ~/.dsh-web-url（令牌将优先复用，不变更你的入口）"
  fi
  DSHM_SERVICE_RUNNING=0
  if curl -s -o /dev/null --max-time 3 http://127.0.0.1:3080/ 2>/dev/null; then
    DSHM_SERVICE_RUNNING=1
    dim "DSH 服务当前正在运行（安装过程不会重启它，避免打断你正在做的事）"
  fi
}

# ---------- 汇总 ----------
preflight_report() {
  if [ ${#PF_WARN[@]} -gt 0 ]; then
    local w
    for w in "${PF_WARN[@]}"; do warn "$w"; done
  fi
  if [ ${#PF_FATAL[@]} -gt 0 ]; then
    printf '\n%s体检未通过，共 %d 项问题：%s\n' "$C_RED" "${#PF_FATAL[@]}" "$C_OFF" >&2
    local f
    for f in "${PF_FATAL[@]}"; do printf '   · %s\n' "$f" >&2; done
    printf '\n   未做任何改动。\n\n' >&2
    exit 1
  fi
  ok "体检通过"
}
