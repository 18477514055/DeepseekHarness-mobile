#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  ui.sh —— 交互界面：安装模式选择菜单
#  被 install.sh source
#
#  需求（用户原话）：依赖装完之后弹出提示，问是"浏览器模式"
#  还是"进一步打包成本机 APK 版"，并把 APK 版的额外需要列清楚。
# ============================================================

hr() { printf '%s\n' "────────────────────────────────────────────────────────"; }

# 计算构建工具的额外体积（用于诚实告知，不瞎写数字）
apk_extra_size_hint() {
  local total=0 p sz
  for p in openjdk-21 aapt aapt2 apksigner d8 clang; do
    sz=$(dpkg-query -W -f='${Installed-Size}' "$p" 2>/dev/null)
    case "$sz" in ''|*[!0-9]*) continue ;; esac
    total=$((total + sz))
  done
  if [ "$total" -gt 0 ]; then printf '约 %s（含 android.jar 62MB）' "$(human_size $((total * 1024 + 66000000)))"
  else printf '约 400MB（含 android.jar 62MB）'; fi
}

choose_mode() {
  # 已经通过参数指定就不问
  if [ -n "${MODE:-}" ]; then
    case "$MODE" in browser|apk) ok "安装模式（命令行指定）：$MODE"; return 0 ;;
      *) die "无效的 --mode=$MODE（只能是 browser 或 apk）" ;;
    esac
  fi
  # 非交互（管道执行）时默认浏览器模式，最稳
  if [ ! -t 0 ]; then
    MODE="browser"
    warn "非交互环境，自动选择「浏览器模式」（如需 APK 版请加 --mode=apk）"
    return 0
  fi

  printf '\n'
  hr
  printf ' %s请选择安装模式%s\n' "$C_BLD" "$C_OFF"
  hr
  printf '  %s1) 浏览器模式%s\n' "$C_GRN" "$C_OFF"
  printf '     最省事，装完用手机浏览器打开 DSH 即可。\n'
  printf '     不需要额外下载、不需要编译，约 1~2 分钟完成。\n'
  printf '     代价：没有原生壳（没有等待页进度条、页面内一键更新、\n'
  printf '           后台空闲回收）。界面适配插件照常生效。\n'
  printf '\n'
  printf '  %s2) 本机 APK 版%s\n' "$C_GRN" "$C_OFF"
  printf '     在浏览器模式基础上，再在这台手机上现场编译并签名一个 APK，\n'
  printf '     获得原生壳：等待页进度条 / 页面内一键更新 / 后台空闲 20 分钟回收。\n'
  printf '     %s额外需要：%s\n' "$C_YEL" "$C_OFF"
  printf '       · 再装构建工具包：%s\n' "$(apk_extra_size_hint)"
  printf '       · 下载 android.jar 平台包 62MB（实测约 5 秒，无需翻墙）\n'
  printf '       · 编译 + 签名，约 1~3 分钟\n'
  printf '       · 授予 Termux 存储权限（用于把 APK 放到 Download 目录）\n'
  printf '       · 允许 Termux 安装未知应用（系统会弹一次确认）\n'
  printf '       · 生成的 APK 用%s本机自己的令牌%s现场签名，不含任何可外泄的凭据。\n' "$C_GRN" "$C_OFF"
  hr
  local a
  while :; do
    printf ' 请输入 1 或 2 [默认 2]: '
    read -r a || a=""
    case "$a" in
      1) MODE="browser"; break ;;
      2|"") MODE="apk"; break ;;
      *) printf ' %s请输入 1 或 2%s\n' "$C_YEL" "$C_OFF" ;;
    esac
  done
  hr
  if [ "$MODE" = "apk" ]; then ok "已选择：本机 APK 版"; else ok "已选择：浏览器模式"; fi
}
