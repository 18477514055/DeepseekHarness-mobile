#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  stage-plugin.sh —— 安装界面适配插件 dsh-mobile-adapt
#  被 install.sh source
#
#  插件在 DSH 里的挂载方式（与本机已验证的做法一致）：
#    1) 模块放到 profile 的 node_modules/ 下
#    2) 在 profile 的 cordis.patch.yml 里 insert 一条挂载记录
#
#  ★ 踩过的坑：全新 profile 的 cordis.patch.yml 模板里有一行 `[]`
#    （表示"空数组"）。如果直接在后面追加列表项，就变成
#        []
#        - insert:
#    这是**非法 YAML**，服务下次启动会直接失败（parsePatchList 报错）。
#    正确做法：把 `[]` 那一行替换掉，而不是追加。
#  因此这里：写入前判断是不是空数组 → 替换；写完立刻用 YAML 解析器校验，
#  校验不过就还原备份并报错 —— 绝不留给用户一个起不来的服务。
# ============================================================

profile_dir() { echo "$DSHM_HOME/.dsh/profiles/web"; }

PATCH_BLOCK='- insert:
    - id: mobile-adapt
      name: dsh-mobile-adapt'

# 用 DSH 自带的 yaml 解析器校验（失败时输出原因并返回非 0）
yaml_validate_array() {
  local f="$1"
  local lib="$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/node_modules/yaml"
  [ -d "$lib" ] || return 0        # 没有解析器就跳过，不阻塞安装
  node -e '
const YAML = require(process.argv[1])
const fs = require("fs")
const v = YAML.parse(fs.readFileSync(process.argv[2], "utf8"))
if (!Array.isArray(v)) { console.error("顶层不是数组，而是 " + typeof v); process.exit(1) }
' "$lib" "$f" 2>&1
}

install_plugin() {
  step "⑧ 安装界面适配插件"
  local prof; prof=$(profile_dir)
  local src="$DSHM_PAYLOAD/plugin/dsh-mobile-adapt"
  local dst="$prof/node_modules/dsh-mobile-adapt"

  [ -d "$src" ] || die "分发包缺少 payload/plugin/dsh-mobile-adapt"
  if [ ! -d "$prof" ]; then
    die "profile 目录还不存在：$prof（服务应在此之前已成功启动过一次）" \
        "先运行一次 dshweb，再重跑本安装脚本"
  fi

  # ---------- 1) 模块文件（整目录，含服务端入口 lib/index.js）----------
  [ -f "$src/lib/index.js" ] || die "分发包里的插件缺 lib/index.js（服务端入口）—— 包不完整" \
      "tools/sync-payload.sh   # 重新生成 payload"
  run mkdir -p "$dst"
  [ -f "$dst/lib/client.js" ] && backup_file "$dst/lib/client.js"
  [ -f "$dst/lib/index.js" ] && backup_file "$dst/lib/index.js"
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] 复制插件模块到 %s%s\n' "$C_BLU" "$dst" "$C_OFF"
  else
    ( cd "$src" && tar cf - . ) | ( cd "$dst" && tar xf - )
  fi
  ok "插件模块已就位（$(cd "$src" && find . -type f | wc -l) 个文件）"

  # ---------- 2) 挂载记录 ----------
  local patch="$prof/cordis.patch.yml"
  if [ -f "$patch" ] && grep -q 'id:[[:space:]]*mobile-adapt' "$patch"; then
    ok "挂载记录已存在，未改动 $patch"
    return 0
  fi

  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] 写入挂载记录到 %s（模板若是空数组则替换掉 `[]`）%s\n' "$C_BLU" "$patch" "$C_OFF"
    return 0
  fi

  # 备份（显式记录路径，校验失败时用来还原）
  local bak=""
  if [ -f "$patch" ]; then
    bak="$patch.bak-$(date +%Y%m%d_%H%M%S)"
    cp -a "$patch" "$bak"
    dim "已备份原文件 → $bak"
  fi

  # 判断现有内容：空/仅注释/空数组模板 vs 非空列表
  local sig
  sig=$(grep -vE '^[[:space:]]*(#|$)' "$patch" 2>/dev/null | tr -d '[:space:]')

  if [ ! -f "$patch" ] || [ -z "$sig" ] || [ "$sig" = "[]" ]; then
    if [ -f "$patch" ]; then
      sed -i -E '/^[[:space:]]*\[\][[:space:]]*$/d' "$patch"   # 去掉那行空数组（保留注释）
    fi
    printf '%s\n' "$PATCH_BLOCK" >> "$patch"
    ok "已写入挂载记录（模板原为空数组，已替换）"
  else
    [ -n "$(tail -c 1 "$patch" 2>/dev/null)" ] && printf '\n' >> "$patch"   # 补末尾换行
    printf '%s\n' "$PATCH_BLOCK" >> "$patch"
    ok "已追加挂载记录到已有补丁列表"
  fi

  # ---------- 3) 立刻校验：非法 YAML 会让服务起不来 ----------
  local err
  if ! err=$(yaml_validate_array "$patch"); then
    if [ -n "$bak" ]; then
      cp -a "$bak" "$patch"
      warn "已恢复原文件：$patch"
    fi
    die "写好的挂载记录不是合法 YAML，已中止（解析器输出见上）" \
        "手动把下面这段加到 $patch 的顶层数组里：
$PATCH_BLOCK"
  fi
  ok "挂载记录 YAML 校验通过"

  # ---------- 4) 记录指纹，便于日后查漂移 ----------
  mkdir -p "$DSHM_HOME/.dsh-mobile"
  sha256sum "$dst/lib/client.js" | awk '{print $1}' > "$DSHM_HOME/.dsh-mobile/plugin.sha256"
}
