#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  stage-service.sh —— 服务启停 + 令牌获取
#  被 install.sh source
#
#  为什么不直接用 dshweb：那个脚本把路径写死了（面向本机日常使用）。
#  这里用同一套经过验证的参数自己拉起服务，好处是路径全部可覆盖，
#  因此可以在"隔离目录"里完整演练，不碰用户正在跑的服务。
# ============================================================

DSHM_PORT="${DSHM_PORT:-3080}"
DSHM_URL_FILE="$DSHM_HOME/.dsh-web-url"

svc_up() {
  curl -s -o /dev/null --max-time 3 "http://127.0.0.1:$DSHM_PORT/" 2>/dev/null
}

svc_pid() {
  # 精确匹配本前缀下的 bin.js web 进程（不用 pgrep -f，避免自匹配）
  local p
  for p in /proc/[0-9]*; do
    [ -r "$p/cmdline" ] || continue
    if tr '\0' ' ' < "$p/cmdline" 2>/dev/null | grep -q "$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/lib/bin.js web"; then
      basename "$p"
    fi
  done
}

# start_service <是否阻塞等待>：拉起服务并等出令牌地址
start_service() {
  local bin; bin=$(dsh_bin_path)
  [ -f "$bin" ] || die "找不到 DSH 入口 $bin"

  local w="$DSHM_HOME/.dsh/run"
  local log="$w/dsh.log"
  run mkdir -p "$w"

  local preload=""
  [ -f "$DSHM_HOME/link-fix.so" ] && preload="$DSHM_HOME/link-fix.so"

  dim "启动服务（首次引导需要 1~2 分钟，期间 CPU 满载属正常）…"
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] 拉起: node --expose-internals %s web --host 127.0.0.1 --port %s%s\n' \
      "$C_BLU" "$bin" "$DSHM_PORT" "$C_OFF"
    return 0
  fi

  rm -f "$DSHM_HOME/.dsh/.credentials.yaml.lock" 2>/dev/null
  : > "$log"

  # 关键环境：
  #   HOME      指向目标家目录
  #   DSH_HOME  ★DSH 自己的配置根（= <家目录>/.dsh）。注意这与本脚本内部使用的
  #             DSHM_* 变量不是一回事：DSH 会把 DSH_HOME 注入到子 shell，
  #             我们若用同名变量就会被它覆盖（曾经踩过，见 docs）
  #   LD_PRELOAD 修 link()
  #   权限模式按 Android 现实（本机没有可用沙箱后端，只有 danger-full-access
  #   才能执行命令 —— 详见 docs/权限与安全.md）
  setsid nohup env HOME="$DSHM_HOME" \
      DSH_HOME="$DSHM_HOME/.dsh" \
      DSH_PERMISSION_MODE="${DSH_PERMISSION_MODE:-danger-full-access}" \
      LD_PRELOAD="$preload" \
      node --expose-internals "$bin" web --no-open --host 127.0.0.1 --port "$DSHM_PORT" \
      > "$log" 2>&1 < /dev/null &
  disown 2>/dev/null || true

  # 轮询日志里的令牌地址（最多 6 分钟，与 dshweb 一致）
  # ★ 同时做"快速失败"：进程若已退出，立刻报错，不让用户白等 6 分钟
  local i url gone=0
  for i in $(seq 1 120); do
    sleep 3
    url=$(grep -o "http://127\.0\.0\.1:$DSHM_PORT/?token=[A-Za-z0-9_-]*" "$log" 2>/dev/null | head -1)
    if [ -n "$url" ]; then
      printf '%s\n' "$url" > "$DSHM_URL_FILE"
      ok "服务已就绪：$url"
      return 0
    fi
    # 进程活着吗？（连续两次探测不到才算真的退出，避免 exec 瞬间误判）
    if [ -z "$(svc_pid)" ]; then
      gone=$((gone + 1))
      if [ "$gone" -ge 2 ]; then
        printf '\n'
        printf '%s── 服务启动失败：进程已退出，日志末尾 ──%s\n' "$C_RED" "$C_OFF" >&2
        tail -25 "$log" >&2
        die "DSH 启动后立刻退出（原因见上面的日志）" "cat $log"
      fi
    else
      gone=0
    fi
    printf '.'
  done
  printf '\n'
  printf '%s── 日志末尾 ──%s\n' "$C_YEL" "$C_OFF" >&2
  tail -25 "$log" >&2
  die "服务启动超时（6 分钟）" "tail -50 $log"
}

stop_service() {
  local pid; pid=$(svc_pid)
  if [ -z "$pid" ]; then
    dim "服务未在运行"
    return 0
  fi
  dim "停止服务（PID $pid）…"
  run kill "$pid" 2>/dev/null || true
  local i
  for i in $(seq 1 20); do
    sleep 1
    [ -z "$(svc_pid)" ] && { ok "服务已停止"; return 0; }
  done
  warn "进程未退出，发送 SIGKILL"
  run kill -9 "$(svc_pid)" 2>/dev/null || true
  sleep 1
}

# ensure_url_file：服务在跑但地址记录丢了时，从日志里找回来
ensure_url_file() {
  [ -s "$DSHM_URL_FILE" ] && return 0
  svc_up || return 0
  local url
  url=$(grep -o "http://127\.0\.0\.1:$DSHM_PORT/?token=[A-Za-z0-9_-]*" "$DSHM_HOME/.dsh/run/dsh.log" 2>/dev/null | head -1)
  if [ -n "$url" ]; then
    printf '%s\n' "$url" > "$DSHM_URL_FILE"
    dim "已从日志恢复服务地址记录"
  else
    warn "服务在跑但找不到地址记录，且日志里也提取不到令牌"
  fi
}

# restart_service：装完插件后需要让服务重新组装模块树
restart_service() {
  step "⑨ 重启服务以加载插件"
  stop_service
  start_service
}

current_token() {
  grep -o 'token=[A-Za-z0-9_-]*' "$DSHM_URL_FILE" 2>/dev/null | cut -d= -f2
}
