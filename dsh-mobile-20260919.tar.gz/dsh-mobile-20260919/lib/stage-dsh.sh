#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  stage-dsh.sh —— 装 DSH 本体 + 应用核心补丁
#  被 install.sh source
# ============================================================

# 经过验证的版本：界面适配插件依赖的 CSS Modules 哈希在这个版本上确认有效。
# 不默认装 latest —— DSH 升级可能改哈希，导致插件静默失效（手册第 6 节坑 9）。
DSHM_PIN_VERSION="${DSHM_PIN_VERSION:-0.1.5-rc.1}"
NPM_MIRROR="https://registry.npmmirror.com"
NPM_OFFICIAL="https://registry.npmjs.org"

dsh_installed_version() {
  node -e "try{console.log(require('$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/package.json').version)}catch(e){console.log('')}" 2>/dev/null
}

dsh_bin_path() { echo "$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/lib/bin.js"; }
dsh_dist_dir() { echo "$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai/dsh-web-frontend/dist"; }

install_dsh() {
  step "③ 安装 DSH 本体"
  case "${DSHM_VERSION_CHOICE:-pin}" in
    latest) DSHM_TARGET="latest" ;;
    *)      DSHM_TARGET="$DSHM_PIN_VERSION" ;;
  esac

  local cur; cur=$(dsh_installed_version)
  if [ -n "$cur" ]; then
    dim "当前已装：v$cur"
    if [ "$DSHM_TARGET" != "latest" ] && [ "$cur" = "$DSHM_TARGET" ]; then
      ok "已是目标版本 v$cur，跳过安装（不打扰正在运行的服务）"
      return 0
    fi
    warn "将安装 v$DSHM_TARGET（当前 v$cur）"
  else
    dim "目标版本：v$DSHM_TARGET"
  fi

  # 用 --registry 传参，不改动用户全局 npm 配置（更礼貌，也更安全）
  # 用 --prefix 传参，使安装位置随时可覆盖（隔离测试时不碰真实环境）
  local reg="$NPM_MIRROR"
  if ! curl -sI --max-time 10 "$reg/" >/dev/null 2>&1; then
    warn "镜像源不可达，改用官方源（会慢一些）"
    reg="$NPM_OFFICIAL"
  fi
  dim "源：$reg"
  dim "安装位置：$DSHM_PREFIX/lib/node_modules"

  if ! run npm install -g "@deepseek-ai/dsh@$DSHM_TARGET" \
        --registry="$reg" --prefix "$DSHM_PREFIX" --no-fund --no-audit; then
    if [ "$reg" != "$NPM_OFFICIAL" ]; then
      warn "镜像安装失败，回退官方源重试…"
      run npm install -g "@deepseek-ai/dsh@$DSHM_TARGET" \
        --registry="$NPM_OFFICIAL" --prefix "$DSHM_PREFIX" --no-fund --no-audit \
        || die "DSH 安装失败" "npm install -g @deepseek-ai/dsh@$DSHM_TARGET"
    else
      die "DSH 安装失败" "npm install -g @deepseek-ai/dsh@$DSHM_TARGET --registry=$NPM_OFFICIAL"
    fi
  fi

  local nv; nv=$(dsh_installed_version)
  [ -n "$nv" ] || die "npm 报告成功，但读不到 DSH 版本（安装可能不完整）" "npm install -g @deepseek-ai/dsh@$DSHM_TARGET"
  ok "DSH v$nv 安装完成"
}

# ------------------------------------------------------------
#  核心补丁。两条都幂等（已打过就跳过）。
#   补丁1：静态服务缺 PNG/字体等 MIME 映射 → 界面图标/字体 404
#   补丁2：把启动令牌改成"由 secret 派生的稳定令牌"
#          ★ APK 模式的前提：令牌每次重启都变的话，烧进 APK 的入口就会失效
# ------------------------------------------------------------
apply_core_patches() {
  step "④ 应用 DSH 核心补丁"
  local base="$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai"
  local S="$base/dsh-host-frontend-static/lib/index.js"
  local C="$base/dsh-client-connection/lib/index.js"
  [ -f "$S" ] || die "找不到 $S（DSH 安装结构可能变了）"
  [ -f "$C" ] || die "找不到 $C（DSH 安装结构可能变了）"

  # --- 补丁1：MIME 映射 ---
  if grep -q '".png"' "$S"; then
    ok "补丁1（MIME 映射）已存在"
  else
    backup_file "$S"
    if run python3 - "$S" <<'PY'
import sys
f = sys.argv[1]
s = open(f, encoding="utf-8").read()
old = '\t".svg": "image/svg+xml",\n'
if old not in s:
    sys.exit(3)
new = old + '\t".png": "image/png",\n\t".webp": "image/webp",\n\t".jpg": "image/jpeg",\n\t".jpeg": "image/jpeg",\n\t".ico": "image/x-icon",\n\t".woff2": "font/woff2",\n\t".woff": "font/woff",\n'
open(f, "w", encoding="utf-8").write(s.replace(old, new, 1))
PY
    then ok "补丁1（MIME 映射）已应用"
    else die "补丁1 应用失败：DSH 源码结构与预期不符（可能换了版本）" "dsh-apply-mime-patch  # 装完后可手动重试"
    fi
  fi

  # --- 补丁2：稳定启动令牌 ---
  if grep -q 'dsh-stable-launch-token' "$C"; then
    ok "补丁2（稳定令牌）已存在"
    DSHM_STABLE_TOKEN=1
  else
    backup_file "$C"
    if run python3 - "$C" <<'PY'
import sys
f = sys.argv[1]
s = open(f, encoding="utf-8").read()
old = '\t\tthis.launchToken = processLaunchToken(processOwner);'
if old not in s:
    sys.exit(3)
new = ('\t\tthis.launchToken = encodeBase64Url(createHmac("sha256", secret)\n'
       '\t\t\t.update("dsh-stable-launch-token-v1").digest()).slice(0, 32);')
open(f, "w", encoding="utf-8").write(s.replace(old, new, 1))
PY
    then
      ok "补丁2（稳定令牌）已应用"
      DSHM_STABLE_TOKEN=1
    else
      DSHM_STABLE_TOKEN=0
      if [ "$MODE" = "apk" ]; then
        die "补丁2（稳定令牌）无法应用：令牌会每次重启都变，烧进 APK 的入口将失效。
     为不给你一个装好就坏的 APK，已中止。" \
            "改用浏览器模式：install.sh --mode=browser"
      fi
      warn "补丁2 应用失败：令牌每次重启会变（浏览器模式不受影响）"
    fi
  fi
}

# DSH 升级后恢复补丁（供后续维护）
ensure_repatch_available() {
  [ -f "$DSHM_PREFIX/bin/dsh-repatch-all" ] && dim "已装 dsh-repatch-all（DSH 升级后跑一次即可恢复补丁）"
  return 0
}
