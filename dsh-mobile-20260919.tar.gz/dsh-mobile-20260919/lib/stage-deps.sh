#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  stage-deps.sh —— 依赖安装（分两批：基础 / APK 构建）
#  被 install.sh source
#
#  为什么分两批：构建工具（JDK 等）有几百 MB，只有选 APK 模式才需要。
#  用户要求"依赖装完再弹菜单"，所以先装基础依赖 → 弹菜单 → APK 模式再补构建依赖。
# ============================================================

# 基础：运行 DSH 与运维脚本所必需
# ★ 必须含 clang（2026-09-16 实测修正）：两种模式都要编译两个 .so ——
#   node-addon-system 的 system.node（不编译则"会话打不开"）与 link-fix.so（不编译则 npm 装不上东西）。
#   原来把 clang 只放在 APK_PKGS 里 ⇒ 选"浏览器模式"会卡在"缺少 clang，无法编译 flock 原生模块"。
#   代价：clang 会带进 libLLVM 等约 270MB，所以浏览器模式的空间预检也要跟着放宽。
BASE_PKGS="nodejs-lts curl unzip python zstd gawk coreutils diffutils clang"
# APK 构建：aapt/aapt2/apksigner/d8 来自 Termux 官方源，无需 Android SDK
APK_PKGS="openjdk-21 aapt aapt2 apksigner d8 clang"

install_base_deps() {
  step "① 安装基础依赖"
  dim "包：$BASE_PKGS"
  ensure_pkgs $BASE_PKGS
  # 版本体检：DSH 需要较新的 Node
  local nv major
  nv=$(node -v 2>/dev/null | sed 's/^v//')
  major=${nv%%.*}
  case "$major" in ''|*[!0-9]*) die "node 不可用" "pkg install -y nodejs-lts" ;; esac
  if [ "$major" -lt 20 ]; then
    die "Node 版本过低（v$nv），DSH 需要 v20 以上" "pkg install -y nodejs-lts"
  fi
  dim "Node v$nv ✓   npm $(npm -v 2>/dev/null) ✓"
}

install_apk_deps() {
  step "② 安装 APK 构建依赖"
  dim "包：$APK_PKGS"
  ensure_pkgs $APK_PKGS
  local miss=()
  for b in aapt2 aapt apksigner d8 javac keytool clang zipalign unzip; do
    have "$b" || miss+=("$b")
  done
  [ ${#miss[@]} -eq 0 ] || die "构建工具仍然缺失：${miss[*]}" "pkg install -y $APK_PKGS"
  dim "构建链齐备 ✓"
}
