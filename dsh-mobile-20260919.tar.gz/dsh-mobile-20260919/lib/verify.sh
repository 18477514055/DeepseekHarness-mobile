#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  verify.sh —— 装完自检：不合格就明确告诉你怎么修
#  被 install.sh source
#
#  原则：不做"看起来成功"的判断，每条都实测。
# ============================================================

V_OK=0; V_BAD=0
v_pass() { printf '  %s✓%s %s\n' "$C_GRN" "$C_OFF" "$1"; V_OK=$((V_OK + 1)); return 0; }
v_fail() {
  printf '  %s✗%s %s\n' "$C_RED" "$C_OFF" "$1"
  V_BAD=$((V_BAD + 1))
  [ -n "${2:-}" ] && printf '      修复：%s\n' "$2"
  return 0
}
v_skip() { printf '  %s–%s %s\n' "$C_YEL" "$C_OFF" "$1"; return 0; }

verify_all() {
  step "⑬ 安装自检"
  local good=1

  # 1) DSH 本体
  local v; v=$(dsh_installed_version)
  if [ -n "$v" ]; then v_pass "DSH 已安装：v$v"; else v_fail "DSH 未安装" "npm install -g @deepseek-ai/dsh@$DSHM_PIN_VERSION"; good=0; fi

  # 2) 服务
  if svc_up; then v_pass "服务在跑（127.0.0.1:$DSHM_PORT）"; else v_fail "服务没起来" "dshweb"; good=0; fi

  # 3) 令牌地址真的能认证通过
  #    DSH 的入口流程是：GET /?token=XXX → 303 + Set-Cookie → 再 GET / → 200
  #    所以只测一次状态码会误判；这里走完整 cookie 流程，并检查反例（无凭据应 401）
  local url tok code code2 code3 cj
  url=$(cat "$DSHM_URL_FILE" 2>/dev/null)
  tok=$(current_token)
  if [ -n "$url" ] && [ "$DRY_RUN" = 0 ]; then
    cj="$DSHM_HOME/.dsh-mobile/.verify-cookies"
    mkdir -p "$(dirname "$cj")"; rm -f "$cj"
    code=$(curl -s -c "$cj" -o /dev/null -w '%{http_code}' --max-time 10 "$url" 2>/dev/null)
    code2=$(curl -s -b "$cj" -o /dev/null -w '%{http_code}' --max-time 10 "http://127.0.0.1:$DSHM_PORT/" 2>/dev/null)
    code3=$(curl -s -o /dev/null -w '%{http_code}' --max-time 10 "http://127.0.0.1:$DSHM_PORT/" 2>/dev/null)
    rm -f "$cj"
    if [ "$code2" = "200" ]; then
      v_pass "令牌有效（入口 $code → 带 cookie 访问 200，认证通过）"
    else
      v_fail "令牌认证失败（入口 HTTP $code，带 cookie 访问 HTTP $code2）" "dshstop && dshweb"
      good=0
    fi
    if [ "$code3" = "401" ]; then
      v_pass "无凭据访问被拒（HTTP 401，符合预期）"
    else
      v_skip "无凭据访问返回 HTTP $code3（预期 401，仅供留意）"
    fi
  elif [ -n "$url" ]; then
    v_skip "令牌认证检查（dry-run 跳过）"
  else
    v_fail "找不到服务地址记录 $DSHM_URL_FILE" "dshweb"; good=0
  fi

  # 4) 核心补丁
  local base="$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/node_modules/@deepseek-ai"
  grep -q '".png"' "$base/dsh-host-frontend-static/lib/index.js" 2>/dev/null \
    && v_pass "补丁1 MIME 映射 已应用" || { v_fail "补丁1 MIME 映射 未应用（图标/字体会 404）" "dsh-apply-mime-patch"; good=0; }
  if grep -q 'dsh-stable-launch-token' "$base/dsh-client-connection/lib/index.js" 2>/dev/null; then
    v_pass "补丁2 稳定令牌 已应用"
    PATCH_STABLE=1
  else
    PATCH_STABLE=0
    if [ "$MODE" = "apk" ]; then v_fail "补丁2 未应用（APK 的令牌会在重启后失效）" "dsh-repatch-all"; good=0
    else v_skip "补丁2 未应用（浏览器模式无影响）"; fi
  fi

  # 4b) Termux 专项修复：flock 原生模块（缺了会话会打不开）
  if [ "$(node -p 'process.platform' 2>/dev/null)" = "android" ]; then
    local so="$base/node-addon-system-android-arm64/bin/system.node"
    if [ -f "$so" ] && grep -q "platform !== 'android'" "$base/node-addon-system/lib/flock.js" 2>/dev/null; then
      if [ "$DRY_RUN" = 0 ] && native_selftest; then
        v_pass "flock 原生模块可用（加锁/争用均正常）"
      elif [ "$DRY_RUN" = 1 ]; then
        v_skip "flock 原生模块功能自检（dry-run 跳过）"
      else
        v_fail "flock 原生模块功能自检失败" "重跑安装脚本"
        good=0
      fi
    else
      v_fail "flock 原生模块缺失或 flock.js 未放行 android（会话会打不开）" "重跑安装脚本"
      good=0
    fi
  fi

  # 4c) Termux 专项修复：sharp 的 WASM 运行时（缺了服务直接起不来）
  local NM="$DSHM_PREFIX/lib/node_modules/@deepseek-ai/dsh/node_modules"
  if [ -f "$NM/sharp/package.json" ]; then
    if [ "$DRY_RUN" = 0 ] && sharp_ok "$NM"; then
      v_pass "sharp 可加载（v$(sharp_version "$NM")）"
    elif [ "$DRY_RUN" = 1 ]; then
      v_skip "sharp 加载检查（dry-run 跳过）"
    else
      v_fail "sharp 无法加载（服务会启动失败）" "重跑安装脚本"
      good=0
    fi
  fi

  # 5) 插件（逐文件核对，含服务端入口）
  local pdir="$DSHM_HOME/.dsh/profiles/web/node_modules/dsh-mobile-adapt"
  local psrc="$DSHM_PAYLOAD/plugin/dsh-mobile-adapt"
  if [ -d "$pdir" ]; then
    local miss=() differ=() rel
    while IFS= read -r rel; do
      if [ ! -f "$pdir/$rel" ]; then miss+=("$rel")
      elif [ "$DRY_RUN" = 0 ] && ! cmp -s "$psrc/$rel" "$pdir/$rel"; then differ+=("$rel"); fi
    done < <( cd "$psrc" && find . -type f | sed 's|^\./||' | sort )
    if [ ${#miss[@]} -gt 0 ]; then
      v_fail "插件缺文件：${miss[*]}（服务可能起不来）" "重跑安装脚本"; good=0
    elif [ ${#differ[@]} -gt 0 ]; then
      v_fail "插件与分发包不一致：${differ[*]}" "tools/sync-payload.sh && 重跑安装"; good=0
    else
      v_pass "插件已安装且与分发包逐文件一致（$(cd "$psrc" && find . -type f | wc -l) 个文件）"
    fi
  else
    v_fail "插件未安装" "重跑安装脚本"; good=0
  fi
  local cpf="$DSHM_HOME/.dsh/profiles/web/cordis.patch.yml"
  if grep -q 'id:[[:space:]]*mobile-adapt' "$cpf" 2>/dev/null; then
    if [ "$DRY_RUN" = 1 ] || yaml_validate_array "$cpf" >/dev/null 2>&1; then
      v_pass "插件挂载记录已写入且 YAML 合法"
    else
      v_fail "挂载记录 YAML 非法（服务会起不来）" "查看 $cpf，或恢复 $cpf.bak-*"
      good=0
    fi
  else
    v_fail "挂载记录缺失" "重跑安装脚本"; good=0
  fi

  # 6) Termux 脚本
  local n=0 s
  for s in dshweb dshstop dshstatus dshwatchdog dshopenapp; do [ -x "$DSHM_PREFIX/bin/$s" ] && n=$((n + 1)); done
  [ "$n" = 5 ] && v_pass "运维脚本已就绪（$n/5 关键命令）" || { v_fail "运维脚本缺失（$n/5）" "重跑安装脚本"; good=0; }

  # 7) link-fix.so
  [ -f "$DSHM_HOME/link-fix.so" ] && v_pass "link-fix.so 已编译" || { v_fail "link-fix.so 缺失（服务可能起不来）" "pkg install -y clang && 重跑安装"; good=0; }

  # 8) APK（仅 APK 模式）
  if [ "$MODE" = "apk" ]; then
    local apk="$DSHM_HOME/.dsh-mobile/build/out/DshShell.apk"
    if [ -f "$apk" ]; then
      v_pass "APK 已生成（$(human_size "$(stat -c %s "$apk")")）"
      if have apksigner && apksigner verify "$apk" >/dev/null 2>&1; then
        v_pass "APK 签名校验通过"
      else
        v_fail "APK 签名校验未通过" "重跑安装脚本"
      fi
      # ★ 关键：APK 里烧的令牌必须等于当前令牌，否则装上去就是白屏/等待页卡死
      local apk_tok=""
      if have unzip; then
        apk_tok=$(unzip -p "$apk" classes.dex 2>/dev/null | grep -ao 'token=[A-Za-z0-9_-]\{8,\}' | head -1 | cut -d= -f2)
      fi
      if [ -z "$apk_tok" ]; then
        # 退一步：比对构建树的源码
        apk_tok=$(grep -o 'token=[A-Za-z0-9_-]*' "$DSHM_HOME/.dsh-mobile/build/src/com/dsh/shell/MainActivity.java" 2>/dev/null | head -1 | cut -d= -f2)
        [ -n "$apk_tok" ] && v_skip "无法从 dex 提取令牌，改比对构建源码"
      fi
      if [ -n "$apk_tok" ] && [ -n "$tok" ]; then
        [ "$apk_tok" = "$tok" ] && v_pass "APK 内令牌与当前服务令牌一致" \
                                 || { v_fail "APK 内令牌与当前令牌不一致 → 装上去会连不上" "重跑安装脚本"; good=0; }
      else
        v_fail "无法核对 APK 内的令牌" "重跑安装脚本"
      fi
    else
      v_skip "APK 模式但未找到产物（可能用了 --dry-run）"
    fi
  fi

  echo
  if [ "$V_BAD" = 0 ]; then
    ok "自检全部通过（$V_OK 项）"
  else
    warn "自检有 $V_BAD 项未通过（通过 $V_OK 项）"
    [ "$good" = 1 ] || dim "请按上面每条的「修复」提示处理后，重跑本脚本（可重复执行，不会重复安装）"
  fi
}
