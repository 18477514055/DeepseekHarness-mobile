#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  stage-apk.sh —— 在本机现场编译并签名 APK（仅 APK 模式）
#  被 install.sh source
#
#  与"发一个预编译 APK"的区别（这是本方案的安全核心）：
#    · 令牌不随包分发，编译时才把本机自己刚生成的令牌填进去
#    · keystore 在本机生成，私钥永不外传
#    · 因此分发包本身不含任何凭据
# ============================================================

ANDROID_PLATFORM_FILE="platform-35_r02.zip"
ANDROID_PLATFORM_URLS=(
  "https://mirrors.cloud.tencent.com/AndroidSDK/platform-35_r02.zip"
  "https://dl.google.com/android/repository/platform-35_r02.zip"
)
# 备用平台包（内容不同但同样可用；仅在主包全部源失败时尝试）
ANDROID_PLATFORM_ALT_FILE="platform-35_r01.zip"
ANDROID_PLATFORM_ALT_URLS=(
  "https://mirrors.cloud.tencent.com/AndroidSDK/platform-35_r01.zip"
  "https://dl.google.com/android/repository/platform-35_r01.zip"
)

# ---------- 1) 取得 android.jar（多源 + 双重校验） ----------
ensure_android_jar() {
  local want_zip want_jar
  want_zip=$(sums_lookup "$ANDROID_PLATFORM_FILE")
  want_jar=$(sums_lookup "android.jar")

  local zip="$DSHM_CACHE/$ANDROID_PLATFORM_FILE"
  local jar="$DSHM_CACHE/android-35/android.jar"

  # 已就绪？
  if verify_sha256 "$jar" "$want_jar"; then
    ok "android.jar 已就绪且校验通过（缓存复用）"
    ANDROID_JAR="$jar"; return 0
  fi

  # 平台包：主包 → 备用包
  if ! verify_sha256 "$zip" "$want_zip"; then
    local alt_zip="$DSHM_CACHE/$ANDROID_PLATFORM_ALT_FILE"
    local alt_want; alt_want=$(sums_lookup "$ANDROID_PLATFORM_ALT_FILE")
    if verify_sha256 "$alt_zip" "$alt_want"; then
      zip="$alt_zip"; want_zip="$alt_want"
    elif fetch_file "Android 平台包 $ANDROID_PLATFORM_FILE" "$zip" "$want_zip" "${ANDROID_PLATFORM_URLS[@]}"; then
      :
    else
      warn "主平台包获取失败，尝试备用平台包…"
      fetch_file "Android 平台包 $ANDROID_PLATFORM_ALT_FILE" "$alt_zip" "$alt_want" "${ANDROID_PLATFORM_ALT_URLS[@]}" \
        || die "Android 平台包全部源失败（含备用）" "见 thirdparty/README.md 的手动获取方法"
      zip="$alt_zip"
    fi
  fi

  # 解出 android.jar
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] unzip 提取 android.jar%s\n' "$C_BLU" "$C_OFF"
    ANDROID_JAR="$jar"; return 0
  fi
  run mkdir -p "$(dirname "$jar")"
  if ! unzip -j -o "$zip" "android-35/android.jar" -d "$(dirname "$jar")" >/dev/null 2>&1; then
    die "从 $zip 里解不出 android-35/android.jar（包结构异常）" "rm -f '$zip' 后重跑安装脚本"
  fi
  if ! verify_sha256 "$jar" "$want_jar"; then
    # 备用包解出的 jar 指纹可能不同：与官方登记的包一致即可接受
    warn "解出的 android.jar 指纹与预期不同（可能用了备用平台包）"
    dim "  实际: $(sha256sum "$jar" | cut -d' ' -f1)"
    dim "  预期: $want_jar"
    confirm "仍要继续编译吗？" || die "已按你的选择中止"
  fi
  ok "android.jar 就绪（$(human_size "$(stat -c %s "$jar")")）"
  ANDROID_JAR="$jar"
}

# ---------- 2) 准备构建工作区 ----------
prepare_build_tree() {
  local work="$DSHM_HOME/.dsh-mobile/build"
  local src="$DSHM_PAYLOAD/apk/DshShell"
  [ -d "$src" ] || die "分发包缺少 payload/apk/DshShell"
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] 复制 APK 工程到 %s%s\n' "$C_BLU" "$work" "$C_OFF"
    BUILD_DIR="$work"; return 0
  fi
  run rm -rf "$work"
  run mkdir -p "$work"
  run cp -a "$src/." "$work/"
  BUILD_DIR="$work"
  dim "构建目录：$work"
}

# ---------- 3) 把本机令牌填进入口 ----------
inject_token() {
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] 把本机令牌填入 ENTRY 占位符%s\n' "$C_BLU" "$C_OFF"
    return 0
  fi
  local tok; tok=$(current_token)
  [ -n "$tok" ] || die "拿不到本机令牌（$DSHM_URL_FILE 为空）" "dshweb  # 重新拉起服务"
  case "$tok" in *[!A-Za-z0-9_-]*) die "令牌含异常字符，已中止以防注入破坏源码" ;; esac

  local f="$BUILD_DIR/src/com/dsh/shell/MainActivity.java"
  [ -f "$f" ] || die "找不到 MainActivity.java"
  if ! grep -q '__TOKEN__' "$f"; then
    die "源码里没有 __TOKEN__ 占位符（分发包可能被改坏）" "tools/sync-payload.sh  # 重新同步 payload"
  fi
  run sed -i "s|__TOKEN__|$tok|g" "$f"
  ok "已把本机令牌填入入口（${tok:0:8}…）"
}

# ---------- 4) 编译 ----------
build_apk() {
  local B="$BUILD_DIR" O="$BUILD_DIR/out" A="$ANDROID_JAR"
  if [ "$DRY_RUN" = 1 ]; then
    printf '   %s[dry-run] aapt2 compile → aapt2 link → javac → d8 → zipalign → apksigner%s\n' "$C_BLU" "$C_OFF"
    return 0
  fi
  run rm -rf "$O"
  run mkdir -p "$O/compiled" "$O/gen" "$O/classes" "$O/dex"

  info "   [1/6] 编译资源（aapt2 compile）"
  run aapt2 compile --dir "$B/res" -o "$O/compiled/res.zip" \
    || die "资源编译失败（aapt2 compile）" "检查 payload/apk/DshShell/res 是否完整"

  info "   [2/6] 链接资源并生成 R.java（aapt2 link）"
  run aapt2 link -o "$O/base.apk" -I "$A" \
      --manifest "$B/AndroidManifest.xml" \
      -R "$O/compiled/res.zip" \
      --java "$O/gen" \
      --min-sdk-version 24 --target-sdk-version 34 \
      --auto-add-overlay \
    || die "资源链接失败（aapt2 link）" "多为 AndroidManifest.xml 或 res 问题"

  info "   [3/6] 编译 Java（javac）"
  local java_files
  java_files=$(find "$B/src" "$O/gen" -name '*.java')
  [ -n "$java_files" ] || die "找不到任何 .java 源文件"
  # shellcheck disable=SC2086
  run javac -source 8 -target 8 -nowarn -Xlint:-options \
      -classpath "$A" -d "$O/classes" $java_files \
    || die "Java 编译失败（javac）"

  info "   [4/6] 转 DEX 并打包（d8 + aapt add）"
  # shellcheck disable=SC2046
  run d8 --lib "$A" --min-api 24 --output "$O/dex" $(find "$O/classes" -name '*.class') \
    || die "DEX 转换失败（d8）"
  ( cd "$O/dex" && aapt add "$O/base.apk" classes.dex >/dev/null ) \
    || die "把 classes.dex 装进 APK 失败（aapt add）"

  info "   [5/6] 对齐（zipalign）"
  if have zipalign; then
    run zipalign -f -p 4 "$O/base.apk" "$O/aligned.apk" || die "zipalign 失败"
  else
    warn "没有 zipalign，跳过对齐（仍可安装）"
    run cp -f "$O/base.apk" "$O/aligned.apk"
  fi

  info "   [6/6] 签名（apksigner）"
  sign_apk "$O/aligned.apk" "$O/DshShell.apk"
}

# ---------- 5) 签名（复用本机已有 keystore 以便覆盖升级） ----------
sign_apk() {
  local in="$1" out="$2"
  local ks="$DSHM_HOME/dsh-backup/apk-build/dsh.keystore"
  local ks_own="$DSHM_HOME/.dsh-mobile/dsh.keystore"
  local passfile="$ks_own.pass" pass

  if [ -f "$ks" ]; then
    pass="${KS_PASS:-android}"          # 本机既有 keystore（与历史安装保持同一签名）
    dim "复用已有 keystore：$ks"
  else
    ks="$ks_own"
    if [ -f "$ks" ] && [ -f "$passfile" ]; then
      pass=$(cat "$passfile")
    else
      pass=$(head -c 24 /dev/urandom | base64 | tr -dc 'A-Za-z0-9' | head -c 20)
      [ -n "$pass" ] || pass="dsh-local-keystore"
      run mkdir -p "$(dirname "$ks")"
      run keytool -genkeypair -keystore "$ks" -alias dsh -keyalg RSA -keysize 2048 \
        -validity 10000 -storepass "$pass" -keypass "$pass" \
        -dname "CN=DSH, O=Local, C=CN" || die "生成 keystore 失败"
      if [ "$DRY_RUN" = 0 ]; then
        printf '%s' "$pass" > "$passfile"; chmod 600 "$passfile"
      fi
      ok "已生成本机专属 keystore（私钥不出本机；密码存于 $passfile，权限 600）"
    fi
  fi

  run apksigner sign --ks "$ks" --ks-pass "pass:$pass" --key-pass "pass:$pass" \
      --out "$out" "$in" || die "APK 签名失败（apksigner）"
  run apksigner verify --print-certs "$out" >/dev/null 2>&1 || warn "签名校验未通过（建议检查）"
}

# ---------- 6) 交付：发布到页面 + 放到 Download ----------
publish_apk() {
  local apk="$BUILD_DIR/out/DshShell.apk"
  [ "$DRY_RUN" = 1 ] && { printf '   %s[dry-run] 发布 APK%s\n' "$C_BLU" "$C_OFF"; return 0; }
  [ -f "$apk" ] || die "构建产物不存在：$apk"

  local vc vn
  vc=$(grep -o 'android:versionCode="[0-9]*"' "$BUILD_DIR/AndroidManifest.xml" | grep -o '[0-9]*')
  vn=$(grep -o 'android:versionName="[^"]*"' "$BUILD_DIR/AndroidManifest.xml" | sed 's/.*="//;s/"//')

  # 发布到 DSH 静态目录 → 页面内「检查更新」可用
  local dist; dist=$(dsh_dist_dir)
  if [ -d "$dist" ]; then
    run cp -f "$apk" "$dist/dsh-update.apk"
    if [ "$DRY_RUN" = 0 ]; then
      printf '{"versionCode":%s,"versionName":"%s","size":%s}\n' \
        "$vc" "$vn" "$(stat -c %s "$apk")" > "$dist/dsh-version.json"
    fi
    dim "已发布到页面：/dsh-update.apk（versionCode=$vc versionName=$vn）"
  fi

  if [ "${NO_DELIVER:-0}" = 1 ]; then
    dim "已按 --no-deliver 跳过：未写入共享存储、未拉起安装器"
    dim "产物留在：$apk"
    APK_VERSION_NAME="$vn"; APK_VERSION_CODE="$vc"; APK_PATH="$apk"
    return 0
  fi

  # 放到共享存储，方便手动安装
  local dl="/storage/emulated/0/Download"
  if [ -d "$dl" ]; then
    run cp -f "$apk" "$dl/DshShell.apk"
    ok "安装包已放到：$dl/DshShell.apk（$(human_size "$(stat -c %s "$apk")")）"
  else
    warn "没有共享存储权限，APK 只留在本机：$apk"
    dim "授权方法：在 Termux 里执行 termux-setup-storage 并允许「文件和媒体」"
  fi

  # 拉起系统安装器（Termux 有存储权限时用 termux-open 走 FileProvider）
  if have termux-open; then
    run termux-open --content-type application/vnd.android.package-archive "$apk" \
      || dim "未能自动拉起安装器，请手动点开上面的 APK"
  else
    dim "请手动到 Download 目录点开 DshShell.apk 安装"
  fi

  APK_VERSION_NAME="$vn"; APK_VERSION_CODE="$vc"; APK_PATH="$apk"
}
