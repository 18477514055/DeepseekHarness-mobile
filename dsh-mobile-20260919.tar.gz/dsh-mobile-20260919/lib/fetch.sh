#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  fetch.sh —— 唯一的下载出口：多源回退 + SHA256 校验 + 断点续传
#  被 install.sh source
#
#  原则：任何一个字节进到系统里，都必须先通过校验。
#        某个源失败就换下一个，全失败才报错，并给出人工兜底办法。
# ============================================================

# sums_lookup <文件名>：从 thirdparty/SHA256SUMS 取期望的 sha256
sums_lookup() {
  local f="$1"
  [ -f "$DSHM_REPO/thirdparty/SHA256SUMS" ] || return 1
  awk -v n="$f" '$2==n {print $1; found=1} END{exit !found}' "$DSHM_REPO/thirdparty/SHA256SUMS"
}

# verify_sha256 <文件> <期望值>：安静比对，返回 0/1
verify_sha256() {
  local f="$1" want="$2"
  [ -f "$f" ] || return 1
  [ "$want" = "-" ] && return 0
  local got
  got=$(sha256sum "$f" 2>/dev/null | cut -d' ' -f1)
  [ "$got" = "$want" ]
}

# fetch_file <显示名> <目标路径> <期望sha256|-> <url...>
#   1) 目标已存在且校验通过 → 直接复用
#   2) 缓存里已有且校验通过 → 复制过来
#   3) 逐个源下载（每个源试 2 次），下完立即校验
fetch_file() {
  local name="$1" dest="$2" want="$3"; shift 3
  local urls=("$@")
  local cache="$DSHM_CACHE/$(basename "$dest")"

  # 1) 目标已就绪
  if verify_sha256 "$dest" "$want"; then
    ok "$name 已存在且校验通过，跳过下载"
    return 0
  fi
  # 2) 命中缓存
  if verify_sha256 "$cache" "$want"; then
    info "$name 命中本地缓存，复制中…"
    run mkdir -p "$(dirname "$dest")"
    run cp -a "$cache" "$dest"
    if verify_sha256 "$dest" "$want"; then ok "$name 就绪（缓存）"; return 0; fi
    warn "缓存复制后校验失败，转为重新下载"
  fi

  # 3) 多源下载
  run mkdir -p "$(dirname "$dest")" "$DSHM_CACHE"
  local url attempt tmp="$dest.part"
  for url in "${urls[@]}"; do
    for attempt in 1 2; do
      info "下载 $name ← $url（第 $attempt 次）"
      rm -f "$tmp"
      if [ "$DRY_RUN" = 1 ]; then
        printf '   %s[dry-run] curl -L -o %s %s%s\n' "$C_BLU" "$tmp" "$url" "$C_OFF"
        return 0
      fi
      if curl -L --fail --connect-timeout 20 --retry 2 --retry-delay 3 \
              --progress-bar -o "$tmp" "$url"; then
        if verify_sha256 "$tmp" "$want"; then
          mv -f "$tmp" "$dest"
          cp -a "$dest" "$cache" 2>/dev/null || true
          ok "$name 下载完成并通过校验（$(human_size "$(stat -c %s "$dest")")）"
          return 0
        fi
        warn "校验不通过（文件可能损坏或被篡改），换下一个源"
        rm -f "$tmp"
        break            # 该源的字节有问题，试这个源的第二次没意义
      fi
      warn "本源下载失败，重试…"
      sleep 2
    done
  done

  # 4) 全失败：给出人工兜底
  printf '\n'
  die "$name 所有下载源都失败了" "$(manual_hint "$name" "$dest" "$want")"
}

# manual_hint <名> <目标> <sha256>：人工兜底说明（离线也能装）
manual_hint() {
  local name="$1" dest="$2" want="$3"
  case "$name" in
    *android.jar*|*平台包*|*platform*)
      cat <<EOF
离线方案（任选）：
  1) 用手机浏览器打开：https://mirrors.cloud.tencent.com/AndroidSDK/platform-35_r02.zip
     下载后执行：
       mkdir -p "$(dirname "$dest")"
       unzip -j -o ~/storage/downloads/platform-35_r02.zip android-35/android.jar -d "$(dirname "$dest")"
       sha256sum "$dest"     # 应等于 $want
  2) 或从已装好的设备拷贝 $(basename "$dest") 到：$(dirname "$dest")
EOF
      ;;
    *)
      echo "请手动把文件放到 $dest，并确认 sha256 = $want"
      ;;
  esac
}
