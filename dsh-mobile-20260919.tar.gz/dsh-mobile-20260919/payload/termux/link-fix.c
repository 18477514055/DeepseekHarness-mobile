#define _GNU_SOURCE
#include <dlfcn.h>
#include <unistd.h>
#include <errno.h>
#include <stdio.h>
#include <fcntl.h>
#include <sys/stat.h>
int link(const char *old, const char *new) {
    static int (*real_link)(const char*, const char*) = NULL;
    if (!real_link) real_link = dlsym(RTLD_NEXT, "link");
    int ret = real_link(old, new);
    if (ret == -1 && (errno == EACCES || errno == EPERM)) {
        int src = open(old, O_RDONLY);
        if (src < 0) return -1;
        int dst = open(new, O_WRONLY | O_CREAT | O_TRUNC, 0644);
        if (dst < 0) { close(src); return -1; }
        char buf[65536]; ssize_t n;
        while ((n = read(src, buf, sizeof(buf))) > 0) write(dst, buf, n);
        struct stat st;
        fstat(src, &st);
        fchmod(dst, st.st_mode);
        close(src); close(dst);
        return 0;
    }
    return ret;
}
