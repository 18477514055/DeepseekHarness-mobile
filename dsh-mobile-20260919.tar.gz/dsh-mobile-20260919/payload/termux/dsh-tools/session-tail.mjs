// 读取 dsh 会话日志（多帧 zstd），打印最近的对话内容
// 用法: node session-tail.mjs <sessionsBaseDir> [要打印的回复条数] [指定sessionId]
import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs'
import { join } from 'node:path'
import zlib from 'node:zlib'

const MAGIC = Buffer.from([0x28, 0xB5, 0x2F, 0xFD])

function decodeAll(buf) {
  const starts = []
  let i = 0
  while (true) {
    const j = buf.indexOf(MAGIC, i)
    if (j < 0) break
    starts.push(j)
    i = j + 4
  }
  return starts.map((st, k) => {
    const e = k + 1 < starts.length ? starts[k + 1] : buf.length
    try { return zlib.zstdDecompressSync(buf.subarray(st, e)).toString('utf8') } catch { return '' }
  }).join('')
}

function readSession(file) {
  const lines = decodeAll(readFileSync(file)).split('\n').filter(Boolean)
  const out = []
  for (const l of lines) { try { out.push(JSON.parse(l)) } catch {} }
  return out
}

const base = process.argv[2]
const want = Number(process.argv[3] ?? 1)
const onlyId = process.argv[4]

if (!existsSync(base)) { console.log('找不到会话目录:', base); process.exit(1) }

const dirs = readdirSync(base)
  .filter(d => d.startsWith('session-'))
  .map(d => {
    const f = join(base, d, 'session.v3.jsonl.zstd')
    let m = 0, size = 0
    try { const s = statSync(f); m = s.mtimeMs; size = s.size } catch {}
    return { d, f, m, size }
  })
  .filter(x => x.m > 0)
  .sort((a, b) => b.m - a.m)

if (dirs.length === 0) { console.log('没有可读的会话'); process.exit(1) }

const target = onlyId ? dirs.find(x => x.d.includes(onlyId)) : dirs[0]
if (!target) { console.log('找不到指定会话:', onlyId); process.exit(1) }

const recs = readSession(target.f)
const title = recs.find(r => r.type === 'session/title' && r.data?.source?.kind === 'provider')?.data?.title
  ?? recs.find(r => r.type === 'session/title')?.data?.title ?? '(无标题)'
const users = recs.filter(r => r.type === 'user/message').length
const turns = recs.filter(r => r.type === 'turn/start').length
const ended = recs.filter(r => r.type === 'turn/end')
const lastEnd = ended[ended.length - 1]

console.log('会话   :', target.d)
console.log('标题   :', title)
console.log('最后写入:', new Date(target.m).toLocaleString('zh-CN', { hour12: false }), `  (${target.size} 字节)`)
console.log('轮次   :', turns, ' 用户消息:', users,
  lastEnd ? ` 末轮结束: ${new Date(lastEnd.time).toTimeString().slice(0, 8)} (${lastEnd.data?.reason?.kind ?? '?'})` : '')
console.log('─'.repeat(70))

const msgs = recs.filter(r => r.type === 'assistant/message')
const picked = msgs.slice(-want)
if (picked.length === 0) { console.log('（该会话还没有 assistant 回复）'); process.exit(0) }

for (const m of picked) {
  const parts = m.data?.message?.content ?? []
  const text = parts.filter(p => p.type === 'text').map(p => p.text).join('')
  const reasoning = parts.filter(p => p.type === 'reasoning').map(p => p.text).join('')
  console.log(`\n【${new Date(m.time).toTimeString().slice(0, 8)}】assistant 回复（${text.length} 字）`)
  console.log(text.length ? text : '（本条为纯工具调用，无正文）')
  if (!text && reasoning) console.log('[思考] ' + reasoning.slice(0, 200))
}
