package com.dsh.shell;

import android.content.Context;
import android.content.SharedPreferences;

/** 监护配置的单一存放点：WebView 里的开关和后台服务读同一份。 */
public final class Cfg {
    public static final String NAME = "dsh";

    private Cfg() {}

    public static SharedPreferences get(Context c) {
        return c.getSharedPreferences(NAME, Context.MODE_PRIVATE);
    }

    /** 后台自启动。默认开，保持与旧版 Termux:Boot 行为一致。 */
    public static boolean autostart(Context c) {
        return get(c).getBoolean("autostart", true);
    }

    public static void setAutostart(Context c, boolean v) {
        get(c).edit().putBoolean("autostart", v).apply();
    }

    /** 手动停止服务后的挂起截止时间（毫秒时间戳），期间监护人不去拉起。 */
    public static long pausedUntil(Context c) {
        return get(c).getLong("pausedUntil", 0L);
    }

    public static void pause(Context c, long ms) {
        get(c).edit().putLong("pausedUntil", System.currentTimeMillis() + ms).apply();
    }

    public static void unpause(Context c) {
        get(c).edit().remove("pausedUntil").apply();
    }

    public static boolean paused(Context c) {
        return System.currentTimeMillis() < pausedUntil(c);
    }

    public static long lastStart(Context c) {
        return get(c).getLong("lastStart", 0L);
    }

    public static void setLastStart(Context c, long t) {
        get(c).edit().putLong("lastStart", t).apply();
    }

    public static boolean batteryAsked(Context c) {
        return get(c).getBoolean("batteryAsked", false);
    }

    public static void setBatteryAsked(Context c) {
        get(c).edit().putBoolean("batteryAsked", true).apply();
    }
}
