package com.dsh.shell;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * 后台空闲检查：应用切到后台满 20 分钟后由系统闹钟唤醒执行。
 *
 * 它只发一条「空闲就停」的指令给 Termux，真正停不停由 Termux 侧判断 ——
 * 因为只有 Termux 能看到 dshweb 有没有子进程（即有没有任务正在执行）。
 * 这样保证：切后台跑任务时永远不会被回收；纯挂机到点才回收。
 */
public class IdleAlarmReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context c, Intent intent) {
        try {
            if (LifecycleService.visible) {
                /* 用户已经切回来了，撤销定时器 */
                Alarm.cancel(c);
                return;
            }
            Termux.run(c, "dsh-supervisor-stop-if-idle", null, "DSH: idle cleanup");
            /* 若 Termux 侧判定「有任务在跑」它会拒绝回收，那就 10 分钟后再问一次；
               期间用户切回来会由 onStart 取消。 */
            Alarm.schedule(c, Alarm.RETRY_MS);
        } catch (Exception e) {
            /* 广播里绝不能抛 */
        }
    }
}
