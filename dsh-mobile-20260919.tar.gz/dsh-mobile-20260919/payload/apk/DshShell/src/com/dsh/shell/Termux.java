package com.dsh.shell;

import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;

/**
 * 用 Termux 官方的 RUN_COMMAND intent 在 Termux 里静默执行脚本。
 *
 * 关键点（都来自 Termux 官方 RUN_COMMAND-Intent 文档与 RunCommandService 源码）：
 *  - 必须声明并获授 com.termux.permission.RUN_COMMAND（dangerous 级，要运行时申请）
 *  - Termux 侧 ~/.termux/termux.properties 必须 allow-external-apps = true
 *  - targetSdk >= 30 时清单里必须声明 <queries><package android:name="com.termux"/></queries>
 *  - RUN_COMMAND_BACKGROUND = true 走 APP_SHELL runner：不创建终端会话、不抢焦点
 */
public final class Termux {
    public static final String PKG = "com.termux";
    public static final String SERVICE = "com.termux.app.RunCommandService";
    public static final String ACTION = "com.termux.RUN_COMMAND";
    public static final String PERM = "com.termux.permission.RUN_COMMAND";
    public static final String PREFIX = "/data/data/com.termux/files/usr";
    public static final String HOME = "/data/data/com.termux/files/home";

    private Termux() {}

    public static boolean granted(Context c) {
        try {
            return c.checkSelfPermission(PERM) == PackageManager.PERMISSION_GRANTED;
        } catch (Exception e) {
            return false;
        }
    }

    /** 静默执行 $PREFIX/bin/&lt;script&gt;。返回 false 表示连 intent 都没发出去。 */
    /** ★ 2026-09-16：带**结果回调**的 RUN_COMMAND（App 内「诊断与修复」用）。
     *  Termux 会把 stdout / stderr / exitCode 放进结果 Bundle，经 PENDING_INTENT 广播回本应用。 */
    public static final String EXTRA_PENDING_RESULT = "com.termux.RUN_COMMAND_PENDING_INTENT";
    public static final String EXTRA_RESULT_BUNDLE = "com.termux.RUN_COMMAND_RESULT_BUNDLE";

    public static boolean runWithResult(Context c, String script, String[] args, String label,
                                        PendingIntent pending) {
        if (!granted(c)) return false;
        try {
            Intent i = new Intent();
            i.setClassName(PKG, SERVICE);
            i.setAction(ACTION);
            i.putExtra("com.termux.RUN_COMMAND_PATH", PREFIX + "/bin/" + script);
            if (args != null && args.length > 0) i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", args);
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME);
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            if (label != null) i.putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL", label);
            i.putExtra(EXTRA_PENDING_RESULT, pending);
            c.startService(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    public static boolean run(Context c, String script, String[] args, String label) {
        try {
            Intent i = new Intent();
            i.setClassName(PKG, SERVICE);
            i.setAction(ACTION);
            i.putExtra("com.termux.RUN_COMMAND_PATH", PREFIX + "/bin/" + script);
            if (args != null && args.length > 0) {
                i.putExtra("com.termux.RUN_COMMAND_ARGUMENTS", args);
            }
            i.putExtra("com.termux.RUN_COMMAND_WORKDIR", HOME);
            i.putExtra("com.termux.RUN_COMMAND_BACKGROUND", true);
            i.putExtra("com.termux.RUN_COMMAND_COMMAND_LABEL", label == null ? "DSH" : label);
            if (Build.VERSION.SDK_INT >= 26) c.startForegroundService(i);
            else c.startService(i);
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private static volatile long lastKickAt = 0L;

    /**
     * 带节流的启动请求：onCreate / onStart / onResume 与服务的探活会在
     * 同一瞬间并发触发，不去重就会一次开机连发 3~6 条 RUN_COMMAND。
     */
    public static boolean runOnce(Context c, String script, String label, long minGapMs) {
        long now = System.currentTimeMillis();
        if (now - lastKickAt < minGapMs) return false;
        lastKickAt = now;
        return run(c, script, null, label);
    }

    /** 只探本机 DSH 是否响应（401 也算活着）。 */
    public static boolean ping() {
        java.net.HttpURLConnection conn = null;
        try {
            conn = (java.net.HttpURLConnection) new java.net.URL("http://127.0.0.1:3080/").openConnection();
            conn.setConnectTimeout(2500);
            conn.setReadTimeout(2500);
            conn.setRequestMethod("GET");
            conn.setInstanceFollowRedirects(false);
            int code = conn.getResponseCode();
            return code > 0 && code < 500;
        } catch (Exception e) {
            return false;
        } finally {
            if (conn != null) {
                try { conn.disconnect(); } catch (Exception e) {}
            }
        }
    }
}
