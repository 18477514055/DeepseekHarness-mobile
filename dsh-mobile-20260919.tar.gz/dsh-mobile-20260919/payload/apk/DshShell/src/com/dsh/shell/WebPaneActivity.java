package com.dsh.shell;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.view.WindowManager;
import android.webkit.CookieManager;
import android.webkit.DownloadListener;
import android.webkit.SslErrorHandler;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebStorage;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.ByteArrayInputStream;

/**
 * 应用内网页面板：在 DSH 里直接打开「DeepSeek 网页版」或「DeepSeek 开放平台」，
 * 不再跳到系统浏览器。
 *
 * 安全模型（与主界面那个 WebView 严格区分）：
 *   1. 绝不注入 JS 桥 —— 远程页面拿不到任何原生能力（主界面那个是注入的）
 *   2. 主框架只允许 *.deepseek.com；其他链接一律交给系统浏览器
 *   3. 拦截对 127.0.0.1 / 局域网地址的请求 —— 防止远程页面反向请求本机 DSH（CSRF）
 *   4. SSL 错误一律取消（不给"继续访问"的机会）；禁止混合内容
 *   5. 不开放文件访问与内容访问
 *   6. 按用户要求：不支持文件上传；允许截屏（不设 FLAG_SECURE）
 */
public class WebPaneActivity extends Activity {
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_TITLE = "title";

    private WebView web;
    private TextView titleView;

    /** 被拦截请求的空响应 */
    private static final WebResourceResponse BLOCKED =
            new WebResourceResponse("text/plain", "utf-8", new ByteArrayInputStream(new byte[0]));

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        String url = getIntent().getStringExtra(EXTRA_URL);
        String name = getIntent().getStringExtra(EXTRA_TITLE);
        if (url == null) url = "https://chat.deepseek.com/";
        if (name == null) name = "DeepSeek";

        /* ---------- 顶部栏（与应用内其他按钮同款：28×28 圆形、无底色）---------- */
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Color.WHITE);

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER_VERTICAL);
        bar.setBackgroundColor(Color.WHITE);
        int pad = dp(8);
        bar.setPadding(pad, dp(6) + safeTop(), pad, dp(6));

        Button back = new Button(this);
        back.setText("\u2039");                       /* ‹ */
        back.setTextSize(22);
        back.setTextColor(Color.parseColor("#111114"));
        back.setBackgroundColor(Color.TRANSPARENT);
        back.setPadding(0, 0, 0, 0);
        back.setMinWidth(0);
        back.setMinimumWidth(0);
        back.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { goBackOrFinish(); }
        });
        bar.addView(back, new LinearLayout.LayoutParams(dp(36), dp(36)));

        titleView = new TextView(this);
        titleView.setText(name);
        titleView.setTextSize(16);
        titleView.setTextColor(Color.parseColor("#111114"));
        titleView.setSingleLine(true);
        titleView.setEllipsize(android.text.TextUtils.TruncateAt.END);
        LinearLayout.LayoutParams tp = new LinearLayout.LayoutParams(0,
                ViewGroup.LayoutParams.WRAP_CONTENT, 1f);
        tp.leftMargin = dp(4);
        bar.addView(titleView, tp);

        Button clear = new Button(this);
        clear.setText("\u6e05\u9664\u767b\u5f55");   /* 清除登录 */
        clear.setTextSize(13);
        clear.setTextColor(Color.parseColor("#8b8b92"));
        clear.setBackgroundColor(Color.TRANSPARENT);
        clear.setPadding(dp(8), 0, dp(8), 0);
        clear.setMinWidth(0);
        clear.setMinimumWidth(0);
        clear.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { confirmClear(); }
        });
        bar.addView(clear, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.WRAP_CONTENT, dp(36)));

        root.addView(bar, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));

        View divider = new View(this);
        divider.setBackgroundColor(Color.parseColor("#ededf0"));
        root.addView(divider, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, Math.max(1, dp(1) / 2)));

        /* ---------- WebView ---------- */
        web = new WebView(this);
        web.setBackgroundColor(Color.WHITE);
        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setSupportZoom(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        /* 安全项 */
        s.setMixedContentMode(WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        if (Build.VERSION.SDK_INT >= 16) {
            s.setAllowFileAccessFromFileURLs(false);
            s.setAllowUniversalAccessFromFileURLs(false);
        }
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSaveFormData(false);
        /* 注意：这里绝不调用 addJavascriptInterface —— 远程页面拿不到任何原生能力 */

        web.setWebViewClient(new WebViewClient() {
            @Override
            public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (u != null && isAllowedHost(u.getHost())) return false;   /* 站内放行 */
                openExternally(u);                                            /* 其余交给系统浏览器 */
                return true;
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest req) {
                Uri u = req.getUrl();
                if (u != null && isLocalOrPrivate(u.getHost())) return BLOCKED;  /* 防反向打本机 DSH */
                return null;
            }

            @Override
            public void onReceivedSslError(WebView v, SslErrorHandler handler, android.net.http.SslError err) {
                handler.cancel();                       /* 一律取消，不给"继续"的选项 */
                toast("\u8bc1\u4e66\u6821\u9a8c\u5931\u8d25\uff0c\u5df2\u963b\u6b62\u52a0\u8f7d");
            }
        });

        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onReceivedTitle(WebView v, String t) {
                if (t != null && t.length() > 0) titleView.setText(t);
            }

            /** 按用户要求：不支持文件上传 */
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                cb.onReceiveValue(null);
                toast("\u672c\u9875\u4e0d\u652f\u6301\u4e0a\u4f20\u6587\u4ef6");
                return true;
            }
        });

        web.setDownloadListener(new DownloadListener() {
            @Override
            public void onDownloadStart(String u, String ua, String cd, String mime, long len) {
                openExternally(Uri.parse(u));
                toast("\u5df2\u4ea4\u7ed9\u7cfb\u7edf\u6d4f\u89c8\u5668\u4e0b\u8f7d");
            }
        });

        root.addView(web, new LinearLayout.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f));

        setContentView(root);
        web.loadUrl(url);
    }

    /* ================= 导航与安全 ================= */

    private static boolean isAllowedHost(String host) {
        if (host == null) return false;
        String h = host.toLowerCase();
        return h.equals("deepseek.com") || h.endsWith(".deepseek.com");
    }

    private static boolean isLocalOrPrivate(String host) {
        if (host == null) return false;
        String h = host.toLowerCase();
        if (h.equals("localhost") || h.equals("127.0.0.1") || h.equals("::1") || h.equals("[::1]")) return true;
        if (h.startsWith("10.") || h.startsWith("192.168.") || h.startsWith("169.254.")) return true;
        if (h.startsWith("172.")) {
            try {
                int second = Integer.parseInt(h.split("\\.")[1]);
                if (second >= 16 && second <= 31) return true;
            } catch (Exception e) { /* ignore */ }
        }
        return false;
    }

    private void openExternally(Uri u) {
        if (u == null) return;
        try {
            Intent i = new Intent(Intent.ACTION_VIEW, u);
            i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            startActivity(i);
            toast("\u5df2\u5728\u7cfb\u7edf\u6d4f\u89c8\u5668\u4e2d\u6253\u5f00");
        } catch (Exception e) {
            toast("\u65e0\u6cd5\u6253\u5f00\u8be5\u94fe\u63a5");
        }
    }

    private void goBackOrFinish() {
        if (web != null && web.canGoBack()) web.goBack();
        else finish();
    }

    @Override
    public void onBackPressed() {
        goBackOrFinish();
    }

    /* ================= 清除登录数据 ================= */

    private void confirmClear() {
        new AlertDialog.Builder(this)
            .setTitle("\u6e05\u9664\u767b\u5f55\u6570\u636e")
            .setMessage("\u5c06\u6e05\u9664\u672c\u5e94\u7528\u5185\u4fdd\u5b58\u7684 DeepSeek \u767b\u5f55\u72b6\u6001\u4e0e\u7f51\u9875\u6570\u636e\u3002\n"
                      + "\u4f1a\u4e00\u5e76\u6e05\u6389 DSH \u9875\u9762\u7684\u4f1a\u8bdd cookie\uff08\u65e0\u5bb3\uff0c\u91cd\u65b0\u6253\u5f00\u5373\u53ef\u6062\u590d\uff09\u3002")
            .setPositiveButton("\u6e05\u9664", new DialogInterface.OnClickListener() {
                @Override public void onClick(DialogInterface d, int w) { doClear(); }
            })
            .setNegativeButton("\u53d6\u6d88", null)
            .show();
    }

    private void doClear() {
        try {
            CookieManager.getInstance().removeAllCookies(null);
            CookieManager.getInstance().flush();
        } catch (Exception e) {}
        try { WebStorage.getInstance().deleteAllData(); } catch (Exception e) {}
        try { web.clearCache(true); } catch (Exception e) {}
        try { web.clearHistory(); } catch (Exception e) {}
        try { web.clearFormData(); } catch (Exception e) {}
        toast("\u5df2\u6e05\u9664\u767b\u5f55\u6570\u636e");
        try { web.reload(); } catch (Exception e) {}
    }

    /* ================= 小工具 ================= */

    private int dp(int v) {
        return (int) (v * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int safeTop() {
        try {
            if (Build.VERSION.SDK_INT >= 23) {
                android.view.WindowInsets ins = getWindow().getDecorView().getRootWindowInsets();
                if (ins != null) return ins.getSystemWindowInsetTop();
            }
        } catch (Exception e) {}
        return 0;
    }

    private void toast(final String msg) {
        runOnUiThread(new Runnable() {
            @Override public void run() {
                try { Toast.makeText(WebPaneActivity.this, msg, Toast.LENGTH_SHORT).show(); } catch (Exception e) {}
            }
        });
    }

    @Override
    protected void onDestroy() {
        if (web != null) web.destroy();
        super.onDestroy();
    }
}
