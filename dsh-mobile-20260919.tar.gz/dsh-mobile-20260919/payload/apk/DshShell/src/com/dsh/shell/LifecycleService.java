package com.dsh.shell;

import android.app.Service;
import android.content.Intent;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;

/**
 * 「随应用启停」的生命周期服务 —— 没有前台通知、没有开机自启、没有后台常驻。
 *
 * 两条规则：
 *   应用可见 → 每 10 秒探活，掉线就拉起（保证用的时候不掉线）
 *   任务被划掉 / 返回退出 → 立刻停止 Termux 侧服务并退出自己
 *
 * 刻意不做「切到后台 N 秒就停」：实测那样会造成停/启循环 —— 用户在长任务期间
 * 切出去或息屏，回来就要重等一次 17 秒的引导。而且后台 startService 本身会在
 * 约 1 分钟后被 Android 回收，onDestroy 里的兜底停止等于必然触发。
 * 只有用户明确的关闭动作（划掉任务、返回退出）才停服务。
 */
public class LifecycleService extends Service {
    public static final String ACTION_OPEN  = "com.dsh.shell.LC_OPEN";
    public static final String ACTION_STOP  = "com.dsh.shell.LC_STOP";

    public static volatile boolean alive = false;
    /** 应用界面是否可见。后台空闲定时器据此判断该不该回收。 */
    public static volatile boolean visible = false;
    public static volatile String lastState = "未启动";

    private static final long PROBE_MS = 10000L;   /* 应用可见时的探活间隔 */

    private final Handler h = new Handler(Looper.getMainLooper());
    private volatile boolean busy = false;

    private final Runnable probe = new Runnable() {
        @Override public void run() {
            if (!busy) {
                busy = true;
                new Thread(new Runnable() {
                    @Override public void run() {
                        try {
                            if (Termux.ping()) {
                                lastState = "运行中";
                            } else {
                                lastState = "掉线，正在拉起";
                                Termux.runOnce(LifecycleService.this, "dsh-supervisor-start",
                                        "DSH: foreground heal", 12000L);
                            }
                        } finally {
                            busy = false;
                        }
                    }
                }).start();
            }
            h.postDelayed(this, PROBE_MS);
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        alive = true;
        lastState = "随应用启停";
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        String a = (intent == null) ? null : intent.getAction();
        if (ACTION_STOP.equals(a)) {
            h.removeCallbacks(probe);
            stopRemote("explicit exit");
            stopSelf();
            return START_NOT_STICKY;
        }
        /* ACTION_OPEN 或空 intent：应用可见，开始保活 */
        h.removeCallbacks(probe);
        h.post(probe);
        lastState = "运行中";
        return START_STICKY;
    }

    /** 从最近任务划掉：直接停。 */
    @Override public void onTaskRemoved(Intent rootIntent) {
        Alarm.cancel(this);          /* 明确关闭：撤销后台空闲定时器 */
        h.removeCallbacks(probe);
        stopRemote("task removed");
        stopSelf();
        super.onTaskRemoved(rootIntent);
    }

    @Override public void onDestroy() {
        /* 注意：这里不停止远端服务。后台 service 被系统回收是常态，
           若在此停服就会变成"切后台约一分钟必定断线"。 */
        alive = false;
        h.removeCallbacksAndMessages(null);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent i) { return null; }

    private void stopRemote(String why) {
        lastState = "已停止（" + why + "）";
        Termux.run(this, "dsh-supervisor-stop", null, "DSH: stop (" + why + ")");
    }
}
