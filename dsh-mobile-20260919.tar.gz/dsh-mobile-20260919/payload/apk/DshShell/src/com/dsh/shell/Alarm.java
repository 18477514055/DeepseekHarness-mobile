package com.dsh.shell;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

/**
 * 后台空闲回收定时器。
 *
 * 为什么必须用 AlarmManager 而不是应用内的 Handler：切到后台后本应用进程会在约
 * 一分钟内被 Android 回收，任何进程内计时器都随之消失。AlarmManager 的闹钟由系统
 * 保管，到点会重新拉起本应用的进程执行接收器，所以"挂在后台 20 分钟就回收"才成立。
 */
public final class Alarm {
    /** 切到后台后多久开始检查（用户要求 20 分钟）。 */
    public static final long FIRST_MS = 20 * 60 * 1000L;
    /** 检查时发现「有任务在跑」就顺延，多久后再看一次。 */
    public static final long RETRY_MS = 10 * 60 * 1000L;

    private static final int REQ = 100;

    private Alarm() {}

    private static PendingIntent pi(Context c) {
        Intent i = new Intent(c, IdleAlarmReceiver.class).setAction("com.dsh.shell.IDLE_CHECK");
        int flags = PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(c, REQ, i, flags);
    }

    public static void schedule(Context c, long delayMs) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            long at = System.currentTimeMillis() + delayMs;
            /* setAndAllowWhileIdle：无需 SCHEDULE_EXACT_ALARM 特殊授权，Doze 下也能送达。
               精度差几分钟无所谓 —— 这是闲置回收，不是闹钟。 */
            if (Build.VERSION.SDK_INT >= 23) {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi(c));
            } else {
                am.set(AlarmManager.RTC_WAKEUP, at, pi(c));
            }
        } catch (Exception e) { /* 定时失败不影响主流程 */ }
    }

    public static void cancel(Context c) {
        try {
            AlarmManager am = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
            am.cancel(pi(c));
        } catch (Exception e) {}
    }
}
