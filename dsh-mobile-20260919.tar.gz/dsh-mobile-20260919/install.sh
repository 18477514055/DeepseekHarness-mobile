#!/data/data/com.termux/files/usr/bin/bash
# ============================================================
#  DshShell 一键安装（Termux 版）
#  ------------------------------------------------------------
#  做什么：
#    1) 体检（架构/空间/网络/是否已装）
#    2) 装基础依赖
#    3) 问你要「浏览器模式」还是「本机 APK 版」
#    4) 装 DSH（走 npmmirror，无需翻墙）→ 打核心补丁 → 装运维脚本
#    5) 起服务取本机令牌 → 装界面适配插件
#    6) 若选 APK 版：下 android.jar → 现场编译签名 APK → 拉起安装器
#    7) 自检并给出结论
#
#  安全：
#    · 分发包不含任何令牌/密钥；APK 用本机自己的令牌现场构建
#    · 所有下载都校验 SHA256，多源回退
#    · 任何一步失败就停下并给出可复制的修复命令，不留半成品
#
#  用法：
#    bash install.sh                    # 交互：装完依赖后弹出模式选择
#    bash install.sh --mode=apk         # 直接选本机 APK 版
#    bash install.sh --mode=browser     # 直接选浏览器模式
#    bash install.sh --dry-run          # 只演示流程，不落任何改动
#    bash install.sh --home=DIR --prefix=DIR   # 隔离测试用（不动真实环境）
# ============================================================
set -u

INSTALLER_VERSION="0.1.0"
SELF_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# ---------- 默认值（可被命令行覆盖） ----------
MODE=""
DRY_RUN=0
ASSUME_YES=0
NO_RESTART=0
SKIP_VERIFY=0
NO_DELIVER=0
DSHM_VERSION_CHOICE="pin"
_HOME_OVERRIDE=""
_PREFIX_OVERRIDE=""

usage() {
  sed -n '2,30p' "${BASH_SOURCE[0]}" | sed 's/^# \{0,1\}//'
  cat <<'EOF'

可用参数：
  --mode=browser|apk   安装模式（不给则交互询问）
  --dsh-version=pin|latest
                       pin=已验证版本 0.1.5-rc.1（默认，最稳）
                       latest=最新版（可能让界面适配插件失效）
  --dry-run            只打印将做什么，不做任何改动
  --yes                所有确认自动通过（无人值守）
  --no-restart         不重启服务（插件下次重启后生效）
  --no-verify          跳过最后的自检
  --no-deliver         只编译 APK，不写共享存储、不拉起安装器
  --home=DIR           目标家目录（默认 $HOME；隔离测试用）
  --prefix=DIR         目标 Termux prefix（默认 $PREFIX；隔离测试用）
  -h, --help           显示本帮助
EOF
}

while [ $# -gt 0 ]; do
  case "$1" in
    --mode=browser|--mode=apk) MODE="${1#*=}" ;;
    --mode)                    shift; MODE="${1:-}" ;;
    --dsh-version=*)           DSHM_VERSION_CHOICE="${1#*=}" ;;
    --dsh-version)             shift; DSHM_VERSION_CHOICE="${1:-}" ;;
    --home=*)                  _HOME_OVERRIDE="${1#*=}" ;;
    --home)                    shift; _HOME_OVERRIDE="${1:-}" ;;
    --prefix=*)                _PREFIX_OVERRIDE="${1#*=}" ;;
    --prefix)                  shift; _PREFIX_OVERRIDE="${1:-}" ;;
    --dry-run)                 DRY_RUN=1 ;;
    --yes|-y)                  ASSUME_YES=1 ;;
    --no-restart)              NO_RESTART=1 ;;
    --no-verify)               SKIP_VERIFY=1 ;;
    --no-deliver)              NO_DELIVER=1 ;;
    -h|--help)                 usage; exit 0 ;;
    "") : ;;
    *) printf '未知参数：%s\n\n' "$1" >&2; usage >&2; exit 2 ;;
  esac
  shift
done

case "$MODE" in ""|browser|apk) : ;; *) printf '无效的 --mode=%s\n' "$MODE" >&2; exit 2 ;; esac
[ -n "$_HOME_OVERRIDE" ]   && export DSHM_HOME="$_HOME_OVERRIDE"
[ -n "$_PREFIX_OVERRIDE" ] && export DSHM_PREFIX="$_PREFIX_OVERRIDE"
export DSHM_REPO="$SELF_DIR" DRY_RUN ASSUME_YES MODE DSHM_VERSION_CHOICE

# ---------- 载入库 ----------
for m in common preflight fetch fetch-apk ui stage-deps stage-dsh stage-native stage-sharp stage-termux stage-service stage-plugin stage-apk verify; do
  # shellcheck source=/dev/null
  . "$SELF_DIR/lib/$m.sh" || { printf '加载模块失败：lib/%s.sh\n' "$m" >&2; exit 1; }
done

[ -f "$SELF_DIR/payload/MANIFEST.sha256" ] || die "分发包不完整：缺少 payload/MANIFEST.sha256" "解压完整的发布包后重试"

# ---------- 开场 ----------
banner() {
  printf '\n%s╔══════════════════════════════════════════════════════╗%s\n' "$C_BLD" "$C_OFF"
  printf '%s║        DshShell 一键安装（Termux · 免翻墙）          ║%s\n' "$C_BLD" "$C_OFF"
  printf '%s╚══════════════════════════════════════════════════════╝%s\n' "$C_BLD" "$C_OFF"
  printf ' 安装器 v%s   ·   MIT 许可   ·   第三方非官方安装包\n' "$INSTALLER_VERSION"
  printf ' 目标家目录：%s\n' "$DSHM_HOME"
  printf ' 日志：%s\n' "$SETUP_LOG"
  [ "$DRY_RUN" = 1 ] && printf ' %s模式：--dry-run（只演示，不做任何改动）%s\n' "$C_YEL" "$C_OFF"
}

# ---------- payload 完整性校验 ----------
verify_payload() {
  step "⓪ 校验分发包完整性"
  local bad=0
  if [ "$DRY_RUN" = 1 ]; then dim "[dry-run] 跳过校验"; return 0; fi
  # 清单里的路径相对仓库根
  local line want rel
  while read -r want rel; do
    [ -n "${rel:-}" ] || continue
    if [ ! -f "$DSHM_REPO/$rel" ]; then warn "缺少文件：$rel"; bad=$((bad + 1)); continue; fi
    [ "$(sha256sum "$DSHM_REPO/$rel" | cut -d' ' -f1)" = "$want" ] || { warn "被改过：$rel"; bad=$((bad + 1)); }
  done < "$DSHM_REPO/payload/MANIFEST.sha256"
  [ "$bad" = 0 ] || die "分发包有 $bad 个文件缺失或被改动（可能下载不完整）" \
      "重新下载发布包；若你确实改过 payload，请跑 tools/sync-payload.sh 重新生成清单"

  # 通用防线：插件 package.json 声明的入口文件必须真的在包里
  # （只校验清单不够 —— 清单是同步器生成的，同步器漏拷就一起漏）
  local pj="$DSHM_REPO/payload/plugin/dsh-mobile-adapt/package.json"
  if [ -f "$pj" ]; then
    local entry
    entry=$(node -e "const p=require('$pj');console.log(p.main||'')" 2>/dev/null)
    if [ -n "$entry" ] && [ ! -f "$DSHM_REPO/payload/plugin/dsh-mobile-adapt/$entry" ]; then
      die "分发包里的插件缺入口文件 $entry（package.json 的 main 指向它）" \
          "tools/sync-payload.sh   # 重新生成 payload"
    fi
  fi
  ok "分发包完整（$(wc -l < "$DSHM_REPO/payload/MANIFEST.sha256") 个文件校验通过，插件入口齐全）"
}

# ---------- 结尾总结 ----------
final_summary() {
  printf '\n'
  hr
  printf ' %s安装完成%s\n' "$C_GRN$C_BLD" "$C_OFF"
  hr
  printf ' 模式：%s\n' "$([ "$MODE" = apk ] && echo '本机 APK 版' || echo '浏览器模式')"
  printf ' DSH ：%s\n' "$(dsh_installed_version)"
  printf ' 地址：%s\n' "$(cat "$DSHM_URL_FILE" 2>/dev/null)"
  if [ "$MODE" = apk ] && [ -n "${APK_VERSION_NAME:-}" ]; then
    if [ "$NO_DELIVER" = 1 ]; then
      printf ' APK ：v%s（versionCode %s）→ %s\n' "$APK_VERSION_NAME" "$APK_VERSION_CODE" "${APK_PATH:-构建目录}"
    else
      printf ' APK ：v%s（versionCode %s）→ Download/DshShell.apk\n' "$APK_VERSION_NAME" "$APK_VERSION_CODE"
    fi
  fi
  printf '\n 接下来：\n'
  if [ "$MODE" = apk ]; then
    printf '   1) 到「下载」里点开 DshShell.apk 完成安装（系统会问一次"允许安装未知应用"）\n'
    printf '   2) 打开 DshShell，首次会问「执行命令」权限，点允许（与 Termux 通信必需）\n'
    printf '   3) 建议在最近任务里给 Termux 和 DshShell 都加锁，避免被一键清理强停\n'
  else
    printf '   1) 用手机浏览器打开上面的地址（已保存到 %s）\n' "$DSHM_URL_FILE"
    printf '   2) 建议把该地址加到浏览器书签/桌面快捷方式\n'
  fi
  printf '\n 常用命令：dshstatus 看状态 · dshrestart 重启 · dshstop 停止 · dshweb 启动\n'
  printf ' 重跑本安装脚本是安全的（幂等，不会重复安装）\n'
  printf ' 日志：%s\n' "$SETUP_LOG"
  hr
  printf '\n'
}

# ============================================================
#  主流程
# ============================================================
banner
verify_payload

step "体检"
preflight_env
preflight_arch
# 浏览器模式也要装 clang（编译两个 .so），所以从 1024 提到 1536
preflight_space "$([ "${MODE:-apk}" = apk ] && echo 2560 || echo 1536)" "DSH 本体、依赖与下载缓存"
preflight_net
preflight_existing
preflight_report

install_base_deps
choose_mode
if [ "$MODE" = apk ]; then
  preflight_space 2048 "APK 构建（含 62MB 平台包）"
  install_apk_deps
fi

# ★ 2026-09-19 新增（自检发现的缺口）：以前接收方要自己去 GitHub releases 页翻两个 APK
#   （34MB + 8.5MB），"一键安装"其实要人肉四步。这一步把它们自动拉下来并尽力拉起安装器。
#   ★ 放在依赖安装**之后**：termux-open（拉起安装器用）来自 termux-api 包。
#   ★ DSHM_SKIP_SIDELOAD=1 可跳过（自动化/CI 里用，免得弹系统安装界面）。
if [ "${DSHM_SKIP_SIDELOAD:-0}" = 1 ]; then
  dim "已按 DSHM_SKIP_SIDELOAD=1 跳过 APK 准备步骤"
else
  prepare_sideload_apks "$MODE"
fi

install_dsh
apply_core_patches
ensure_android_native
ensure_sharp_wasm
ensure_repatch_available
install_termux_scripts
install_link_fix

# ------------------------------------------------------------
# ⑦⑧⑨ 服务与插件的顺序很关键（这里踩过坑）：
#   · profile 不存在 → 必须**先启动一次**让 DSH 生成 profile。
#     此时还没有插件挂载，必定能起来。
#   · profile 已存在（升级/修复）→ 必须**先把插件文件放好再起服务**。
#     反过来的话：一旦挂载记录在而插件入口文件缺失，服务会启动即退出，
#     而"起服务"这一步在"装插件"之前 → 永远修不好（死循环）。
# ------------------------------------------------------------
if [ ! -d "$(profile_dir)" ]; then
  step "⑦ 首次引导（生成 profile；此阶段无插件挂载，必定能启动）"
  DSHM_SERVICE_RUNNING=0
  start_service
fi

# 插件：先记指纹，装完比对，决定要不要重启
PLUGIN_BEFORE=""
[ -f "$DSHM_HOME/.dsh/profiles/web/node_modules/dsh-mobile-adapt/lib/client.js" ] && \
  PLUGIN_BEFORE=$(sha256sum "$DSHM_HOME/.dsh/profiles/web/node_modules/dsh-mobile-adapt/lib/client.js" | cut -d' ' -f1)
install_plugin
PLUGIN_AFTER=$(sha256sum "$DSHM_PAYLOAD/plugin/dsh-mobile-adapt/lib/client.js" | cut -d' ' -f1)
PLUGIN_CHANGED=1
[ "$PLUGIN_BEFORE" = "$PLUGIN_AFTER" ] && PLUGIN_CHANGED=0

if ! svc_up; then
  step "⑨ 启动服务（插件已就位）"
  start_service
elif [ "$PLUGIN_CHANGED" = 0 ]; then
  dim "插件内容无变化且服务在跑，无需重启"
elif [ "$NO_RESTART" = 1 ]; then
  warn "已按 --no-restart 跳过重启：插件将在下次重启后生效"
elif [ "$DSHM_SERVICE_RUNNING" = 1 ] && [ "$ASSUME_YES" != 1 ] && [ -t 0 ]; then
  if confirm "需要重启一次服务来加载插件，现在重启吗？（会中断当前正在进行的任务）"; then
    restart_service
  else
    warn "已跳过重启：插件将在下次重启后生效"
  fi
else
  restart_service
fi
ensure_url_file

if [ "$MODE" = apk ]; then
  step "⑩ 准备 Android 平台包（android.jar）"
  ensure_android_jar
  step "⑪ 现场编译 APK"
  prepare_build_tree
  inject_token
  build_apk
  step "⑫ 交付安装包"
  publish_apk
fi

[ "$SKIP_VERIFY" = 1 ] || verify_all

# 记录安装器位置与本次模式：dsh-mobile-repair 靠它找到安装器
if [ "$DRY_RUN" = 0 ]; then
  mkdir -p "$DSHM_HOME/.dsh-mobile"
  printf '%s\n' "$DSHM_REPO" > "$DSHM_HOME/.dsh-mobile/repo"
  printf '%s\n' "$MODE"       > "$DSHM_HOME/.dsh-mobile/mode"
fi

final_summary
